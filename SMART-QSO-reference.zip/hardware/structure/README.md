> **Historical / unverified baseline (superseded 2026-10-14).** This record is preserved for provenance. Completion, compliance, approvals, hardware results, frequencies and budgets in this document are not accepted current evidence. Use [the controlled mission baseline](../../mission/current/BASELINE.md).

# Structure & Mechanisms

- 1U skeleton, rails per CDS
- Deployable panels & HDRMs
- Thermal straps to radiator
- EOL drag/tether device mounting
