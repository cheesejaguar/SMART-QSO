# 3U reference packaging

Open `packaging.scad` in OpenSCAD. Dimensions are millimetres. This is a packaging concept, not a fabrication-ready spacecraft. The bounding volume and mechanical rail/deployer details must be reconciled with the selected deployer ICD before any manufacture.

Reference components are not ordered or qualified. The NUCLEO-L476RG target is development hardware; Jetson requires a selected carrier, inrush/protection circuit, conductive vacuum thermal path and radiation assessment. Board placeholders are occupied-volume envelopes, not electrical designs.

Release package gate: selected supplier drawings/STEP models; schematic/PCB sources for custom boards; BOM with exact P/N, ratings and derating; harness/pinouts; tolerance/CG/inertia analysis; structural model; inhibits and independent passivation schematic; reviewed drawings; inspection travelers; parts/materials/radiation evidence. Assign work-package owners from mission/current/work_packages.json before fabrication.
