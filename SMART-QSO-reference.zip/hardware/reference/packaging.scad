// SMART-QSO 3U reference packaging. Concept only: not released manufacturing geometry.
// mm. Deployer/vendor geometry, tolerance stacks and electrical interfaces pending.
$fn=24;
outer=[100,100,340.5];
rail=8.5;
module board(z,thickness=1.6) {translate([8,8,z]) color([0.12,0.28,0.24]) cube([84,84,thickness]);}
for(x=[0,100-rail],y=[0,100-rail]) translate([x,y,0]) color([0.55,0.56,0.58]) cube([rail,rail,outer[2]]);
for(z=[0,outer[2]-4]) translate([0,0,z]) color([0.55,0.56,0.58]) difference(){cube([100,100,4]);translate([rail,rail,-1])cube([100-2*rail,100-2*rail,6]);}
board(22);board(58);board(100);board(148);board(212);
translate([15,15,65])color([0.3,0.3,0.34])cube([70,70,30]); // battery placeholder envelope
translate([15,25,220])color([0.3,0.3,0.34])cube([70,45,25]); // compute envelope, vendor model pending
translate([12,12,254])color([0.72,0.48,0.19])cube([76,76,5]); // conductive spreader concept
