# SMART-QSO

**A small spacecraft. A wider conversation.**

An open **3U digital message-relay CubeSat** concept with bounded autonomy and an isolated onboard language-generation experiment. Ordinary amateur packet stations are the intended users. The MCU owns safety, relay service, factual telemetry and radio shutdown; the language payload is optional.

**Current state: repository demonstration.** No hardware, sponsoring institution, funding, spectrum authorization, launch or flight qualification is secured. Historical review/compliance claims are preserved as unverified records. NASA-aligned requirements and assurance are a development target, not a certification claim.

## Run the complete local demonstration

Prerequisites: Python 3.11+, uv, CMake 3.20+, C11 compiler, Node.js 24.19.0 (verified build). CMocka is found locally or fetched with a pinned checksum.

```sh
uv sync --frozen --extra dev
cmake -S software/flight -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build
ctest --test-dir build --output-on-failure --no-tests=error
uv run pytest -q
npm --prefix software/web ci
npm --prefix software/web run build
uv run python -m software.ground.service.app
```

Open [the local public site](http://127.0.0.1:8000/) and [mission console](http://127.0.0.1:8000/console/). There is no silent RF transmission. Simulation, replay, offline and stale states are explicit. Signing is unavailable until you provision local credentials; see [ground operations](software/ground/README.md).

![Public design concept](docs/design/public-concept.png)

## What is implemented

- Portable bounded C relay: persistent queue, duplicate rejection, quotas, fair scheduling, expiry, acknowledgments and retry limits.
- Ed25519 telecommands, persistent replay floor and retained transmitter inhibits; fail-closed storage behavior.
- Shared protocol authority and C/Python conformance; AX.25 UI and streaming KISS reference client.
- Genuine STM32L476RG Cortex-M4 reference images with static FreeRTOS, UART/GPIO/watchdog, persistent journal, signed image validation and boot trial/rollback.
- Local FastAPI/SQLite service, React operator console, Astro public site and a reproducible engineering-analysis CLI.
- Separate OBC–payload transaction link, independent MCU factual acceptance, deadlines, power cycling and template fallback.
- Authenticated streaming firmware updates, durable page-checkpoint resume, readback/hash checks, trial/rollback and retained retirement.
- Ground-trained compact contact/energy predictor with matched synthetic evaluation and deterministic safety gates; measured flight benefit remains unproven.
- Current production replacements for every quarantined C test, bounded B-dot/calibration and periodic scheduling, with explicit MISRA context/assurance records.
- Complete artifact audit, finding/evidence registers, requirements, work packages, standards tailoring and funded review gates.

[MISRA and test remediation](docs/resurrection/MISRA_RESOLUTION.md) · [Software closure and remaining acceptance](docs/resurrection/SOFTWARE_CLOSURE.md) · [Payload integration](docs/resurrection/PAYLOAD_INTEGRATION.md) · [Firmware updates](docs/resurrection/FIRMWARE_UPDATES.md)

## Engineering and funding

[Controlled mission baseline](mission/current/BASELINE.md) · [Audit report](docs/resurrection/AUDIT_REPORT.md) · [Verification campaign](docs/resurrection/VERIFICATION_CAMPAIGN.md) · [Research protocol](docs/resurrection/EXPERIMENT_PLAN.md)

[Funding proposal](output/pdf/SMART-QSO-proposal.pdf) · [Editable presentation](output/presentation/SMART-QSO-funding.pptx)

[Implementation and verification report](docs/resurrection/IMPLEMENTATION_REPORT.md) · [Development release manifest](output/release/manifest.json) · [Reference release archive](output/release/SMART-QSO-reference.zip)

The program funding target is **$500k-$1.5m**, not a validated estimate. Planning allocations separate cash and uncommitted in-kind contributions. The first funding gate targets measured 3U feasibility, station interoperability, named owners and independent requirements review. No novelty, grant or flight-heritage claim is made without evidence.

## Reference firmware

See [STM32 reference target](software/flight/platform/stm32l476/README.md). `FLIGHT_BUILD=ON` on a host compiler fails instead of producing a mislabeled executable. Outputs remain SAFE/RF OFF without verified EPS input. Flight sensor/radio/actuator drivers, environmental acceptance and provider/regulatory approvals require selected hardware and external evidence.

## Program checks

```sh
uv run python -m tools.generate_protocol --check
uv run python -m tools.audit_repository
uv run python -m tools.check_program
uv run python -m software.simulation.mission
uv run ruff check software tools
uv run mypy software/payload software/common software/ground/service software/ground/client software/simulation
```

[Parametric reference packaging](hardware/reference/README.md) is a concept, not a released manufacturing design. All mechanical, EPS, avionics, RF, ADCS, thermal/radiation, software, ground, AIT/GSE, launch/disposal and program workstreams have explicit closure gates.

MIT license. Contributions must preserve evidence provenance, pass relevant checks and trace new behavior to requirements. Do not commit credentials or present simulated results as flight evidence.

## Public publishing

The publication target is [GitHub Pages](https://cheesejaguar.github.io/SMART-QSO/). Run `uv run python -m tools.publish_pages` after rebuilding and verifying the development release. The publisher checks the exact current-source archive and project-path static links, updates only `gh-pages`, and restores the localhost build. Public pages provide read-only evidence and the development source archive; the signing/command service remains local. Deployment/build/HTTP evidence is recorded separately in `output/verification/publication.json`. See [final review and remaining external work](docs/resurrection/FINAL_REVIEW.md).
