"""Create a signed reference firmware image; writes an artifact, never programs a device."""

import argparse
import hashlib
import struct
from pathlib import Path

from software.ground.service.signing import Signer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--application", type=Path, required=True)
    parser.add_argument("--key", type=Path, required=True)
    parser.add_argument("--version", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    image = args.application.read_bytes()
    if not 8 <= len(image) <= 382 * 1024 or not 1 <= args.version < 2**64:
        parser.error("Application/monotonic version exceeds the slot bounds")
    signer = Signer(args.key)
    manifest = (
        b"SQFW"
        + struct.pack("<QI", args.version, len(image))
        + hashlib.blake2b(image, digest_size=32).digest()
    )
    # File update signing uses its own provisioned key; does not reuse telecommand envelopes.
    signature = signer.sign_manifest(manifest)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(
        manifest + signature + b"\xff" * (2048 - len(manifest) - len(signature)) + image
    )
    print(
        f"Signed image: {len(image)} application bytes, version {args.version}; boot acceptance requires the matching update public key"
    )


if __name__ == "__main__":
    main()
