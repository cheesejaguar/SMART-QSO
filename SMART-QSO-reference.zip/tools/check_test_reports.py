"""Reject absent, empty, failed, disabled or skipped verification reports."""

import argparse
import xml.etree.ElementTree as ET
from pathlib import Path


def check_report(path: Path) -> dict[str, int]:
    tree = ET.parse(path)
    suites = [s for s in tree.iter("testsuite") if not s.findall("testsuite")]
    counts = {
        key: sum(int(s.get(key, 0)) for s in suites)
        for key in ("tests", "failures", "errors", "skipped", "disabled")
    }
    if counts["tests"] == 0 or any(counts[k] for k in counts if k != "tests"):
        raise RuntimeError(f"Absent/failed/skipped verification evidence: {path}: {counts}")
    return counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", type=Path, nargs="+")
    args = parser.parse_args()
    for path in args.reports:
        print(f"{path}: {check_report(path)['tests']} executed; no failures or skips")


if __name__ == "__main__":
    main()
