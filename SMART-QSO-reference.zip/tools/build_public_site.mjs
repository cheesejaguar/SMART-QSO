// Export read-only engineering evidence; no console, signing service or operational data.
import {copyFile, mkdir, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'software/web/public/dist');
await mkdir(path.join(out, 'evidence'), {recursive: true});
for (const name of ['baseline', 'findings', 'requirements', 'gates', 'work_packages',
  'software_closure', 'budgets', 'standards', 'final_review']) {
  await copyFile(path.join(root, `mission/current/${name}.json`), path.join(out, `evidence/${name}.json`));
}
for (const name of ['engineering-analysis', 'predictor-experiment']) {
  await copyFile(path.join(root, `output/${name}.json`), path.join(out, `evidence/${name}.json`));
}
if (process.env.PUBLIC_SQ_STATIC === '1') {
  await copyFile(path.join(root, 'output/release/SMART-QSO-reference.zip'), path.join(out, 'SMART-QSO-reference.zip'));
  await copyFile(path.join(root, 'output/release/checksums.sha256'), path.join(out, 'checksums.sha256'));
  await copyFile(path.join(root, 'output/release/manifest.json'), path.join(out, 'manifest.json'));
  await copyFile(path.join(root, 'output/release/sbom.cdx.json'), path.join(out, 'sbom.cdx.json'));
}
await writeFile(path.join(out, '.nojekyll'), '');
if (process.env.SQ_PUBLIC_SITE) {
  const origin = new URL(process.env.SQ_PUBLIC_SITE).origin;
  const base = (process.env.SQ_PUBLIC_BASE || '/').replace(/\/$/, '') + '/';
  const locations = ['', 'engineering/', 'participate/', 'research/'].map(route => origin + base + route);
  await writeFile(path.join(out, 'sitemap.xml'), '<?xml version="1.0" encoding="UTF-8"?>\n'
    + '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
    + locations.map(url => `<url><loc>${url}</loc></url>`).join('') + '</urlset>\n');
  await writeFile(path.join(out, 'robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${origin + base}sitemap.xml\n`);
}
