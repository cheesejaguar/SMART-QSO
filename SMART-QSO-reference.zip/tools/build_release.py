"""Package reference firmware, locked dependencies and actual verification evidence.

This produces a development manifest and CycloneDX inventory, never flight acceptance.
"""

import hashlib
import json
import subprocess
import tomllib
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from tools.check_test_reports import check_report

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output/release"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reports():
    results = {}
    for name in ("pytest", "ctest", "sanitizers"):
        p = ROOT / f"output/verification/{name}.xml"
        counts = check_report(p)
        results[name] = {**counts, "path": str(p.relative_to(ROOT)), "sha256": digest(p)}
    return results


def sbom():
    components = []
    lock = tomllib.loads((ROOT / "uv.lock").read_text())
    for package in lock["package"]:
        name, version = package["name"], package["version"]
        components.append(
            {
                "type": "library",
                "name": name,
                "version": version,
                "purl": f"pkg:pypi/{name}@{version}",
                "properties": [
                    {
                        "name": "evidence",
                        "value": "uv.lock pinned artifacts; license review required",
                    }
                ],
            }
        )
    npm = json.loads((ROOT / "software/web/package-lock.json").read_text())
    for package_path, package in npm["packages"].items():
        if "node_modules/" not in package_path or not package.get("version"):
            continue
        name, version = package_path.rsplit("node_modules/", 1)[1], package["version"]
        components.append(
            {
                "type": "library",
                "name": name,
                "version": version,
                "purl": f"pkg:npm/{name.replace('@', '%40')}@{version}",
                "properties": [
                    {
                        "name": "source-integrity",
                        "value": package.get("integrity", "workspace link"),
                    },
                    {
                        "name": "declared-license",
                        "value": package.get("license", "Review required"),
                    },
                ],
            }
        )
    for name, version, url, license_name in [
        ("Monocypher", "4.0.3", "https://monocypher.org/", "BSD-2-Clause OR CC0-1.0"),
        ("FreeRTOS-Kernel", "11.1.0", "https://github.com/FreeRTOS/FreeRTOS-Kernel", "MIT"),
        ("CMocka", "1.1.7", "https://cmocka.org/", "Apache-2.0"),
        ("Cppcheck", "2.22.0", "https://cppcheck.sourceforge.io/", "GPL-3.0-or-later"),
        (
            "xPack ARM GNU toolchain",
            "14.2.1-1.1",
            "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack",
            "Toolchain license bundle; review required",
        ),
    ]:
        components.append(
            {
                "type": "application"
                if name in ("xPack ARM GNU toolchain", "Cppcheck")
                else "library",
                "name": name,
                "version": version,
                "externalReferences": [{"type": "website", "url": url}],
                "properties": [{"name": "declared-license", "value": license_name}],
            }
        )
    unique = {(c["name"], c["version"]): c for c in components}
    return {
        "bomFormat": "CycloneDX",
        "specVersion": "1.6",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(UTC).isoformat(),
            "component": {
                "type": "application",
                "name": "SMART-QSO development reference",
                "version": "1.0.0",
            },
        },
        "components": list(unique.values()),
    }


def main():
    subprocess.run(
        ["python3", str(ROOT / "tools/check_firmware.py"), str(ROOT / "build/arm-reference")],
        check=True,
    )
    OUT.mkdir(parents=True, exist_ok=True)
    bom = OUT / "sbom.cdx.json"
    bom.write_text(json.dumps(sbom(), indent=2) + "\n")
    files = [
        bom,
        ROOT / "uv.lock",
        ROOT / "software/web/package-lock.json",
        ROOT / "mission/current/protocol.json",
        ROOT / "output/engineering-analysis.json",
        ROOT / "output/predictor-experiment.json",
        ROOT / "mission/current/misra_findings.json",
        ROOT / "mission/current/software_closure.json",
        ROOT / "mission/current/legacy_test_migration.json",
        ROOT / "mission/current/misra_resolution.json",
        ROOT / "docs/resurrection/MISRA_RESOLUTION.md",
        ROOT / "docs/resurrection/FIRMWARE_UPDATES.md",
        ROOT / "docs/resurrection/PAYLOAD_INTEGRATION.md",
        ROOT / "docs/resurrection/SOFTWARE_CLOSURE.md",
        ROOT / "mission/current/artifact_inventory.json",
        ROOT / "docs/resurrection/AUDIT_REPORT.md",
        ROOT / "output/pdf/SMART-QSO-proposal.pdf",
        ROOT / "output/presentation/SMART-QSO-funding.pptx",
    ]
    for name in (
        "smart_qso_boot",
        "smart_qso_reference",
        "smart_qso_reference_b",
        "smart_qso_reference_recovery",
    ):
        files += [
            ROOT / f"build/arm-reference/{name}.bin",
            ROOT / f"build/arm-reference/{name}.map",
            ROOT / f"build/arm-reference/platform/stm32l476/{name}.elf",
        ]
    files += list((ROOT / "output/ui").glob("*.png"))
    files += list((ROOT / "output/verification").rglob("*.json"))
    files += list((ROOT / "output/verification").rglob("*.xml")) + list(
        (ROOT / "output/verification/analyzer").glob("*.plist")
    )
    files += [
        ROOT / "software/flight/vendor/MONOCYPHER_LICENSE.md",
        ROOT / "software/flight/platform/stm32l476/README.md",
    ]
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    sources = sorted(
        subprocess.check_output(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard"], cwd=ROOT, text=True
        ).splitlines()
    )
    source_records = [
        {"path": p, "sha256": digest(ROOT / p)}
        for p in sources
        if (ROOT / p).is_file()
        and not p.startswith(("output/", ".impeccable/"))
        and p
        not in ("mission/current/artifact_inventory.json", "docs/resurrection/AUDIT_REPORT.md")
    ]
    cache = (ROOT / "build/arm-reference/CMakeCache.txt").read_text()

    def setting(name):
        return next(
            line.split("=", 1)[1] for line in cache.splitlines() if line.startswith(name + ":")
        )

    compiler = setting("CMAKE_C_COMPILER")
    key_records = {
        name: (
            "Unprovisioned; acceptance disabled"
            if not setting("SQ_" + name + "_PUBLIC_KEY")
            else "Provisioned public-key SHA256 "
            + hashlib.sha256(bytes.fromhex(setting("SQ_" + name + "_PUBLIC_KEY"))).hexdigest()
        )
        for name in ("COMMAND", "UPDATE")
    }
    manifest = {
        "version": "1.0.0-development",
        "built_at_utc": datetime.now(UTC).isoformat(),
        "original_source_commit": commit,
        "source_tree_sha256": hashlib.sha256(
            json.dumps(source_records, sort_keys=True).encode()
        ).hexdigest(),
        "source_files": source_records,
        "source_tree_included": True,
        "test_reports": reports(),
        "target": "STM32L476RG development reference",
        "command_and_update_keys": key_records,
        "toolchain_records": {
            "arm_gcc": subprocess.check_output([compiler, "--version"], text=True).splitlines()[0],
            "cmake": subprocess.check_output(["cmake", "--version"], text=True).splitlines()[0],
            "host_clang": subprocess.check_output(["clang", "--version"], text=True).splitlines()[
                0
            ],
            "cppcheck": {
                "version": "2.22.0",
                "source_sha256": "d74945deb2d50393430e07596b766f8a779512c7f60dac2a30ea64e059ece57b",
                "partial_misra_compliance": False,
                "actionable_findings": json.loads(
                    (ROOT / "mission/current/misra_findings.json").read_text()
                )["actionable_findings"],
                "raw_context_diagnostics": json.loads(
                    (ROOT / "mission/current/misra_findings.json").read_text()
                )["context_findings"],
            },
        },
        "model_artifacts": [],
        "flight_accepted": False,
        "hardware_execution_verified": False,
        "misra_compliance_verified": False,
        "qualification_gaps": [
            "Selected EPS, ADCS, RF, RTC and deployment hardware/drivers",
            "Protected option bytes and interrupted writes/updates HIL",
            "Actual radio interoperability and cessation",
            "Parts/radiation/thermal/environmental evidence",
            "Independent reviews and institutional/regulatory/provider acceptance",
        ],
        "artifacts": [
            {"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": digest(p)}
            for p in files
        ],
    }
    record = OUT / "manifest.json"
    record.write_text(json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(OUT / "SMART-QSO-reference.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        included = set()
        for p in [record, *files]:
            name = str(p.relative_to(ROOT))
            archive.write(p, name)
            included.add(name)
        for source in source_records:
            if source["path"] not in included:
                archive.write(ROOT / source["path"], source["path"])
                included.add(source["path"])
    checksum_files = [record, bom, OUT / "SMART-QSO-reference.zip"]
    (OUT / "checksums.sha256").write_text(
        "".join(f"{digest(p)}  {p.name}\n" for p in checksum_files)
    )
    print(
        f"Packaged {len(files)} development artifacts and {len(sbom()['components'])} dependency components; no flight acceptance"
    )


if __name__ == "__main__":
    main()
