"""Fail on inconsistent baseline, missing workstreams, invalid evidence claims or protocol drift."""

import json
from pathlib import Path

from software.simulation.mission import budgets
from tools.audit_repository import STATES

ROOT = Path(__file__).resolve().parents[1]


def main():
    current = ROOT / "mission/current"

    def load(n):
        return json.loads((current / f"{n}.json").read_text())

    baseline = load("baseline")
    if (
        baseline["form_factor"] != "3U"
        or baseline["ai"]["on_orbit_training"]
        or baseline["ai"]["federated_updates"]
    ):
        raise SystemExit("Unapproved mission scope drift")
    packages = load("work_packages")
    if {p["id"] for p in packages} != {
        "SYS",
        "MECH",
        "EPS",
        "OBC",
        "RF",
        "ADCS",
        "ENV",
        "FSW",
        "AI",
        "GND",
        "AIT",
        "REG",
        "PM",
    }:
        raise SystemExit("Missing mission workstream")
    for name in ("findings", "requirements", "work_packages", "gates"):
        data = load(name)
        if len({r["id"] for r in data}) != len(data):
            raise SystemExit(f"Duplicate identifiers: {name}")
        for row in data:
            if row["state"] not in STATES:
                raise SystemExit(f"Invalid evidence state: {name}/{row['id']}")
            if row["state"] == "accepted" and not row.get("acceptance_record"):
                raise SystemExit(f"Unsupported acceptance: {row['id']}")
    for f in load("findings"):
        for source in f["evidence"]:
            if not (ROOT / source).exists():
                raise SystemExit(f"Missing finding evidence: {source}")
    for name, field in (("requirements", "evidence"), ("findings", "closure_evidence")):
        for row in load(name):
            for path in row.get(field, []):
                if not (ROOT / path).exists():
                    raise SystemExit(f"Missing correction/test evidence: {path}")
    matrix = load("standards_tailoring")["requirements"]
    if len(matrix) != 253 or len({r["id"] for r in matrix}) != len(matrix):
        raise SystemExit("Incomplete/duplicate clause-level assurance register")
    for row in matrix:
        if not row["owner"] or not row["source_url"] or row["state"] not in STATES:
            raise SystemExit("Missing assurance applicability/evidence owner")
        if row["state"] == "accepted" and not (row["approver"] and row["accepted_evidence"]):
            raise SystemExit("Unsupported assurance acceptance")
    for row in load("software_closure")["items"]:
        if row["state"] not in STATES or not row["owner"] or not row["remaining_closure"]:
            raise SystemExit("Invalid software closure state/ownership")
        for source in row["evidence"]:
            if not (ROOT / source).exists():
                raise SystemExit(f"Missing software closure evidence: {source}")
        if row["accepted"] and not row.get("acceptance_record"):
            raise SystemExit("Unsupported software acceptance")
    if not load("hazards"):
        raise SystemExit("Missing hazard/control register")
    result = budgets(load("budgets"))
    if not result["flash_fits"]:
        raise SystemExit("Flash partitions exceed selected reference device")
    standards = load("standards")
    if not all(s["owner"] and s["url"] and s["evidence_required"] for s in standards):
        raise SystemExit("Incomplete standards tailoring matrix")
    print("Program consistency verified; physical feasibility and review acceptance remain open")


if __name__ == "__main__":
    main()
