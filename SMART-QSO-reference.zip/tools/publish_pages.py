"""Publish only the verified static website to gh-pages; leave the working source branch unchanged.

Run after repository verification. This is an explicitly requested publishing action.
The Pages build and live site must still be checked after this script returns.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from tools.check_public_site import check
from tools.check_release import check as check_release

ROOT = Path(__file__).resolve().parents[1]


def run(args, **kwargs):
    return subprocess.check_output(args, text=True, **kwargs).strip()


def main():
    check_release()
    repo = json.loads(run(["gh", "repo", "view", "--json", "nameWithOwner,visibility"], cwd=ROOT))
    if repo["visibility"] != "PUBLIC":
        raise RuntimeError("This publisher requires a public repository")
    repository = repo["nameWithOwner"]
    owner, name = repository.split("/")
    origin = f"https://{owner}.github.io"
    base = f"/{name}"
    env = {**os.environ, "SQ_PUBLIC_SITE": origin, "SQ_PUBLIC_BASE": base, "PUBLIC_SQ_STATIC": "1"}
    dist = ROOT / "software/web/public/dist"
    try:
        subprocess.run(["npm", "--prefix", "software/web", "run", "build:public"],
                       cwd=ROOT, env=env, check=True)
        checks = check(dist, base, public_only=True)
        manifest = {str(p.relative_to(dist)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted(dist.rglob("*")) if p.is_file()}
        (dist / "publication.json").write_text(json.dumps({
            "built_at_utc": datetime.now(UTC).isoformat(), "url": origin + base + "/",
            "artifacts": manifest, "scope": "Static public mission/evidence site; no command service",
            "flight_accepted": False,
        }, indent=2) + "\n")
        remote = run(["git", "remote", "get-url", "origin"], cwd=ROOT)
        ref = run(["git", "ls-remote", "--heads", remote, "gh-pages"], cwd=ROOT)
        with tempfile.TemporaryDirectory(prefix="smart-qso-pages-") as temp:
            directory = Path(temp)
            if ref:
                subprocess.run(["git", "clone", "--single-branch", "--branch", "gh-pages",
                                remote, temp], check=True)
                for path in directory.iterdir():
                    if path.name != ".git":
                        shutil.rmtree(path) if path.is_dir() else path.unlink()
            else:
                run(["git", "init", "--initial-branch=gh-pages"], cwd=directory)
                run(["git", "remote", "add", "origin", remote], cwd=directory)
            shutil.copytree(dist, directory, dirs_exist_ok=True)
            run(["git", "config", "user.name", "SMART-QSO site publishing"], cwd=directory)
            run(["git", "config", "user.email", f"{owner}@users.noreply.github.com"], cwd=directory)
            run(["git", "add", "--all"], cwd=directory)
            run(["git", "commit", "-m", "docs(site): publish reviewed mission and engineering evidence"], cwd=directory)
            commit = run(["git", "rev-parse", "HEAD"], cwd=directory)
            # HTTPS uses the existing gh credential helper without exposing a
            # token in argv or the browser, and avoids stalled SSH upload routes.
            subprocess.run(["git", "-c", "credential.helper=", "-c",
                            "credential.helper=!gh auth git-credential",
                            "-c", "http.lowSpeedLimit=1024", "-c", "http.lowSpeedTime=60",
                            "push", f"https://github.com/{repository}.git", "gh-pages"],
                           cwd=directory, check=True, timeout=180)
        pages = subprocess.run(["gh", "api", f"repos/{repository}/pages"], capture_output=True, text=True)
        if pages.returncode:
            if "404" not in pages.stderr:
                raise RuntimeError(pages.stderr)
            subprocess.run(["gh", "api", "--method", "POST", f"repos/{repository}/pages", "--input", "-"],
                           input=json.dumps({"source": {"branch": "gh-pages", "path": "/"},
                                             "build_type": "legacy"}), text=True, check=True)
        else:
            configured = json.loads(pages.stdout)
            source = configured.get("source") or {}
            if source.get("branch") != "gh-pages" or source.get("path") != "/" or configured.get("build_type") != "legacy":
                # The user's publication request authorizes the site source update;
                # only static artifacts are pushed, never the source checkout.
                subprocess.run(["gh", "api", "--method", "PUT", f"repos/{repository}/pages", "--input", "-"],
                               input=json.dumps({"source": {"branch": "gh-pages", "path": "/"},
                                                 "build_type": "legacy"}), text=True, check=True)
        out = ROOT / "output/verification/publication.json"
        out.write_text(json.dumps({"repository": repository, "branch": "gh-pages", "commit": commit,
                                   "url": origin + base + "/", "static_checks": checks,
                                   "public_artifacts": manifest, "live_verified": False,
                                   "source_branch_changed": False}, indent=2) + "\n")
        print(f"Published static branch {commit}; verify the Pages build and {origin + base}/")
    finally:
        # Restore the root-path localhost site and local console after the project-path build.
        local_env = {k: v for k, v in os.environ.items()
                     if k not in ("SQ_PUBLIC_SITE", "SQ_PUBLIC_BASE", "PUBLIC_SQ_STATIC")}
        subprocess.run(["npm", "--prefix", "software/web", "run", "build"], cwd=ROOT,
                       env=local_env, check=True)


if __name__ == "__main__":
    main()
