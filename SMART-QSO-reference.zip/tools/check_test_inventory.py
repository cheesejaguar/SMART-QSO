"""Require an explicit registration/exclusion record for every flight test source."""

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    inventory = json.loads((ROOT / "mission/current/test_inventory.json").read_text())
    if len({row["suite"] for row in inventory}) != len(inventory):
        raise SystemExit("Duplicate suite mapping hides a current source test")
    actual = {str(p.relative_to(ROOT)) for p in (ROOT / "software/flight/tests").rglob("test_*.c")}
    if actual != {r["path"] for r in inventory}:
        raise SystemExit("Uninventoried or removed flight tests")
    registered = json.loads(
        subprocess.check_output(
            ["ctest", "--test-dir", str(ROOT / "build"), "--show-only=json-v1"], text=True
        )
    )["tests"]
    names = {r["name"] for r in registered}
    for row in inventory:
        if row["registered"]:
            expected = row["suite"]
            if expected not in names:
                raise SystemExit(f"Missing registered suite: {expected}")
        else:
            raise SystemExit(f"Unexecuted current test source: {row['path']}")
    print(
        f"{len(actual)} test sources accounted for; {len(names)} registered suites; no quarantined current test sources"
    )


if __name__ == "__main__":
    main()
