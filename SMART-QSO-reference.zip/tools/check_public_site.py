"""Check static public routes, assets and anchors, including project-URL deployment."""

from __future__ import annotations

import argparse
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit


class Page(HTMLParser):
    def __init__(self, text: str):
        super().__init__()
        self.links: list[str] = []
        self.ids: set[str] = set()
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get("id"):
            self.ids.add(values["id"])
        for name in ("href", "src"):
            if values.get(name):
                self.links.append(values[name])


def check(directory: Path, base: str = "/", public_only: bool = False) -> dict:
    directory = directory.resolve()
    prefix = base.rstrip("/") + "/"
    pages = {p: Page(p.read_text()) for p in directory.rglob("*.html")}
    if not pages or not (directory / "index.html").is_file():
        raise ValueError("Static site has no home page")
    if public_only and (directory / "console").exists():
        raise ValueError("Local command console cannot be included in the public deployment")
    links = 0
    for source, parsed in pages.items():
        for link in parsed.links:
            url = urlsplit(link)
            if url.scheme or url.netloc:
                continue
            local = unquote(url.path)
            if local.startswith("/"):
                if not local.startswith(prefix):
                    raise ValueError(f"Link escapes deployment base: {source.name}: {link}")
                target = directory / local[len(prefix):]
            else:
                target = source.parent / local if local else source
            target = target.resolve()
            if not target.is_relative_to(directory):
                raise ValueError(f"Link escapes public files: {link}")
            if target.is_dir():
                target /= "index.html"
            if not target.is_file():
                raise ValueError(f"Missing public route/asset: {source.name}: {link}")
            if url.fragment and target in pages and url.fragment not in pages[target].ids:
                # The local React console owns its fragment routing.
                if not (not public_only and "console" in target.relative_to(directory).parts):
                    raise ValueError(f"Missing anchor: {source.name}: {link}")
            links += 1
    return {"html_pages": len(pages), "checked_links": links,
            "deployment_base": prefix, "public_only": public_only}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--base", default="/")
    parser.add_argument("--public-only", action="store_true")
    args = parser.parse_args()
    print(check(args.directory, args.base, args.public_only))


if __name__ == "__main__":
    main()
