"""Ground-only training from ordered JSON contact/energy records; never deploys a model."""

import argparse
import hashlib
import json
from pathlib import Path

from software.simulation.predictors import ContactEnergyModel


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--records", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.records.stat().st_size > 32 * 1024 * 1024:
        parser.error("Training input exceeds the bounded local dataset size")
    records = json.loads(args.records.read_text())
    if not isinstance(records, list):
        parser.error("Expected an ordered JSON record array")
    model = ContactEnergyModel.train(records)
    report = {
        **model.export(),
        "input_file_sha256": hashlib.sha256(args.records.read_bytes()).hexdigest(),
        "acceptance": "Ground analysis only; dataset provenance, measurement calibration, held-out validation and independent flight selection required",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
