import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const modules=process.env.RUNTIME_NODE_MODULES;
if(!modules)throw new Error('Set RUNTIME_NODE_MODULES to the bundled runtime node_modules');
const require=createRequire(path.join(modules,'package.json'));
const {Presentation,PresentationFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const root=path.resolve('.');
const runtime=process.env.ARTIFACT_RUNTIME_ROOT;
if(!runtime)throw new Error('Set ARTIFACT_RUNTIME_ROOT to bundled dependency root');
const skill=process.env.PRESENTATION_SKILL_ROOT;
if(!skill)throw new Error('Set PRESENTATION_SKILL_ROOT to the presentation skill directory');
const funding=JSON.parse(await fs.readFile(path.join(root,'mission/current/funding.json'),'utf8'));
const gates=JSON.parse(await fs.readFile(path.join(root,'mission/current/gates.json'),'utf8'));
const presentation=Presentation.create({slideSize:{width:1280,height:720}});
const colors={paper:'#fafafa',ink:'#142029',muted:'#52606c',accent:'#c64b30',rule:'#cbd0d5'};
function text(slide,value,x,y,w,h,size=24,bold=false,color=colors.ink){const shape=slide.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});shape.text=value;shape.text.style={typeface:'Arial',fontSize:size,bold,color};return shape;}
function rect(slide,x,y,w,h,color=colors.ink){return slide.shapes.add({geometry:'rect',position:{left:x,top:y,width:w,height:h},fill:color,line:{fill:'none',width:0}});}
function slide(title,subtitle=''){const s=presentation.slides.add();s.background.fill=colors.paper;text(s,'SMART-QSO',60,32,250,35,20,true);text(s,'3U REFERENCE / REPOSITORY DEMONSTRATION',655,38,565,24,14,false,colors.muted);rect(s,60,94,1160,1,colors.rule);text(s,title,60,128,1160,90,44,true);if(subtitle)text(s,subtitle,60,214,1160,65,22,false,colors.muted);rect(s,60,667,1160,1,colors.rule);text(s,'14 October 2026 / No hardware, funding, license or launch secured',60,680,1040,24,13,false,colors.muted);text(s,String(presentation.slides.items.length).padStart(2,'0'),1160,680,60,24,13,true,colors.accent);return s;}
function note(s,extra=''){s.speakerNotes.text='Sources: controlled mission/current/baseline.json, funding.json, gates.json and docs/resurrection/AUDIT_REPORT.md. '+extra;}
let s=slide('A small spacecraft.\nA wider conversation.');
text(s,'An open packet relay with bounded autonomy\nand an isolated onboard language experiment.',60,325,650,110,29,false,colors.muted);
text(s,'3U / 1200 baud / 12-month target',60,485,650,45,26,true,colors.accent);
text(s,'Funding target: $500k–$1.5m\nInitial feasibility milestone: $75k',60,555,680,70,24);
s.images.add({blob:new Uint8Array(await fs.readFile(path.join(root,'software/web/public/public/spacecraft-concept.png'))),contentType:'image/png',alt:'Unbuilt spacecraft concept illustration',fit:'contain',position:{left:745,top:250,width:460,height:390}});
note(s,'AI-generated concept illustration; no flight unit or NASA affiliation implied.');
s=slide('Useful amateur service, independently of AI','Short public messages between ordinary licensed packet stations');
const steps=[['Ground station','Radio + KISS-compatible TNC\nAX.25 UI / 1200-baud AFSK'],['Deterministic relay','32-message queue / sender quotas\nExpiry, retries and fair scheduling'],['Recipient','Later-pass delivery\nCorroborated acknowledgments']];
for(let i=0;i<3;i++){const x=60+i*395;rect(s,x,320,350,5,colors.accent);text(s,String(i+1),x,340,50,45,30,true,colors.accent);text(s,steps[i][0],x,410,350,45,28,true);text(s,steps[i][1],x,478,350,95,22,false,colors.muted);}
text(s,'A pilot public amateur service — not a commercial or emergency-critical guarantee.',60,603,1150,35,18,false,colors.muted);note(s,'Packet-radio heritage: https://www.amsat.org/amsat/ftp/articles/intro/easysat.pdf');
s=slide('The MCU owns safety','The language payload explains status; it cannot control the spacecraft');
rect(s,60,315,550,55);text(s,'ESSENTIAL SERVICE / MCU',80,327,510,35,22,true,'#ffffff');
rect(s,670,315,550,55,colors.accent);text(s,'OPTIONAL EXPERIMENT',690,327,510,35,22,true,'#ffffff');
text(s,'Signed commands and retained RF shutdown\nFactual telemetry and template beacons\nBounded queue, resource limits and watchdog\nPersistent replay floor and fail-closed storage',80,400,510,190,24);
text(s,'Read-only verified health snapshots\nDeadline and factual-grammar checks\nPower gating and deterministic fallback\nNo rewriting messages or on-orbit training',690,400,510,190,24);
note(s,'Software engineering: https://nodis3.gsfc.nasa.gov/displayDir.cfm?t=NPR&c=7150&s=2D ; software assurance/safety: https://standards.nasa.gov/standard/nasa/nasa-std-87398');
s=slide('Software evidence exists. Physical evidence is open.');
text(s,'IMPLEMENTED / HOST VERIFICATION',60,278,550,34,18,true,colors.accent);
text(s,'Shared C/Python command and relay core\nSignature, replay and corruption tests\nSigned-image validation and boot rollback\nARM reference images and local console\nControlled audit, interfaces and requirements',60,340,550,230,24);
text(s,'REQUIRED BEFORE FLIGHT',680,278,540,34,18,true,colors.accent);
text(s,'Selected hardware and real drivers\nFlatsat / RF and environmental results\nVacuum cooling and radiation assessment\nNamed independent reviews and hazard closure\nSpectrum, disposal and launch acceptance',680,340,540,230,24);
text(s,'A passing host test or compiled firmware image is not flight qualification.',60,607,1160,35,22,false,colors.muted);note(s);
s=slide('3U feasibility must close with measurements','Executable budgets expose assumptions and unresolved inputs');
const concerns=[['Energy and peak current','Cold boot, model load, inference, shutdown; battery EOL and PA efficiency'],['Thermal and radiation','Conductive vacuum cooling, correlated TVAC, selected-parts TID / SEE'],['Packaging and RF','Provider ICD, actual CAD / mass properties, antennas, sensitivity and desense'],['Disposal and control','Probabilistic five-year disposal analysis and telecommanded cessation']];
for(let i=0;i<4;i++){const y=315+i*75;rect(s,60,y,1160,1,colors.rule);text(s,concerns[i][0],60,y+16,345,40,23,true);text(s,concerns[i][1],430,y+16,790,55,21,false,colors.muted);}note(s,'47 CFR 97.207: https://www.ecfr.gov/current/title-47/chapter-I/subchapter-D/part-97/subpart-C/section-97.207 ; GEVS: https://standards.nasa.gov/standard/gsfc/gsfc-std-7000');
s=slide('Funded gates, with accountable acceptance','24–36-month readiness planning envelope; launch date remains open');
for(let i=0;i<6;i++){const x=i%3*395+60,y=Math.floor(i/3)*180+310;const gate=gates[i];rect(s,x,y,350,2,colors.accent);text(s,gate.id,x,y+18,65,35,22,true,colors.accent);text(s,gate.name,x,y+62,350,55,24,true);text(s,gate.criteria.slice(0,2).join(' / '),x,y+116,350,48,18,false,colors.muted);}note(s,'All gates require named reviewers, actual evidence and action acceptance; no historical review is accepted current evidence.');
s=slide('A planning allocation, not a validated estimate','Cash and uncommitted in-kind contributions are kept separate');
const cash=funding.allocations.reduce((sum,row)=>sum+row.cash,0),inkind=funding.allocations.reduce((sum,row)=>sum+row.in_kind,0),reserve=cash*funding.reserve_fraction;
const grouped=(ids,field)=>ids.reduce((sum,i)=>sum+funding.allocations[i][field],0); const groups=[['Engineering labor',[0]],['Bus, payload, spares and ground/GSE',[1,2]],['Facilities, assurance and regulatory',[3,6]],['Launch/integration and operations',[4,5]]];const rows=groups.map(([name,ids])=>[name,grouped(ids,'cash'),grouped(ids,'in_kind')]);rows.push(['Cash reserve (25%)',reserve,0]);
const t=s.tables.add({rows:6,columns:3,left:60,top:315,width:1160,height:270});
t.rows[0].cells[0].value='Planning category';t.rows[0].cells[1].value='Cash / USD';t.rows[0].cells[2].value='In-kind / uncommitted';
for(let i=0;i<rows.length;i++)for(let j=0;j<3;j++){t.rows[i+1].cells[j].value=j===0?rows[i][j]:`$${Number(rows[i][j]).toLocaleString('en-US')}`;}
for(let row=0;row<6;row++)for(let col=0;col<3;col++){t.getCell(row,col).text.style={typeface:'Arial',fontSize:20,color:colors.ink};} for(let row=0;row<6;row++){t.rows[row].height=45;} t.columns.get(0).width=680;t.columns.get(1).width=240;t.columns.get(2).width=240;
text(s,`Cash scenario: $${(cash+reserve).toLocaleString('en-US')}  /  In-kind: $${inkind.toLocaleString('en-US')}`,60,608,1160,40,25,true,colors.accent);note(s,'Source: mission/current/funding.json. Allocations contain no supplier quotations or secured contribution/launch commitments.');
s=slide('The first $75k buys a measurable feasibility decision');
text(s,'Measure the payload',60,295,550,45,28,true);text(s,'Full-cycle energy, thermal profiles, peak current\nand reproducible model/runtime evidence.',60,355,550,90,24,false,colors.muted);
text(s,'Demonstrate the radio service',680,295,540,45,28,true);text(s,'Real station/TNC interoperability and\nrecipient-corroborated delivery.',680,355,540,90,24,false,colors.muted);
text(s,'Establish program ownership',60,465,550,45,28,true);text(s,'Sponsoring institution, named engineers,\nindependent requirements review and quotes.',60,525,550,90,24,false,colors.muted);
text(s,'Close the 3U decision',680,465,540,45,28,true);text(s,'Measured budgets and a reviewed scope\nbefore spacecraft fabrication.',680,525,540,90,24,false,colors.muted);
note(s,'Potential launch-support eligibility route: https://www.nasa.gov/kennedy/launch-services-program/cubesat-launch-initiative/ . This is not an award or spacecraft-development funding commitment.');
await fs.mkdir(path.join(root,'.artifact-build/slides'),{recursive:true});
for(const [index,slide] of presentation.slides.items.entries()){const png=await presentation.export({slide,format:'png',scale:1});await fs.writeFile(path.join(root,`.artifact-build/slides/slide-${index+1}.png`),new Uint8Array(await png.arrayBuffer()));}
const candidate=path.join(root,'.artifact-build/candidate.pptx');await(await PresentationFile.exportPptx(presentation)).save(candidate);
const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')).href);
const result=await finalizePresentation({workspaceDir:root,candidatePath:candidate,finalPath:path.join(root,'output/presentation/SMART-QSO-funding.pptx'),pythonExecutable:path.join(runtime,'python/bin/python3'),integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit','--require-native-table-slide','7'],explicitTotalSlideCount:8,requiredNativeTableOwnerSlides:[7],fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(root,`.artifact-build/deck-validation-${Date.now()}.json`)});
console.log(JSON.stringify(result));
