"""Derive development evidence counts from actual reports without awarding acceptance."""

import hashlib
import json
import plistlib
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

from tools.check_test_reports import check_report

ROOT = Path(__file__).resolve().parents[1]


def main():
    directory = ROOT / "output/verification"
    reports = {name: check_report(directory / f"{name}.xml") for name in
               ("pytest", "pytest-python311", "ctest", "sanitizers", "sanitizers-all")}
    misra = json.loads((directory / "misra-status.json").read_text())
    if misra["actionable_findings"]:
        raise RuntimeError("Unresolved actionable MISRA findings")
    cpp = {name: len(list(ET.parse(directory / name).iter("error"))) for name in
           ("cppcheck.xml", "cppcheck-legacy.xml")}
    if any(cpp.values()):
        raise RuntimeError("Unresolved standard Cppcheck diagnostics")
    analyzer = list((directory / "analyzer").glob("*.plist"))
    if len(analyzer) != 10 or any(plistlib.loads(p.read_bytes())["diagnostics"] for p in analyzer):
        raise RuntimeError("Missing/failed Clang analyzer evidence")
    arm = json.loads((directory / "arm-analyzer.json").read_text())["results"]
    if not arm or any(row["exit_code"] or row["diagnostics"] for row in arm):
        raise RuntimeError("Missing/failed ARM compiler analysis")
    for name in ("pip-audit.json", "pip-audit-python311.json"):
        if any(row["vulns"] for row in json.loads((directory / name).read_text())["dependencies"]):
            raise RuntimeError("Unresolved active Python dependency advisories")
    if json.loads((directory / "npm-audit.json").read_text())["metadata"]["vulnerabilities"]["total"]:
        raise RuntimeError("Unresolved npm dependency advisories")
    coverage = ET.parse(directory / "coverage.xml").getroot().attrib
    # Record explicit scopes. These reports do not prove hardware execution, MC/DC,
    # software classification or independence of their producing development agent.
    record = {
        "recorded_at_utc": datetime.now(UTC).isoformat(),
        "scope": "Local development verification; no hardware execution, independent acceptance or NASA compliance determination",
        "junit_reports": reports,
        "report_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                          directory.glob("*.xml")},
        "pytest": {"passed": reports["pytest"]["tests"], "skipped": 0,
                   "python_versions": ["3.11 (isolated)", "3.12"], "warnings": []},
        "ctest": {"passed": reports["ctest"]["tests"], "production_core_suites": 17,
                  "legacy_host_suites": 14, "quarantined_current_sources": 0},
        "sanitizers": {"production_only_suites": reports["sanitizers"]["tests"],
                       "all_current_suites": reports["sanitizers-all"]["tests"],
                       "types": ["address", "undefined behavior"]},
        "analysis": {"Clang_analyzer_modules": len(analyzer), "diagnostics": 0,
                     "standard_cppcheck": cpp, "MISRA_actionable_owned_portable": 0,
                     "MISRA_context_diagnostics": misra["context_findings"],
                     "MISRA_checker_exit_code": misra["checker_exit_code"],
                     "MISRA_verified": False, "MISRA_deviations_accepted": False,
                     "ARM_analyzer_translation_units": len(arm),
                     "ARM_analyzer_distinct_files": len({row["path"] for row in arm})},
        "coverage": {**coverage,
                     "scope": "Ten portable/host modules; native production suites plus Python on instrumented shared library; unreachable branches excluded",
                     "MC_DC_verified": False, "BSP_RTOS_or_vendor_coverage": False},
        "dependency_audits": "No known advisories in active locked Python 3.11/3.12 and npm package scans; not full vendor/license acceptance",
        "arm_reference": {"images": 4, "hardware_executed": False, "keys_provisioned": False},
        "acceptance": {"hardware": False, "independent_review": False, "NASA_compliance": False},
        "public_web_evidence": "output/verification/publication.json and live-public-qa.json are produced separately after publishing; their presence is not flight evidence",
        "quality_and_artifact_scope": "Ruff/mypy, generated protocol, program consistency, clean notebook and root/project web builds rerun by development agent; see FINAL_REVIEW.md. These are not independently accepted reviews.",
    }
    (directory / "verification.json").write_text(json.dumps(record, indent=2) + "\n")
    print("Derived verification summary from actual test/analysis/advisory reports; acceptance remains false")


if __name__ == "__main__":
    main()
