"""Generate local development credentials with exclusive owner-only files."""

import argparse
import os
import secrets
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)


def exclusive(path: Path, value: bytes):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(value)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(".state/operator"))
    args = parser.parse_args()
    args.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    key = Ed25519PrivateKey.generate()
    exclusive(
        args.directory / "signer.pem",
        key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()),
    )
    exclusive(args.directory / "token", secrets.token_urlsafe(32).encode())
    (args.directory / "public-key.hex").write_text(
        key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex() + "\n"
    )
    print(
        "Development credentials created with owner-only permissions. Existing files are never overwritten."
    )
    print(f"Key directory: {args.directory.resolve()}")


if __name__ == "__main__":
    main()
