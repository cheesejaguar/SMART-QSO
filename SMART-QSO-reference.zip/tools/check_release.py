"""Verify the development ZIP, all source/artifact digests and its current-source boundary."""

from __future__ import annotations

import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def check(root: Path = ROOT) -> dict:
    release = root / "output/release"
    manifest = json.loads((release / "manifest.json").read_text())
    if not manifest["source_tree_included"] or any(manifest[name] for name in
        ("flight_accepted", "hardware_execution_verified", "misra_compliance_verified")):
        raise ValueError("Development release contains unsupported acceptance")
    actual = set(subprocess.check_output(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard"], cwd=root, text=True
    ).splitlines())
    actual = {p for p in actual if (root / p).is_file()
              and not p.startswith(("output/", ".impeccable/"))
              and p not in ("mission/current/artifact_inventory.json", "docs/resurrection/AUDIT_REPORT.md")}
    if actual != {row["path"] for row in manifest["source_files"]}:
        raise ValueError("Release source inventory is stale")
    def digest(data):
        return hashlib.sha256(data).hexdigest()
    if digest(json.dumps(manifest["source_files"], sort_keys=True).encode()) != manifest["source_tree_sha256"]:
        raise ValueError("Release source fingerprint is inconsistent")
    with zipfile.ZipFile(release / "SMART-QSO-reference.zip") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or archive.testzip() is not None:
            raise ValueError("Duplicate or corrupt archive entries")
        for name in names:
            path = Path(name)
            if path.is_absolute() or ".." in path.parts or ".state" in path.parts or path.suffix in (".pem", ".key") or path.name == ".env":
                raise ValueError(f"Unsafe/operational archive path: {name}")
        for row in manifest["artifacts"] + manifest["source_files"]:
            name = row["path"]
            if digest((root / name).read_bytes()) != row["sha256"] or digest(archive.read(name)) != row["sha256"]:
                raise ValueError(f"Stale release artifact/source: {name}")
        if archive.read("output/release/manifest.json") != (release / "manifest.json").read_bytes():
            raise ValueError("Archived manifest differs from checksum authority")
    for line in (release / "checksums.sha256").read_text().splitlines():
        expected, name = line.split("  ", 1)
        if digest((release / name).read_bytes()) != expected:
            raise ValueError(f"Checksum mismatch: {name}")
    return {"source_files": len(actual), "artifacts": len(manifest["artifacts"]),
            "source_tree_sha256": manifest["source_tree_sha256"], "integrity_verified": True,
            "flight_accepted": False}


if __name__ == "__main__":
    print(check())
