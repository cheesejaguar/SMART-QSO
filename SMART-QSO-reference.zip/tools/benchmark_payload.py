"""Record actual model hash/latency; require a measured power trace for energy claims."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

from software.payload.bounded_worker import generate
from software.payload.policy import HealthSnapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--license", required=True)
    parser.add_argument(
        "--power-trace", type=Path, help="Measured whole-cycle CSV: elapsed_s,power_w"
    )
    parser.add_argument("--deadline", type=float, default=20)
    parser.add_argument("--gpu-layers", type=int, default=0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    digest = hashlib.file_digest(args.model.open("rb"), "sha256").hexdigest()
    report = generate(
        str(args.model),
        HealthSnapshot(1, 0, 760, "IDLE", True, False),
        0,
        args.deadline,
        args.gpu_layers,
    )
    report.update(
        model_sha256=digest,
        model_bytes=args.model.stat().st_size,
        license=args.license,
        hardware_identity="operator must attach board/carrier/power-meter calibration evidence",
        provenance="local software measurement; not a flight or radiation result",
    )
    if args.power_trace:
        with args.power_trace.open() as stream:
            rows = list(csv.DictReader(stream))
        samples = [(float(r["elapsed_s"]), float(r["power_w"])) for r in rows]
        if (
            len(samples) < 2
            or any(not math.isfinite(t) or not math.isfinite(w) for t, w in samples)
            or samples[0][0] > 0
            or samples[-1][0] < report["elapsed_s"]
            or any(
                b[0] <= a[0] or a[1] < 0 or b[1] < 0
                for a, b in zip(samples, samples[1:], strict=False)
            )
        ):
            parser.error(
                "Power trace must cover the whole measured cycle with increasing times and nonnegative watts"
            )
        report["energy_j"] = sum(
            (b[0] - a[0]) * (a[1] + b[1]) / 2 for a, b in zip(samples, samples[1:], strict=False)
        )
        report["power_trace_sha256"] = hashlib.file_digest(
            args.power_trace.open("rb"), "sha256"
        ).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
