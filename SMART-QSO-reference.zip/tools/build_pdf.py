"""Build the source-backed mission funding proposal using ReportLab."""

import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output/pdf/SMART-QSO-proposal.pdf"
DATA = ROOT / "mission/current"
C = colors.HexColor("#142029")
A = colors.HexColor("#c64b30")
M = colors.HexColor("#52606c")
RULE = colors.HexColor("#cbd0d5")
styles = getSampleStyleSheet()
styles.add(
    ParagraphStyle(
        name="TitleSQ",
        fontName="Helvetica-Bold",
        fontSize=34,
        leading=38,
        textColor=C,
        spaceAfter=22,
    )
)
styles.add(
    ParagraphStyle(
        name="HeadingSQ",
        fontName="Helvetica-Bold",
        fontSize=22,
        leading=27,
        textColor=C,
        spaceAfter=16,
    )
)
styles.add(
    ParagraphStyle(
        name="BodySQ", fontName="Helvetica", fontSize=10.5, leading=16, textColor=M, spaceAfter=12
    )
)
styles.add(
    ParagraphStyle(name="SmallSQ", fontName="Helvetica", fontSize=8, leading=12, textColor=M)
)
styles.add(
    ParagraphStyle(
        name="LabelSQ", fontName="Courier", fontSize=9, leading=12, textColor=A, spaceAfter=10
    )
)


def load(name):
    return json.loads((DATA / f"{name}.json").read_text())


def p(text, style="BodySQ"):
    return Paragraph(text, styles[style])


def table(headers, rows, widths):
    data = [[p(escape(str(value)), "SmallSQ") for value in row] for row in [headers] + rows]
    result = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    result.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), C),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("LINEBELOW", (0, 0), (-1, 0), 1, A),
                ("LINEBELOW", (0, 1), (-1, -1), 0.4, RULE),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    # Paragraph colors need their own header style.
    for index, value in enumerate(headers):
        data[0][index] = Paragraph(
            escape(str(value)),
            ParagraphStyle(
                name=f"header{index}",
                fontName="Helvetica-Bold",
                fontSize=8,
                leading=12,
                textColor=colors.white,
            ),
        )
    result = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    result.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), C),
                ("LINEBELOW", (0, 0), (-1, 0), 1, A),
                ("LINEBELOW", (0, 1), (-1, -1), 0.4, RULE),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        )
    )
    return result


def footer(canvas, doc):
    canvas.setStrokeColor(RULE)
    canvas.line(48, 42, 564, 42)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(M)
    canvas.drawString(
        48, 29, "SMART-QSO | 3U reference mission | Repository demonstration | 14 October 2026"
    )
    canvas.drawRightString(564, 29, str(doc.page))


def main():
    funding = load("funding")
    gates = load("gates")
    cash = sum(r["cash"] for r in funding["allocations"])
    inkind = sum(r["in_kind"] for r in funding["allocations"])
    reserve = int(cash * funding["reserve_fraction"])
    story = [
        p("SMART-QSO", "LabelSQ"),
        p("A small spacecraft.<br/>A wider conversation.", "TitleSQ"),
        p(
            "An open 3U packet relay with bounded autonomy and an isolated onboard language experiment."
        ),
        Image(
            str(ROOT / "software/web/public/public/spacecraft-concept.png"),
            width=3.7 * inch,
            height=3.7 * inch,
            kind="proportional",
        ),
        p(
            "Concept illustration. No flight unit, NASA affiliation, qualification or secured launch is implied.",
            "SmallSQ",
        ),
        Spacer(1, 14),
        p("Funding target: $500k-$1.5m. Initial feasibility milestone: $75k.", "HeadingSQ"),
        p(
            "Prepared for educational/nonprofit sponsors, amateur-radio partners and technology-research funders. All cost allocations and hardware budgets remain subject to quotations and measured closure."
        ),
        PageBreak(),
    ]
    story += [
        p("A useful service with a testable research case", "HeadingSQ"),
        p(
            "SMART-QSO stores short public messages from licensed amateur stations and relays them to recipients during later contacts. It starts with ordinary AX.25/1200-baud AFSK and KISS-compatible station equipment. This is a pilot amateur service and an open research platform, not a commercial or emergency-critical communications promise."
        ),
        p(
            "The deterministic MCU controls packet capacity, fairness, retries, power limits and radio inhibits. Small predictors may recommend resource use within those limits. The separate language computer can explain verified health but cannot command the spacecraft or rewrite user messages."
        ),
        table(
            ["Service level", "Measured success target"],
            [
                [
                    "Minimum",
                    "30 days of commissioning, verified telecommand, safe fallback and independent-station delivery",
                ],
                [
                    "Full",
                    "1,000 corroborated acknowledged messages; 20 stations; 3 regions; 90 days",
                ],
                [
                    "Research",
                    "Matched delivered-message/Wh comparison, uncertainty analysis and zero safety-limit violations",
                ],
                ["Extended", "12 months of useful operations and reproducible engineering results"],
            ],
            [110, 406],
        ),
        Spacer(1, 18),
        p("What makes the program worth supporting", "HeadingSQ"),
        p(
            "A compatible public service gives the mission an observable purpose. The autonomy experiment has a conventional baseline and charges compute energy to its own benefit claim. Open protocols, source code, engineering evidence and public results let schools and clubs participate and let reviewers distinguish software demonstrations from flight readiness."
        ),
        p(
            "Existing packet satellites and onboard-AI experiments are part of the comparison, not achievements to erase with a first-of-its-kind claim. Community adoption, measured energy benefit and rigorous failure containment are the research questions."
        ),
        PageBreak(),
    ]
    story += [
        p("Safety has a separate owner", "HeadingSQ"),
        table(
            ["MCU / essential service", "Optional language payload"],
            [
                [
                    "Safety limits, watchdog and persistent state",
                    "Read-only verified health snapshots",
                ],
                [
                    "Relay scheduling and public message integrity",
                    "Constrained status explanation only",
                ],
                [
                    "Factual telemetry and template beacons",
                    "Deadline, freshness, ASCII and factuality validation",
                ],
                [
                    "Signed telecommands and retained RF shutdown",
                    "Power-gated; failure returns to templates",
                ],
            ],
            [258, 258],
        ),
        Spacer(1, 18),
        p("Command and update assurance"),
        p(
            "Ed25519 authentication is distinct from readable radio content. The shared C core rejects invalid signatures and replay, commits the replay floor before accepting control, and fails closed on storage faults. Signed firmware manifests bind version, length and content. Reference boot trials and rollback are tested on the host; physical write protection, power-cut behavior and board acceptance remain open."
        ),
        p(
            "Reference firmware enforces SAFE/RF OFF when verified EPS input is unavailable. Hardware execution remains unverified; a compiling ARM image does not demonstrate a working spacecraft interface."
        ),
        p("NASA-aligned process", "HeadingSQ"),
        p(
            "NPR 7150.2D and NASA-STD-8739.8B supply software-engineering, assurance and safety tailoring inputs. Mission risk class, software classification and safety criticality require separate assessment. Requirement-level evidence, independent review and accepted tailoring are necessary before any compliance declaration."
        ),
        PageBreak(),
    ]
    story += [
        p("3U feasibility is the first physical gate", "HeadingSQ"),
        p(
            "The mass, volume, energy, flash, RF and data budgets are executable, share one source of assumptions and explicitly report unclosed feasibility. Estimated positive margins are not measured hardware results."
        ),
        table(
            ["Budget", "Evidence required before closure"],
            [
                [
                    "Power / current",
                    "Whole cold-boot/model-load/inference/shutdown cycle; RF PA efficiency; inrush; battery cycling and EOL",
                ],
                [
                    "Thermal / radiation",
                    "Conductive vacuum cooling, correlated hot/cold model, TVAC and selected-parts TID/SEE/latch-up assessment",
                ],
                [
                    "Mechanical / volume",
                    "Supplier CAD, deployer ICD, tolerance stacks, mass/CG/inertia, structural and mechanism tests",
                ],
                [
                    "RF / service",
                    "Measured sensitivity/gain/emissions, modem interoperability, Doppler/desense, realistic contact exposure",
                ],
                [
                    "Disposal / safety",
                    "Accepted probabilistic lifetime and reentry/collision analysis; independent passivation and launch inhibits",
                ],
            ],
            [126, 390],
        ),
        Spacer(1, 18),
        p("Design boundaries"),
        p(
            "Keep the 3U reference fixed until a documented scope decision. Prefer selected heritage bus components and make custom design sources, exact parts, harness interfaces and manufacturing inspection records explicit. The parametric packaging file is a concept envelope, not a fabrication package."
        ),
        p(
            "The amateur space-station control path must demonstrate telecommanded cessation. Current 47 CFR 97.207 includes a five-year post-mission disposal criterion for applicable LEO spacecraft. Orbit selection and uncertainty analysis must support that requirement; a blanket historical 25-year assumption is superseded."
        ),
        PageBreak(),
    ]
    story += [
        p("A program advanced by evidence", "HeadingSQ"),
        table(
            ["Gate", "Required evidence"],
            [[g["name"], "; ".join(g["criteria"])] for g in gates],
            [144, 372],
        ),
        Spacer(1, 15),
        p(
            "Readiness planning envelope: 24-36 months after staffing and funding assumptions are validated. This is not a promised launch date. Qualification facilities, supplier lead times, institutional reviews and launch opportunities determine the critical path."
        ),
        p(
            "The team is not yet staffed. Named accountable owners are required for program management, systems, RF/licensed operations, EPS/avionics, mechanics/thermal/radiation, flight software, payload/ground, assurance and integration/operations."
        ),
        PageBreak(),
    ]
    story += [
        p("Funding allocations and the first ask", "HeadingSQ"),
        p(
            f"Illustrative allocations only. Base cash: ${cash:,}. Cash reserve (25%): ${reserve:,}. Total cash scenario: ${cash + reserve:,}. Uncommitted in-kind contributions: ${inkind:,}. Neither quotes nor partner commitments are secured."
        ),
        table(
            ["Category", "Cash allocation", "In-kind, uncommitted"],
            [
                [r["category"], f"${r['cash']:,}", f"${r['in_kind']:,}"]
                for r in funding["allocations"]
            ]
            + [["Cash reserve", f"${reserve:,}", "Not assigned"]],
            [276, 120, 120],
        ),
        Spacer(1, 18),
        p("Initial feasibility milestone: $75,000", "HeadingSQ"),
        p(
            "Deliver calibrated payload-cycle energy/thermal profiles; real station/TNC interoperability; preliminary 3U budgets with uncertainties; a sponsoring institution and named subsystem owners; independent requirements review; and a supplier quote log."
        ),
        p(
            "NASA CubeSat Launch Initiative may provide a launch-support route for eligible educational/nonprofit organizations. It is not an award, a launch commitment or spacecraft-development funding in this proposal. Scope, eligibility and cost must be reviewed against the actual opportunity."
        ),
        PageBreak(),
    ]
    story += [
        p("Evidence, sources and open work", "HeadingSQ"),
        p(
            "The repository contains the complete audit inventory and finding register, controlled baseline, requirements, work packages, standards tailoring matrix, software tests, reference firmware, ground demo, verification campaign and research protocol. Historical reviews remain accessible but explicitly unverified."
        ),
        p(
            "Outstanding physical work includes selected hardware/driver integration, fabrication sources, flatsat and engineering model, calibrated RF/environmental/radiation testing, hazard closure, named independent reviews, licensing/coordination, launch acceptance and commissioning."
        ),
        table(
            ["Source", "Reference"],
            [
                ["Software engineering", "nodis3.gsfc.nasa.gov - NPR 7150.2D"],
                ["Software assurance / safety", "standards.nasa.gov - NASA-STD-8739.8B"],
                ["Environmental guidance", "standards.nasa.gov - GSFC-STD-7000B (GEVS)"],
                ["Amateur space station control / disposal", "ecfr.gov - 47 CFR 97.207"],
                ["Amateur permissible service", "ecfr.gov - 47 CFR 97.113"],
                [
                    "Launch support eligibility",
                    "nasa.gov/kennedy/launch-services-program/cubesat-launch-initiative/",
                ],
                [
                    "Program and engineering evidence",
                    "mission/current/; docs/resurrection/; output/verification/",
                ],
            ],
            [185, 331],
        ),
        Spacer(1, 20),
        p("Next decision", "HeadingSQ"),
        p(
            "Fund the measurable feasibility gate, establish institutional ownership and review the resulting evidence before committing to spacecraft fabrication. The value of the project is a useful service and an honest experiment whose safety, benefit and maturity can be inspected."
        ),
    ]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(OUT),
        pagesize=(612, 792),
        leftMargin=48,
        rightMargin=48,
        topMargin=50,
        bottomMargin=60,
        title="SMART-QSO funding proposal",
        author="SMART-QSO contributors",
    )
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print(OUT)


if __name__ == "__main__":
    main()
