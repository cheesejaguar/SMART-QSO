"""Import clause references from downloaded authoritative NPR/standard source files.

Use an HTML copy of NPR 7150.2D Appendix C and a text extraction of NASA-STD-8739.8B.
References retain class applicability; no project tailoring or compliance is accepted here.
"""

import argparse
import hashlib
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("appendix_html", type=Path)
    parser.add_argument("assurance_text", type=Path)
    args = parser.parse_args()
    source = args.appendix_html.read_text()
    rows = []
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", source, re.S | re.I):
        cells = [
            html.unescape(re.sub("<[^>]+>", " ", c)).strip()
            for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)
        ]
        cells = [" ".join(c.split()) for c in cells]
        if len(cells) != 12 or not re.fullmatch(r"\d{3}", cells[1]):
            continue
        section, swe = cells[:2]
        owner = (
            "Program manager"
            if section.startswith(("3.1", "3.2", "3.3", "3.4"))
            else "Independent software assurance lead"
            if section.startswith(("3.5", "3.6", "3.7", "5.3"))
            else "Flight / payload / ground software leads"
        )
        rows.append(
            {
                "id": "SWE-" + swe,
                "standard": "NPR 7150.2D",
                "section": section,
                "source_url": "https://nodis3.gsfc.nasa.gov/displayDir.cfm?Internal_ID=N_PR_7150_002D_&page_name=AppendixC",
                "source_class_applicability": dict(
                    zip(
                        "ABCDEF",
                        [cells[4], cells[5], cells[6], cells[7], cells[8], cells[11]],
                        strict=True,
                    )
                ),
                "source_authority_A_E": cells[3],
                "source_authority_F": cells[10],
                "owner": owner,
                "components": ["flight", "payload", "ground"],
                "decision": "Pending formal classification and independent applicability assessment; retain until accepted tailoring",
                "tailoring_rationale": None,
                "approver": None,
                "state": "proposed",
                "candidate_artifacts": [
                    "mission/current/requirements.json",
                    "docs/resurrection/VERIFICATION_CAMPAIGN.md",
                ],
                "accepted_evidence": [],
                "closure_criteria": "Assess the referenced requirement and all subparts per component; link verified artifacts and reviews; accept tailoring through designated authority",
            }
        )
    if len(rows) < 80:
        raise SystemExit("Incomplete NPR mapping extraction")
    text = args.assurance_text.read_text()
    ids = sorted(
        set(re.findall(r"^\s*(4\.4\.2\.\d+)\s+The", text, re.M)),
        key=lambda s: int(s.rsplit(".", 1)[1]),
    )
    if len(ids) != 49:
        raise SystemExit("Incomplete IV&V clause extraction")
    assurance_ids = sorted(set(re.findall(r"^\s*\d+\.\d+(?:\.\d+)?\s+(\d{3}[a-d]?)\s", text, re.M)))
    if len(assurance_ids) != 103:
        raise SystemExit("Incomplete Table 1 activity extraction")
    refs = (
        ["4.3 / SASS-01"]
        + [f"4.3 Table 1 / SWE-{identifier}" for identifier in assurance_ids]
        + ids
    )
    for ref in refs:
        rows.append(
            {
                "id": "SASS-"
                + ref.replace("4.3 Table 1 / ", "").replace("4.3 / ", "").replace("4.4.2.", "IVV-"),
                "standard": "NASA-STD-8739.8B",
                "section": ref,
                "source_url": "https://standards.nasa.gov/standard/nasa/nasa-std-87398",
                "owner": "Independent software assurance / IV&V lead",
                "components": ["flight", "payload", "ground"],
                "decision": "Table 1 activities follow accepted engineering applicability; IV&V scope/selection pending independent determination",
                "tailoring_rationale": None,
                "approver": None,
                "state": "proposed",
                "candidate_artifacts": [
                    "mission/current/requirements.json",
                    "mission/current/hazards.json",
                    "docs/resurrection/VERIFICATION_CAMPAIGN.md",
                ],
                "accepted_evidence": [],
                "closure_criteria": "Assess all subtasks under the cited clause; execute approved assurance or IV&V scope and retain independent acceptance",
            }
        )
    output = {
        "retrieved_on": "2026-10-14",
        "source_hashes": {
            "NPR Appendix C HTML": hashlib.sha256(args.appendix_html.read_bytes()).hexdigest(),
            "8739.8B text extraction": hashlib.sha256(args.assurance_text.read_bytes()).hexdigest(),
        },
        "classification_status": "Unaccepted; software classification, safety criticality and mission risk are separate determinations",
        "matrix_scope": "All NPR Appendix C SWE rows; Table 1 companion activities and all 49 IV&V clauses. Individual subtask acceptance is required before compliance claims.",
        "requirements": rows,
    }
    (ROOT / "mission/current/standards_tailoring.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    print(f"{len(rows)} clause/activity references imported; no accepted tailoring")


if __name__ == "__main__":
    main()
