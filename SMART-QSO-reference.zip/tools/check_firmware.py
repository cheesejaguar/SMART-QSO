"""Check that firmware evidence is ARM, contains no simulation HAL, and fits slots."""

import argparse
import json
import re
import struct
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build", type=Path)
    args = parser.parse_args()
    compiled = json.loads((args.build / "compile_commands.json").read_text())
    if any("/hal_sim.c" in row["file"] or "/src/main.c" in row["file"] for row in compiled):
        raise SystemExit("Simulation/legacy application is linked into firmware")
    if not all("arm-none-eabi" in row["command"] for row in compiled):
        raise SystemExit("Host compiler detected in firmware build")
    names = [
        "smart_qso_boot",
        "smart_qso_reference",
        "smart_qso_reference_b",
        "smart_qso_reference_recovery",
    ]
    for name in names:
        elf = args.build / "platform/stm32l476" / f"{name}.elf"
        data = elf.read_bytes()
        if data[:4] != b"\x7fELF" or struct.unpack_from("<H", data, 18)[0] != 40:
            raise SystemExit(f"Not an ARM ELF: {elf}")
        binary = args.build / f"{name}.bin"
        maximum = (
            65536
            if name == "smart_qso_boot"
            else 126 * 1024
            if name.endswith("recovery")
            else 382 * 1024
        )
        if not 0 < binary.stat().st_size <= maximum:
            raise SystemExit(f"Image exceeds slot: {name}")
        link_map = (args.build / f"{name}.map").read_text()
        if re.search(r"\b(hal_sim|pvPortMalloc|vPortFree)\b", link_map):
            raise SystemExit("Simulation/dynamic RTOS allocation in firmware")
    print(
        "Four ARM reference images and maps verified; no hardware execution or qualification implied"
    )


if __name__ == "__main__":
    main()
