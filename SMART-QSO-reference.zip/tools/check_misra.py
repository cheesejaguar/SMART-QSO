"""Inventory partial MISRA findings; reject checker errors and untracked diagnostics.

This check never approves deviations or awards MISRA compliance. Flight acceptance
requires a complete selected ruleset and independent dispositions of all findings.
"""

import argparse
import ast
import json
import re
import subprocess
import xml.etree.ElementTree as ET
from collections import Counter
from functools import lru_cache
from pathlib import Path

BASELINE = Path("mission/current/misra_findings.json")
SOURCE_SHA = "d74945deb2d50393430e07596b766f8a779512c7f60dac2a30ea64e059ece57b"


@lru_cache(maxsize=256)
def external_references(symbol: str, definition: str) -> list[dict]:
    """Verify real source references omitted by this C-only core scan."""
    references = []
    sources = list(Path("software/flight").rglob("*.c"))
    for folder in ("common", "ground", "payload", "simulation"):
        sources.extend(Path("software", folder).rglob("*.py"))
    for source in sources:
        name = source.as_posix()
        if name == definition or "/vendor/" in name:
            continue
        text = source.read_text()
        if source.suffix == ".c":
            code = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"', "", text, flags=re.S)
            used = bool(re.search(r"\b" + re.escape(symbol) + r"\b", code))
            kind = "C source consumer"
        else:
            tree = ast.parse(text)
            used = any(
                isinstance(node, ast.Attribute) and node.attr == symbol for node in ast.walk(tree)
            )
            for node in ast.walk(tree):
                if (
                    isinstance(node, ast.Call)
                    and isinstance(node.func, ast.Name)
                    and node.func.id == "getattr"
                    and len(node.args) >= 2
                ):
                    used = used or (
                        isinstance(node.args[1], ast.Constant) and node.args[1].value == symbol
                    )
                if isinstance(node, ast.For):
                    targets = {
                        item.id for item in ast.walk(node.target) if isinstance(item, ast.Name)
                    }
                    iterates_symbol = any(
                        isinstance(item, ast.Constant) and item.value == symbol
                        for item in ast.walk(node.iter)
                    )
                    looks_up_target = any(
                        isinstance(item, ast.Call)
                        and isinstance(item.func, ast.Name)
                        and item.func.id == "getattr"
                        and len(item.args) >= 2
                        and isinstance(item.args[1], ast.Name)
                        and item.args[1].id in targets
                        for statement in node.body
                        for item in ast.walk(statement)
                    )
                    used = used or (iterates_symbol and looks_up_target)
            kind = "Python ctypes binding/consumer"
        if used:
            references.append({"path": name, "kind": kind})
    return sorted(references, key=lambda row: row["path"])


def disposition(rule: str, path: str, line: int) -> dict:
    text = Path(path).read_text().splitlines()[line - 1]
    result = {
        "actionable": True,
        "disposition": "requires_code_correction",
        "external_references": [],
    }
    if rule == "8.7" and path.startswith("software/flight/core/"):
        match = re.search(r"\b(sq_[A-Za-z0-9_]+)\s*\(", text)
        if match:
            references = external_references(match[1], path)
            if references:
                result = {
                    "actionable": False,
                    "disposition": "external_consumer_verified",
                    "symbol": match[1],
                    "external_references": references,
                    "rationale": "The C-only core scan omits target entrypoints and Python ABI consumers. External linkage is required by the referenced callers; making this static would break the verified interface.",
                }
    if rule == "2.5" and path == "software/flight/vendor/monocypher.h":
        if text.strip() in (
            "#define CRYPTO_ARGON2_D  0",
            "#define CRYPTO_ARGON2_I  1",
            "#define CRYPTO_ARGON2_ID 2",
        ):
            result = {
                "actionable": False,
                "disposition": "unused_third_party_api_constant",
                "external_references": [
                    {
                        "path": "software/flight/vendor/MONOCYPHER_LICENSE.md",
                        "kind": "Pinned unchanged third-party component",
                    }
                ],
                "rationale": "Public constants for an unused Argon2 API in the pinned vendor header; not an unused project definition. Vendor assurance and complete ruleset assessment remain independent work.",
            }
    return result


def scan(checker: Path, addon: Path) -> dict:
    report = Path("output/verification/misra.xml")
    report.parent.mkdir(parents=True, exist_ok=True)
    cache = Path(".artifact-build/cppcheck-misra")
    cache.mkdir(parents=True, exist_ok=True)
    command = [
        str(checker),
        "--language=c",
        "--std=c11",
        "--platform=unix32",
        "-UMONOCYPHER_CPP_NAMESPACE",
        "--enable=style",
        "--error-exitcode=2",
        "--suppress=missingIncludeSystem",
        f"--addon={addon}",
        f"--cppcheck-build-dir={cache}",
        "-Isoftware/flight/core",
        "-Isoftware/flight/vendor",
        "--xml",
        "--xml-version=2",
        "software/flight/core",
    ]
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    report.write_text(result.stderr)
    (report.parent / "misra-checker.log").write_text(result.stdout)
    try:
        errors = ET.fromstring(result.stderr).findall("./errors/error")
    except ET.ParseError as exc:
        raise RuntimeError("MISRA checker did not produce a valid report") from exc
    unexpected = [e.attrib for e in errors if not e.get("id", "").startswith("misra-c2012-")]
    if unexpected or result.returncode not in (0, 2):
        raise RuntimeError(
            f"Checker errors are not suppressible: {result.returncode}: {unexpected}"
        )
    unique = {}
    for error in errors:
        for location in error.findall("location"):
            file = location.get("file", "")
            if not file.startswith(("software/flight/core/", "software/flight/vendor/")):
                raise RuntimeError(f"Untracked diagnostic scope: {file}")
            rule = error.attrib["id"].removeprefix("misra-c2012-")
            line = int(location.attrib["line"])
            identity = f"{file}:{line}:{rule}"
            unique[identity] = {
                "id": identity,
                "rule": rule,
                "evidence": {"path": file, "line": line},
                "severity": error.attrib["severity"],
                "mission_consequence": "Unreviewed rule nonconformance blocks assurance acceptance; assess functional/safety impact per path",
                "dependencies": [
                    "Software classification",
                    "Complete selected MISRA ruleset",
                    "Independent assurance review",
                ],
                **disposition(rule, file, line),
                "state": "host-tested"
                if not disposition(rule, file, line)["actionable"]
                else "proposed",
                "owner": "Software assurance lead",
                "accepted": False,
                "corrective_action": "Assess applicability; correct code or submit a justified deviation",
                "closure_criteria": "Independent review of rule applicability and correction/deviation evidence",
            }
    findings = sorted(unique.values(), key=lambda f: f["id"])
    return {
        "checker": "Cppcheck 2.22.0 partial MISRA C:2012 addon",
        "source_sha256": SOURCE_SHA,
        "checker_exit_code": result.returncode,
        "configuration": "C11 unix32; owned portable modules and host ABI; target entrypoint/board, RTOS and vendor implementation are separate analysis scopes",
        "misra_diagnostics_suppressed": False,
        "non_misra_header_lookup_filter": "missingIncludeSystem; standard library modeled by Cppcheck",
        "actionable_findings": sum(f["actionable"] for f in findings),
        "context_findings": sum(not f["actionable"] for f in findings),
        "compliance_verified": False,
        "deviations_accepted": False,
        "full_rule_texts_supplied": False,
        "independent_review_completed": False,
        "rules": dict(sorted(Counter(f["rule"] for f in findings).items())),
        "findings": findings,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, required=True)
    parser.add_argument("--addon", type=Path, required=True)
    parser.add_argument("--refresh", action="store_true")
    parser.add_argument("--require-accepted", action="store_true")
    args = parser.parse_args()
    version = subprocess.check_output([str(args.checker), "--version"], text=True).strip()
    if version != "Cppcheck 2.22.0":
        raise RuntimeError(f"Uncontrolled checker: {version}")
    record = scan(args.checker, args.addon)
    if args.refresh:
        BASELINE.write_text(json.dumps(record, indent=2) + "\n")
    else:
        baseline = json.loads(BASELINE.read_text())
        expected = {f["id"] for f in baseline["findings"]}
        actual = {f["id"] for f in record["findings"]}
        if actual != expected:
            raise RuntimeError(
                f"MISRA inventory drift: added {len(actual - expected)}, removed {len(expected - actual)}"
            )
    Path("output/verification/misra-status.json").write_text(json.dumps(record, indent=2) + "\n")
    print(
        f"{record['actionable_findings']} actionable, {record['context_findings']} evidenced context/vendor diagnostics; raw checker exit {record['checker_exit_code']}; compliance unaccepted"
    )
    if record["actionable_findings"] and not args.refresh:
        raise RuntimeError("Unresolved actionable MISRA findings fail the development gate")
    if args.require_accepted:
        raise RuntimeError(
            "Flight assurance gate unaccepted: complete ruleset, tailoring and independent dispositions required"
        )


if __name__ == "__main__":
    main()
