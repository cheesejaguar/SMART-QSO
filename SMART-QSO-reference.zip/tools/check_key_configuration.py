"""Prove ARM configuration rejects zero/shared operational keys without programming hardware."""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    reference = Path(sys.argv[1] if len(sys.argv) > 1 else ROOT / "build/arm-reference").resolve()
    cache = (reference / "CMakeCache.txt").read_text().splitlines()
    compiler = next(line.split("=", 1)[1] for line in cache
                    if line.startswith("CMAKE_C_COMPILER:"))
    env = {**os.environ, "PATH": str(Path(compiler).parent) + os.pathsep + os.environ["PATH"]}
    cases = [
        ("zero_command", "0" * 64, "", "cannot be an all-zero"),
        ("zero_update", "", "0" * 64, "cannot be an all-zero"),
        ("shared", "ab" * 32, "AB" * 32, "must be separate"),
        ("short", "ab" * 31, "", "exactly 32 bytes"),
    ]
    records = []
    with tempfile.TemporaryDirectory(prefix="sq-key-config-") as directory:
        for name, command, update, error in cases:
            result = subprocess.run([
                "cmake", "-S", str(ROOT / "software/flight"), "-B", str(Path(directory) / name),
                f"-DCMAKE_TOOLCHAIN_FILE={ROOT / 'software/flight/cmake/arm-none-eabi.cmake'}",
                "-DSQ_TARGET=stm32l476-reference", "-DFLIGHT_BUILD=ON",
                f"-DFETCHCONTENT_SOURCE_DIR_FREERTOS={reference / '_deps/freertos-src'}",
                f"-DSQ_COMMAND_PUBLIC_KEY={command}", f"-DSQ_UPDATE_PUBLIC_KEY={update}",
            ], env=env, capture_output=True, text=True)
            if result.returncode == 0 or error not in result.stdout + result.stderr:
                raise RuntimeError(f"Key rejection did not execute: {name}: {result.stderr}")
            records.append({"case": name, "rejected": True, "diagnostic": error})
    out = ROOT / "output/verification/key-configuration.json"
    out.write_text(json.dumps({"cases": records, "hardware_execution": False}, indent=2) + "\n")
    print("Four invalid ARM key configurations rejected; no hardware programmed")


if __name__ == "__main__":
    main()
