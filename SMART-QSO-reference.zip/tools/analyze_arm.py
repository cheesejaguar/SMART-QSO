"""Analyze project-owned C under its actual ARM compile configuration, never execute it."""

import argparse
import json
import shlex
import subprocess
import tempfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build", type=Path)
    args = parser.parse_args()
    root = Path.cwd()
    rows = json.loads((args.build / "compile_commands.json").read_text())
    results = []
    with tempfile.TemporaryDirectory(prefix="sqso-arm-analysis-") as output:
        for number, row in enumerate(rows):
            source = Path(row["file"])
            if (
                source.suffix != ".c"
                or "/software/flight/" not in str(source)
                or "/vendor/" in str(source)
            ):
                continue
            command = shlex.split(row["command"])
            if "arm-none-eabi" not in command[0]:
                raise RuntimeError("ARM analysis cannot use a host compiler")
            command[command.index("-o") + 1] = str(Path(output) / f"{number}.o")
            command.extend(["-fanalyzer", "-Werror"])
            checked = subprocess.run(
                command, cwd=row["directory"], text=True, capture_output=True, check=False
            )
            results.append(
                {
                    "path": str(source.relative_to(root)),
                    "exit_code": checked.returncode,
                    "diagnostics": checked.stderr,
                    "flags": "Actual ARM compile configuration plus -fanalyzer -Werror",
                }
            )
    report = Path("output/verification/arm-analyzer.json")
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(
        json.dumps(
            {
                "scope": "Project-owned target C, including BSP and boot; third-party RTOS/crypto excluded; no hardware execution",
                "results": results,
            },
            indent=2,
        )
        + "\n"
    )
    if not results or any(row["exit_code"] or row["diagnostics"] for row in results):
        raise RuntimeError("Missing or unsuccessful ARM analysis; see retained report")
    print(
        f"{len(results)} target translation units ({len({row['path'] for row in results})} distinct files): no diagnostics; no hardware execution"
    )


if __name__ == "__main__":
    main()
