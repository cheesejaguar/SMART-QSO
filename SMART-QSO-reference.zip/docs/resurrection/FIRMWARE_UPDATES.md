# Authenticated updates and interrupted-transfer recovery

The production C writer is linked into the host shared library and all three reference applications. It accepts only Ed25519 telecommands and independently verifies an Ed25519 firmware manifest with a separately provisioned public key. Neither private key is sent to the browser. The default ARM images have unprovisioned keys; acceptance is disabled.

## Artifact and transfer

The signed artifact contains a 112-byte manifest, erased padding to a 2KB page, and a separately linked application. The manifest authenticates `SQFW`, uint64 monotonic version, uint32 length, BLAKE2b-256 content hash and a 64-byte Ed25519 signature. Application A and B have different vector addresses; signing an A binary cannot turn it into a B binary. Inspect/target-vector checks reject mismatches. Boot and recovery partitions cannot be remotely written.

Build an artifact with the offline update signer:

```
uv run python -m tools.build_update --application build/arm-reference/smart_qso_reference_b.bin \
  --key /absolute/private/update.pem --version 2 --output /absolute/artifacts/application-b.sqfw
```

Version numbers are configuration-controlled. The accepted-version high-water mark survives rollback. CRC-correct but inconsistent boot version/trial/attempt fields and nonzero reserved bytes are rejected. A failed published version cannot be reused. Do not derive versions from wall-clock time or erase state to bypass the floor.

The signed command sequence is UPDATE_BEGIN (80), sequential UPDATE_CHUNK (81, at most 128 bytes), UPDATE_COMMIT (82). The command replay floor is persisted before execution. UINT64_MAX is reserved for END_MISSION; another command cannot consume the last shutdown nonce. The writer checks SAFE mode, retained RF inhibit, healthy storage, valid EPS, payload off/unrequested, SOC at least 650 permille and temperature 0 to below 45°C. Retirement blocks writes. Every erase/write is partition bounded; writes are read back before hashing. Commit checks the complete hash and stack/reset vectors, persists the new trial/version floor, then erases the staging header and publishes the signed manifest last. Publication does not establish a successful boot. I/O errors latch acceptance off until protected state is reloaded.

## Recovery, abort and deadlines

The unpublished header page holds an authenticated staging manifest plus append-only 8-byte page checkpoints. A complete 2KB body page, or final partial page, receives a CRC32 checkpoint. UPDATE_RESUME (84) must supply the same signed manifest and target. The supervisor reconstructs the hash from validated contiguous pages, one checkpoint per cycle; torn records are skipped. The unfinished page is erased and retransmitted. At most 224 checkpoint records are available, including spare records for torn writes. Exhaustion fails closed. Final content/signature verification is mandatory even when every checkpoint passed.

UPDATE_STATUS (85) reports active/published/I/O-fault/recovering flags, target, verified bytes, length and accepted version. During a live transfer, verified bytes can include an unfinished page. **Use the offset reported after completed resume reconstruction** for retransmission; do not treat the pre-reset byte count as durable. A valid offset is a page boundary or the full image length. UPDATE_ABORT (83) writes a durable abort marker when active and safe; an explicitly aborted stage cannot resume. A lost contact or 120-second inactivity timeout stops volatile transfer while retaining staging. The session limit is three hours. An interrupted publication consumes the version if its floor was already committed, and requires a new higher-version artifact.

The loader validates images, persists trial attempts, tries the candidate at most three times, then returns to the confirmed image or signed recovery. Hash validation services the watchdog. The application confirms after a healthy 60-second supervisor interval. The host `boot_cycle` exercises policy and persistence, not ARM instruction execution.

## Ground workflow

Supply `SQ_SIGNING_KEY`, `SQ_OPERATOR_TOKEN` and `SQ_UPDATE_PUBLIC_KEY` (64 hex characters) to the local service. The update public key must be 32 nonzero bytes and match the offline signer. The console inspects signature, hash, version and target, requires explicit review, then transfers at most eight commands per step. The resume checkbox reconstructs existing page checkpoints. HTTP requests mutate file-backed simulation only. SQLite and simulated flash survive restart. Preserve the database, replay history, slot files and boot state together when restoring a reviewed backup.

The explicit serial CLI defaults to inspection without transmission:

```
uv run python -m software.ground.client.firmware --image /absolute/artifacts/application-b.sqfw \
  --update-public-key <64-hex-public-key>
```

`--send` additionally requires the command signer, sequence database, source/destination callsigns and `/dev/...` port. Stop-and-wait receipts are unsigned; they cannot prove execution. A missing/rejected receipt stops the transfer for state reconciliation. Because operational RF is inhibited during update, `--no-receipts` provides an explicitly selected paced uplink-only mode, never an execution-success claim. Default command pacing is 2.5 seconds; resume recovery wait is 10 seconds for the 10ms reference supervisor, subject to measured HIL timing. `--resume --offset ...` requires a reconciled durable page offset and persistent command floor. No transport timeout authorizes blind replay or rearming RF. UART speed is distinct from modem baud. No physical radio has been used here.

## Evidence and remaining acceptance

`test_update_stream.c` and `test_update_payload.py` exercise the actual C dispatcher/writer, every injected flash mutation cut in the tested short image, torn checkpoints, stage/header corruption, partial readback, wrong keys/hashes/vectors, safety loss, replay, expiry, rollback, confirmation, HTTP restart/resume and serial framing. These are bounded fault campaigns, not exhaustive hardware failure proofs.

The reference backend checks the STM32L476 1MB dual-bank layout, disables output permits before flash erasure and retains UART input with DMA. No board has been programmed. Selected EPS inputs, brownout/flash timing, watchdog margin, option-byte protection, key custody, ECC/endurance/radiation, reboot continuity, maximum-image HIL, corrupted recovery paths and independent review remain mandatory. Unknown EPS inputs correctly prevent updates. Host fault injection cannot close those hardware gates.

The host flash adapter requires exact-length reads before copying across the C ABI. Truncated slot files and faulty short-read backends cause I/O failure and acceptance shutdown; they are not interpreted as valid memory. A maximum 382KB application body is tested through transfer/publication/boot policy. These remain host scenarios, not maximum-size hardware timing qualification.

## Final review hardening

Operational configuration now rejects a shared command/firmware key at the ARM configuration, localhost service and serial sender entry points. An all-zero nonempty ARM key is rejected; use an empty key for an unprovisioned reference. Direct file-backed C fault harnesses can use test keys to isolate writer behavior; they are not operational provisioning. C and Python both reject noncanonical manifest padding and stack pointers without SRAM headroom. Signing-counter storage migrates atomically from signed SQLite integers to exact decimal text, with uint64 HTTP sequences represented as strings; only retirement can reserve the terminal nonce. Migration/exhaustion/restart and high-sequence retirement are tested.
