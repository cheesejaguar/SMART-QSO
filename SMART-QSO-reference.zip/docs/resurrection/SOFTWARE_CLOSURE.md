# Software closure and acceptance boundary

This follow-up implements the remaining portable OBC–payload transaction, authenticated update writer/resume, recipient relay contact and retirement paths. It does not establish flight readiness. The [machine-readable closure register](../../mission/current/software_closure.json) assigns 17 software work items, their source/test evidence, accountable roles and exact remaining acceptance criteria.

| Work item | Repository evidence state | Remaining acceptance |
|---|---|---|
| OBC–payload transport, MCU grammar/freshness, power cycle and fallback | Host-tested | Carrier/harness, measured boot/power/thermal profiles and disconnect HIL |
| Signed command and separately signed firmware transfer | Host-tested | Selected EPS, actual flash/watchdog timing, protected option bytes and security review |
| Durable checkpoint resume, readback, publication and boot rollback | Host-tested | Maximum-image power-cut/endurance/ECC HIL and executed recovery |
| Protocol-v2 CRC, generated dictionaries and recipient contact relay | Host-tested | Real radios/TNCs, AFSK interoperability and independent recipient logs |
| Update inspection/review/resume UI and server-held signing | Host-tested | Operational key custody, backup operators, live adapter and rehearsals |
| Retained end-of-mission software latch | Host-tested | Verified physical RF cessation and independent battery passivation |
| TIM2 monotonic timer, 80MHz clock, dual UART DMA and handoff | Implemented and ARM-built | Actual reference-board execution and timing/error campaign |
| Generation/header/data-protected state journal | Host-tested portable format | Flash brownout, endurance, ECC and RTC continuity |
| Compact contact/energy predictor and deterministic safety gate | Host-tested synthetic experiment | Real/calibrated held-out data, approved artifact and flight selection |
| Owned portable MISRA remediation and context evidence | Host-tested | Complete ruleset, target/vendor applicability and independent review; 51 raw context/vendor diagnostics retained |
| Selected EPS/ADCS/deployment/RTC/radio drivers | Proposed | Supplier/component ICDs, pin/harness assignments, calibration and HIL |
| Selected flight inference runtime/model | Proposed | Artifact/hash/license selection and calibrated full-cycle profiles |

There are no required placeholders in the portable production logic or false simulation drivers linked into ARM firmware. The unselected EPS input deliberately reports unavailable and keeps the development board SAFE/RF OFF; it also prevents update writes until valid EPS is supplied by an accepted hardware interface. Hardware-specific software cannot honestly be completed from invented component choices or simulated measurements. The selected drivers, recovery protections and institutional assurance work remain explicit program tasks.

Original incompatible test bodies are preserved as historical text. Their twelve current replacements execute against production modules. All 31 current C suites run: 17 production suites and 14 explicitly named compatible historical-host suites. No current test source is quarantined. [MISRA and test resolution](MISRA_RESOLUTION.md) records the migration and actual analysis scope. B-dot/calibration is host-tested reference code; sensor/actuator integration remains open.

The actual test/analysis results and scope are recorded in [the implementation report](IMPLEMENTATION_REPORT.md) and `output/verification/verification.json`. A development ZIP includes the complete non-secret source tree and binds the source fingerprint, firmware images, protocol, test reports, analyzer outputs, closure/MISRA registers, predictor experiment and proposal artifacts. No board has been programmed, no ARM instruction execution is claimed, and no RF signal was transmitted. Named reviewers must approve classification, tailoring and evidence before NASA compliance or flight acceptance can be declared.
