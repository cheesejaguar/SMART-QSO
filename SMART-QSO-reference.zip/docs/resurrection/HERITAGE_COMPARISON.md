# Heritage and research comparison

Retrieved 2026-10-14. This is a scoped starting comparison, not a claim of exhaustive literature coverage or priority. Refresh it before a formal proposal submission; retain mission papers and their actual experiment methods/results.

| Primary source | Relevant established work | SMART-QSO question and boundary |
|---|---|---|
| [AMSAT packet-station guidance](https://www.amsat.org/wordpress/wp-content/uploads/2014/01/AMSAT_Journal_ISS_Packet.pdf) | Ordinary 1200-baud AX.25 AFSK station operation | Reuse ordinary TNC interoperability. A bounded persistent message relay needs a reference client and real independent-station delivery trials. |
| [ESA Φsat-2 mission](https://www.esa.int/Applications/Observing_the_Earth/FutureEO/Phsat-2/Introducing_Phsat-2) | A 6U spacecraft demonstrating onboard AI for Earth observation | Onboard AI is established mission work. Do not infer that its compute/power design fits this 3U relay or its language workload. |
| [ESA OPS-SAT](https://esoc.esa.int/content/ops-sat) | In-orbit software experimentation and AI deployment | Separate essential spacecraft control from optional experiments, and require operational evidence. This repository has no flight heritage. |
| [LLMSat, arXiv:2405.01392](https://arxiv.org/abs/2405.01392) | Research on a goal-oriented language-model spacecraft agent | SMART-QSO instead confines language output to verified status descriptions. Assess bounded generation value and cost; do not transfer simulation claims into flight evidence. |
| [ASTREA, arXiv:2509.13380](https://arxiv.org/abs/2509.13380) | Research integrating language and reinforcement-learning agents for thermal autonomy on flight-heritage platforms | Hardware/platform heritage and a publication do not establish SMART-QSO's in-orbit performance. Compare reported resource, robustness and validation methods before selecting a payload architecture. |

The funding proposition is accessible packet service plus reproducible resource-management evidence. No “first AI satellite” or “first language model in space” claim is made. Predeclare matched deterministic/predictor experiments, charge whole-cycle compute energy, measure fairness and station exposure, and publish null/negative results. Existing AI and packet heritage strengthens the need for practical differentiation rather than a priority slogan.

Outstanding research work: full-paper method extraction, independent technical literature review, actual model/runtime/parts license selection, measured payload profiles and real/calibrated held-out predictor trials. Synthetic held-out model experiments are now implemented; they do not close the measured-flight comparison. The simulation's contact oracle is an upper bound, not a deployed learned model.
