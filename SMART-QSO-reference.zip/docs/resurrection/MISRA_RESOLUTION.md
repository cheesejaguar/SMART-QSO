# MISRA remediation and test replacement

The initial partial-checker register contained 576 locations. The portable mission, payload, update, transport, persistence and runtime modules have been reworked to remove actionable findings: single-exit control flow, explicit byte indexing and expression grouping, checked return values, consistent essential types, distinct helper names, typed update dispatch and bounded host JSON formatting. The host demonstration lives under `software/flight/examples/`; it is not flight code.

## Actual checker result

The checksum-pinned Cppcheck 2.22.0 partial MISRA C:2012 addon now reports **zero actionable findings in the owned portable-core/host-ABI scope**. The raw XML is retained unchanged and still has exit code **2**, with **51 context/vendor locations**:

- 48 rule-8.7 locations are externally linked APIs. Target entrypoints, current C tests and Python ctypes callers are outside the core-only C scan. Each disposition records actual source references; reducing linkage would break those interfaces. These are analysis-context resolutions, not automatic approval of a deviation.
- Three rule-2.5 locations are unused public Argon2 constants in the unchanged, pinned Monocypher header. The firmware uses the separate signature/hash APIs. The vendor implementation still requires its own assurance assessment.

No MISRA rule/location suppression is used. Standard header lookup uses Cppcheck's library model; the informational `missingIncludeSystem` category is explicitly recorded. Any other checker diagnostic/error, new location, missing interface consumer or actionable finding fails the development gate. Regression tests verify that prose strings, missing callers, unknown vendor constants and analyzer errors cannot be silently relabeled as resolved. Full licensed rule texts, complete checker coverage, tool-confidence assessment, formal applicability/deviation decisions and independent review remain required for compliance acceptance.

The original register is preserved at `docs/history/misra-initial-findings.json`. `mission/current/misra_resolution.json` links its historical locations to remediation categories and current evidence. `mission/current/misra_findings.json` and `output/verification/misra.xml` contain the current raw/context results. Source line changes are not represented as independent review.

```
uv run python -m tools.check_misra --checker /absolute/cppcheck-2.22.0/cppcheck \
  --addon /absolute/cppcheck-2.22.0/addons/misra.py
```

`--require-accepted` continues to reject flight assurance acceptance. `--refresh` regenerates the inventory after a reviewed source change; it does not waive actionable findings. The checker remains a partial implementation, as described in the [Cppcheck manual](https://cppcheck.sourceforge.io/manual.html) and [addon documentation](https://github.com/cppcheck-opensource/cppcheck/blob/2.22.0/addons/README.md).

## Production tests replacing quarantined code

All twelve formerly quarantined C files now contain executable current-module tests. The original files are preserved byte-for-byte under `docs/history/legacy-tests/`, with paths, hashes and original scenario names in `mission/current/legacy_test_migration.json`. Sensor self-tests, obsolete APIs, sun-pointing/TRIAD and retired beacon/JSON behavior are distinguished from current requirements; no fake hardware reading is substituted for acceptance evidence.

The current inventory has **31 C source suites**, all registered: 17 production suites and 14 explicitly named compatible historical-host suites. CI rejects unknown/unregistered sources and duplicate suite mappings. Assertions remain enabled in Release builds. The 17 production suites run under address/undefined-behavior sanitizers.

Replacement scenarios cover initialization, storage failure, reboot restoration, retained inhibits/retirement, mode transitions, queue expiry/duplicates/receipts, telemetry units and corruption, KISS fragmentation/overflow, watchdog votes/deadlines, periodic cadence/clock regression, payload fallback/timeouts and update/boot recovery. B-dot/calibration tests cover reviewed-input gating, integer bounds, control sign, total actuator-command limits, clock/sensor failure, invalid pointers and in-place calibration. A Python reference independently checks 1,000 randomized control samples. No torquer or sensor is connected.

Additional fault tests reject CRC-correct inconsistent persistent state, reserve the terminal command nonce for END_MISSION, verify the maximum 382KB application body, reconstruct the final partial-page checkpoint, and prevent an authenticated command sender from changing firmware-signer content. Truncated/custom short flash reads now fail before `ctypes.memmove`; recovery, publication and abort I/O failures latch acceptance off and retain the previous image.

## Verification scope

Clang analysis covers ten owned portable/host modules. GCC `-fanalyzer -Werror` uses the actual ARM compile configuration for 17 target translation units (12 distinct files), including board support, main and boot. It is reproduced by `tools/analyze_arm.py`. These checks do not execute ARM instructions or cover third-party RTOS/crypto implementations.

The final recorded run has 404 passing Python tests, 31 CTest suites and 31 sanitizer suites (including the separate 17-production campaign). It executes all 1,601 measured portable/host lines; measured branch coverage is 82.60%.

Coverage reports combine the production C suites with Python tests using an instrumented shared library. They measure executed lines/branches of ten portable/host modules, excluding compiler-unreachable branches. They do not establish MC/DC, BSP/RTOS coverage or accepted safety/classification-driven coverage targets. Hardware-specific drivers, measured timing/profiles, HIL/environmental evidence and institutional/independent review remain open.
