# OBC–payload integration

The C supervisor owns payload power, transaction acceptance and the public advisory description. The optional Python bridge can return a deterministic template or run process-isolated language generation. It cannot command the spacecraft, change numeric telemetry or rewrite relayed messages.

## Link and lifecycle

The reference link is USART1 PA9/PA10 AF7 at approximately 115200 baud, 3.3V logic. Point-to-point KISS port 0 contains raw protocol-v2 frames; there is no AX.25 wrapper on this link. It is separate from USART2's development command/TNC interface. Ground and payload dictionaries derive from `mission/current/protocol.json`. All frames include CRC32/IEEE over the header/payload. CRC detects corruption; it does not authenticate a payload computer.

A permitted payload request powers the module, waits 30 seconds for cold boot, and sends a sequenced HEALTH snapshot. PAYLOAD_RESULT echoes the sequence and observed MCU uptime plus 1–120 ASCII bytes. The MCU independently checks the active transaction, unchanged approved facts, 20-second response deadline, 30-second freshness, exact bounds and finite grammar. Approved phrases state battery SOC, mode and RF permission, optionally `73!`. The interface has no sunlight measurement; generation cannot assume one. The Python inference deadline defaults to 15 seconds and cannot exceed 18 seconds, preserving transport margin.

A valid response is retained while facts remain current. Five seconds later the supervisor removes the payload power permit and waits 600 seconds before another cold start. Timeouts/disconnects remove power and back off for 600 seconds. Resource loss removes power, and clock regression latches a fault. Malformed, excessive, stale, duplicate or factually incorrect text uses the current deterministic template. Disabling the payload immediately invalidates accepted text. Accepted text can remain fresh briefly after the payload powers off; source and authoritative numeric HEALTH are separate.

The wired development output publishes numeric HEALTH and separate DESCRIPTION frames every 60 seconds or on signed GET_STATUS. DESCRIPTION identifies deterministic-template versus MCU-accepted-payload source. Neither source constitutes authoritative command data. Physical RF permission remains independently governed by the MCU safety state.

## Run the bridge

```
uv run python -m software.payload.bridge --port /dev/ttyUSB0 --baud 115200
```

This defaults to templates. `--model /absolute/path/model.gguf` selects the bounded language worker when a compatible runtime is installed. No model or inference runtime is selected for flight, and no model license/energy/latency/thermal profile is accepted. Missing model/runtime and worker stalls fall back to templates. Benchmark full cold-boot/model-load/inference/shutdown cycles with calibrated traces using `tools/benchmark_payload.py`; unmeasured energy remains unknown.

The local service's `/api/payload/request` and operator-protected `/api/payload/response` pass the same raw transaction through the production C adapter. They are file-backed simulation, not an attached payload board.

## Verification and hardware boundary

Native tests and Python cross-language tests cover framing, grammar, freshness, sequence, changed facts, deadlines, power removal, cooldown, unavailable EPS, explicit payload disable and template recovery. A real OS pseudo-terminal connects pyserial to the bridge; this proves serial software behavior, not electrical hardware integration. Spawned worker tests exercise actual termination and incorrect output.

Selected carrier/harness, level shifting, inrush/load switching, payload UART reset behavior, measured boot timing, cooling in vacuum, model/runtime pins and licenses, EMI, supervisor watchdog interaction and physical disconnect/power-interruption HIL remain required. The 30/5/600-second lifecycle values are provisional controlled software parameters and need measured hardware validation.
