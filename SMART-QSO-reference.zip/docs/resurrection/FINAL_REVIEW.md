# Final repository review and external closure

This review inventories every tracked/nonignored artifact, inspects current high-risk software paths and interfaces, checks legacy boundaries/claims, and reruns the executable development campaign. It is a repository-wide development review, not an independently accepted line-by-line flight inspection. The source inventory, [ten final findings](../../mission/current/final_review.json), prior [mission findings](../../mission/current/findings.json), [software closure](SOFTWARE_CLOSURE.md) and actual reports are the evidence authorities.

## Corrections

| Finding | Correction and evidence |
|---|---|
| Dependency advisories | Astro 5.18.2 → 7.3.8; cryptography 46.0.7 → 50.0.2; pytest 8.4.2 → 9.1.1. Frozen locks and Python/npm advisory gates retained. NumPy is bounded below 2.5 to preserve the declared Python 3.11 typing/runtime baseline. Starlette's supported httpx2 test client eliminates its compatibility deprecation. |
| Operational trust roots | Shared command/firmware keys and nonempty zero ARM keys fail provisioning. Four invalid ARM configurations and HTTP/serial rejection before transport are tested. Test-only C fault rigs remain distinct from operational provisioning. |
| Image agreement | MCU and Python reject noncanonical manifest padding and a stack pointer without SRAM headroom. The complete signed hash, vector/slot and version checks remain required. |
| Station-field agreement | C now rejects nonzero bytes after a callsign terminator in messages, ACKs, recipient contacts and loaded records. Seven C/Python malformed/persistence regressions enforce one dictionary and preserve queue/delivery state. |
| Ground nonce/archive | Atomic SQLite INTEGER → TEXT migration preserves unsigned 64-bit nonces. Browser-facing nonces remain exact strings. The terminal nonce is reserved for retirement; exhaustion is explicit. Exact signed commands, parameters and public signer identity are archived without private keys/tokens. |
| Historical input validation | Logging-only assertions in five host modules no longer permit null/range/index errors to proceed. Scenario regressions, a 24-source Cppcheck scan, sanitizers and warnings-as-errors cover these corrections. Assertion macro redefinition warnings are removed. |
| Public deployment | Base-aware routes/assets, a read-only engineering register, explicit local-console guidance, research limits/tradeoffs and a complete development source download work at the GitHub project URL. All static routes/assets/anchors are checked before publishing. |
| Unsupported legacy claims | Historical C/Python support and earlier Class B/heritage claims are explicitly labeled. The earlier payload README is archived; the current README directs users to the actual protocol-v2 serial bridge. |
| Source release integrity | Build caches are excluded. Source/artifact hashes, archive CRCs, source inventory and checksums must match before publication; missing/tampered sources, operational key paths and unsupported acceptance fail checks. |
| Reference watchdog boundary | The watchdog deadline is checked again after boot-state confirmation. Failed boot-state reads/writes latch unhealthy storage and prevent feeding. A repeated runtime deadline regression and actual ARM compilation/analysis support the correction; physical timing remains HIL work. |

The dependency upgrades follow the [Astro upgrade guide](https://docs.astro.build/en/guides/upgrade-to/v7/), [Astro security advisory](https://github.com/withastro/astro/security/advisories/GHSA-26w7-cxv4-gfx2), [cryptography changelog](https://cryptography.io/en/latest/changelog/) and [pytest changelog](https://docs.pytest.org/en/stable/changelog.html). Advisory scans are current queries for active locked Python/npm packages; they are not a complete vulnerability, vendor or license acceptance assessment.

## Verification rerun

| Verification | Recorded development result |
|---|---|
| Python | 411 tests on Python 3.12 and 411 in an isolated Python 3.11 environment; no failures/errors/skips or test warnings in the final runs. |
| C | 31 suites: 17 production and 14 compatible historical-host; every current C test source registered, none quarantined. |
| ASan/UBSan | All 31 suites, including corrected historical support; the separate 17-production campaign also passes. |
| Coverage | 1,611/1,611 portable/host lines; 1,045/1,259 measured branches (83.00%). Unreachable branches excluded. No MC/DC, BSP/RTOS/vendor coverage or accepted classification target. |
| Analysis | Ten Clang module reports; core and 24-source historical Cppcheck scans: no standard diagnostics. ARM `-fanalyzer -Werror`: 17 translation units / 12 files, no diagnostics. |
| Partial MISRA | Zero actionable owned portable/host-ABI findings; 51 raw context/vendor diagnostics retained, raw exit 2. Full rule coverage, vendor/target applicability, tool confidence and accepted deviations remain open. |
| Quality and dictionaries | Ruff and nonincremental mypy (29 sources), generated protocol conformance, program/source references and test-inventory consistency pass. |
| Firmware | Four genuine ARM ELF/BIN/MAP sets checked; unprovisioned keys, no simulation/heap linkage, no board execution. Invalid key configurations reject. |
| Simulations | Engineering CLI, matched held-out predictor experiment and clean historical notebook execute. Physical feasibility and measured flight benefit remain false. |
| Dependencies | Active locked Python 3.11/3.12 and npm audits have no known advisories. |
| Website | Root/local and GitHub-project static builds; route/asset/anchor checks. Live deployment and Chromium desktop/mobile evidence are recorded separately after publication. |
| Funding artifacts | Unchanged seven-page PDF rendered and inspected; eight-slide editable presentation ZIP/OpenXML checked. Native PowerPoint execution is not asserted. |
| Release | Complete current non-secret source plus actual reports, reference images, proposal and editable deck; manifest/source/ZIP/checksum integrity checked. |

`output/verification/verification.json` is derived from actual JUnit, analyzer, coverage and advisory reports. The current-source check binds the development archive to the exact source snapshot; publication has a separate external evidence boundary. Remote mission CI is configured but not claimed to have run for these uncommitted source changes. A GitHub Pages build does not establish flight-software CI or acceptance.

## What still needs hardware, supplier or mission inputs

| Work | Accountable role | Closure evidence |
|---|---|---|
| Component selection and actual drivers | Systems / hardware / RF / flight software leads | Selected OBC/EPS/battery/radio/modem/ADCS/RTC/deployment ICDs, pin/harness assignments, supplier evidence; implement and test the corresponding selected drivers. Generic compiled register code is not a verified board support package. |
| MCU/EPS/persistent recovery | Flight software / EPS / assurance leads | Board execution, brownout, interrupted writes/updates, maximum-image flash timing, endurance/ECC, bus faults, watchdog reset, option-byte protection, recovery/rollback and clock continuity. |
| RF, antennas and mechanisms | RF / mechanical / operations leads | Receive/transmit chain, real ordinary TNC interoperability, deployment sensing, emissions/desense/Doppler/PA measurements, physically verified RF cessation and independent launch inhibits/passivation. |
| Language payload | Payload / thermal leads | Selected licensed model/runtime and hashes, carrier/harness, measured boot/load/inference/shutdown energy, thermal shutdown, disconnect and power-gating HIL. No model/runtime is selected or silently bundled. |
| Feasibility and environment | Systems / ADCS / thermal / radiation leads | Fabrication-ready CAD/PCB/BOM, calibrated mass/volume/energy/peak-current/link/attitude budgets; correlated hot/cold/structural/radiation analyses; vibration, TVAC, EMC/EMI, deployment and pre/post functional results using provider-approved levels. |
| Operational evidence | Operations / RF / regulatory leads | Selected mission orbit and station network, primary/backup equipment and operators, commissioning/handovers/anomaly rehearsals, corroborated station delivery logs, tracking/conjunction/disposal execution. Synthetic contacts and public ACKs do not prove delivery or flight benefit. |

These are not merely test checkboxes. Component/provider decisions, measured profiles and corresponding mission-specific software/analysis work remain. Parametric envelopes and preliminary budgets cannot be accepted as fabrication or physical feasibility evidence.

## What still needs independent review or organizational acceptance

- Determine software classification, safety criticality and assurance/IV&V scope separately from mission risk classification. Approve requirement applicability/tailoring, hazards, controls and bidirectional traceability.
- Complete the chosen MISRA ruleset and target/vendor analysis scope; assess tool confidence, deviations, risk-driven coverage/MC/DC and inspected code/crypto/update/recovery evidence. This developer cannot award independent acceptance.
- Review boot/command trust, operational key provisioning/custody/backup/rotation, authenticated update authority, protected recovery and archived command history.
- Obtain named institutional ownership and accountable people, licensed operators, spectrum coordination/filings, current debris/disposal and launch/provider acceptance, materials/parts/transport/export determinations and accepted environmental levels.
- Replace funding targets/planning allocations with supplier-informed cash/in-kind estimates, staffing commitments, reserves and secured funding. Preregister and independently assess an experiment using calibrated real data before claiming autonomy benefits.

The authoritative listings were rechecked: [NPR 7150.2D](https://nodis3.gsfc.nasa.gov/displayDir.cfm?t=NPR&c=7150&s=2D), [NASA-STD-8739.8B](https://standards.nasa.gov/standard/nasa/nasa-std-87398) and [GEVS GSFC-STD-7000B](https://standards.nasa.gov/standard/gsfc/gsfc-std-7000). Applicability and acceptance still require the governing organization/provider; a source listing is not compliance evidence.

## Publication and browser QA

The public target is https://cheesejaguar.github.io/SMART-QSO/. `tools/publish_pages.py` publishes only verified static files and the current development archive to `gh-pages`, preserves the source checkout, and restores the localhost console build. The public site does not expose the local command/signing service. Source-download instructions refer to the exact packaged source; they do not assume the uncommitted resurrection is already on the repository's main branch.

Live build status/commit and downloaded asset hashes are recorded in `output/verification/publication.json`. Browser checks and screenshots are recorded in `output/verification/live-public-qa.json`; neither is inferred from a successful local build. Browser plugin is unavailable in this session, so regular bundled Playwright/Chromium is the validation path. The flow is home → mission/architecture details → engineering/evidence → research → participation/local-console instructions. Viewports are 1440×1000 and 390×844; identity, meaningful content, no framework overlay, console errors, clipping/overflow, screenshots and navigation are checked. Other browser engines and assistive-technology review remain outside this browser pass. The Browser plugin is an optional future convenience for in-app QA.

The source archive is an immutable development snapshot taken before publication; live deployment/browser evidence is retained separately to avoid an archive/publication self-hash loop. No release, hardware or independent flight acceptance is granted by these checks.
