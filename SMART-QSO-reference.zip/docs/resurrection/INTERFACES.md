# Controlled interfaces

`mission/current/protocol.json` is authoritative. `uv run python -m tools.generate_protocol --check` rejects C/Python dictionary and golden-fixture drift. Historical JSON health, federated-update and voice interfaces are superseded.

Public packet service uses KISS port 0 and AX.25 UI/F0. A TNC supplies HDLC/FCS and 1200-baud AFSK; UART speed is separate. Callsigns/SSIDs are validated. Protocol **v2** information frames have a 14-byte little-endian header (`SQ`, version, kind, uint64 sequence, uint16 payload length), followed by payload and four-byte CRC32/IEEE. Every complete frame is at most 240 bytes. COMMAND additionally appends a 64-byte Ed25519 signature over header, payload and CRC. Version 1 is rejected; update clients/dictionaries together. No flight/public service was deployed before this change.

Messages carry sender/destination, ID, TTL and 1–128 printable ASCII bytes unchanged. RELAY_REQUEST asks for one eligible message addressed to the requesting recipient while preserving fair sender scheduling. ACK is readable and spoofable; corroborating recipient logs are required for verified research delivery. No public request enables RF or bypasses resource limits.

Strictly increasing signed command sequences are persisted before execution; keys stay outside the browser. The generated dictionary includes update transactions and retained END_MISSION retirement. COMMAND_RESULT echoes ID/result and sequence, but is unsigned and cannot establish authenticated execution. UPDATE_STATUS is likewise readable and unsigned. Unprovisioned keys reject commands and firmware. Public telemetry/content remain readable.

HEALTH has a **15-byte** payload `<QHhBBB`: MCU uptime seconds, SOC permille, signed centi-Celsius, mode, flags, queue count. The complete frame is **33 bytes**. Flags report inhibit, RF permission, payload permission, storage health, EPS validity and retirement. When EPS-valid is clear, SOC/temperature are unavailable; zero is not a measurement. Telemetry transactions are distinct from command replay floors. HTTP JSON represents these units, not an alternative radio format.

[Payload integration](PAYLOAD_INTEGRATION.md) defines the separate raw-KISS link, lifecycle, independently checked finite grammar and deadlines. DESCRIPTION carries advisory text/source separately from numeric telemetry. [Firmware updates](FIRMWARE_UPDATES.md) defines image signing, bounded writes, durable resume, rollback and the hardware acceptance boundary.

The 1MB STM32 reference uses static RTOS memory, two journal banks, TIM2 monotonic time and DMA UART reception. The platform README owns its provisional pins and clock configuration. Selected EPS/ADCS/radio/RTC/deployment interfaces, supplier ICDs, harness, calibration, interrupt/flash timing, memory endurance and HIL remain open. No frequency or deployer is approved by this document.
