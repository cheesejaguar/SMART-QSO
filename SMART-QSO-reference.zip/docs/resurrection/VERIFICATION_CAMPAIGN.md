# Verification campaign and acceptance

Reference software tests and ARM builds establish software evidence only. Named review authorities, hardware identities, calibrated instruments, controlled as-run procedures and raw results are required for physical acceptance. Requirements are traced in mission/current/requirements.json; applicable standards in standards.json. Coverage targets are assigned by risk/classification and actual coverage reports, never implied by test count.

| Campaign | Inputs and acceptance evidence |
|---|---|
| Protocol/software | Canonical C/Python fixtures; malformed/boundary fuzzing; invalid signatures/replay; persistent failures/corruption; queue limits, expiry, fairness and retries; boot trial/rollback; model unavailable/timeout/factuality cases |
| Integrated simulation | Matched arrivals, contact visibility/loss, power/thermal/attitude/EOL inputs; uncertainty and time-step convergence; explicit unmeasured fields; no oracle performance represented as flight ML |
| Flatsat/HIL | Actual MCU/RTOS/EPS/radios; real resets and watchdog timing; I2C/SPI/UART recovery; NVM power cuts; RTC continuity; load-switch/inrush response; signed command cessation under fault |
| Mechanical/EPS | Deployer fit, measured mass/CG/inertia, retention/inhibits, deployment sensors and interruption; battery charging/thermal protection/cycling; independent passivation proof |
| RF/environmental | Conducted power, modulation/FCS, sensitivity, Doppler, desense, spurious emissions; provider levels for vibration/TVAC/EMC; calibrated raw data and pre/post functional checks |
| Radiation | Selected orbit/parts TID/SEE/latch-up assessment; margin/derating; measured or justified mitigations and residual risk acceptance |
| Operations/UI | Independent recipient logs, station interoperability, command review/custody, stale/offline/replay UI, primary/backup station failover, commissioning and anomaly drills |
| Disposal/launch | Accepted probabilistic lifetime/reentry/collision assessment; current five-year disposal criterion; battery/energy safing; actual notifications, coordination letters and provider acceptance |

No gate closes because a template exists. Record anomalies with configuration, trigger, expected/observed behavior, raw evidence, consequence, root cause, corrective action, re-verification and review authority. Critical findings remain launch blockers until their closure criteria are met or explicitly accepted by the appropriate authority.
