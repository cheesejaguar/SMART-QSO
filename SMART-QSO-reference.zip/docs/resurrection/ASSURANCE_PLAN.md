# Software engineering, assurance and safety baseline

This project is NASA-aligned in its intended process. It has no accepted NASA compliance determination. NPR 7150.2D and NASA-STD-8739.8B were checked against their authoritative current listings on 2026-10-14. The applicable contract, institution and designated technical/assurance authorities are not selected.

[Standards overview](../../mission/current/standards.json) identifies the program disciplines. [Clause-level tailoring register](../../mission/current/standards_tailoring.json) imports all 100 NPR Appendix C SWE requirements, 103 corresponding assurance activity rows (including separate SWE-065 a–d), SASS-01 and 49 IV&V clauses. Each row has a source reference, component scope, evidence owner, candidate artifacts, decision, rationale/approver fields and acceptance criteria. Source clauses and every subtask must be evaluated; an imported row is not an accepted applicability decision. Re-import with `tools/import_standards.py` from authoritative downloaded source copies and retain source hashes.

## Classification and independence

The systems and independent assurance leads must separately determine software classification for the flight MCU, optional payload, command service and support tools. Hazard analysis determines safety criticality; mission risk classification does not substitute for it. Treat RF shutdown, deployment inhibits, EPS protection and update/recovery as candidate safety functions until the [hazard register](../../mission/current/hazards.json) has been reviewed. Scope IV&V according to the governing requirements and authority; no independent verification institution has been engaged.

Assign named personnel for each role, authority, supplier and independent reviewer before funded execution. The developer who produces an artifact cannot self-award independent acceptance. Record scope, version/hash, participants, unresolved actions, decision and approval for every gate. Historical meeting templates remain historical.

## Development controls

The root lockfiles control Python and JavaScript dependencies. ARM GCC 14.2.1-1.1, FreeRTOS V11.1.0, Monocypher 4.0.3 and CMocka 1.1.7 have pinned sources/hashes. CI builds production C logic, genuine ARM reference images, cross-language tests and the web. The host flight-build alias is rejected. Analyzer failure, missing test dependencies and protocol drift fail the pipeline. The twelve incompatible Unity/API tests have been replaced by current-module production suites, with original bodies/hashes preserved. All 31 current C test sources execute; 17 production suites and 14 named historical-host suites remain separately identified. Unknown sources and duplicate suite mappings fail CI.

Compiler diagnostics, Clang analysis, sanitizers and bounded parser tests are useful evidence. They do not prove MISRA compliance or flight qualification. Cppcheck 2.22.0 is checksum pinned. The partial MISRA C:2012 scan now has zero actionable findings in owned portable/host-ABI code. Its unmodified XML retains exit code 2 and 51 evidenced context/vendor locations: 48 external APIs consumed by target/Python/test callers outside the C-only scan and three unchanged vendor Argon2 constants. No MISRA rule/location suppression is used. The development gate rejects actionable findings, untracked diagnostics, missing consumer evidence and analyzer errors. Full licensed rules, complete checker coverage, target/vendor applicability, tool confidence and independent review remain unaccepted. See [MISRA resolution](MISRA_RESOLUTION.md) for the original 576-location register, corrections, scope decisions and regression tests. `--require-accepted` still blocks flight assurance acceptance. Coverage targets must follow hazard and classification assessments. MC/DC, stress/HIL, endurance and environmental obligations cannot be closed by a host parser test.

## Configuration, changes and releases

Maintain bidirectional requirements → design/source → verification links in the requirements register and test inventory. Record root cause, affected artifacts and verification for nonconformances; regressions reopen findings. Changes to hardware, interface, safety thresholds, model/runtime, keys or disposal assumptions require controlled impact review.

Release manifests and SBOMs identify exact source, dependencies, images and evidence. The reference image has no provisioned signing keys and no selected EPS/radio/ADCS drivers. Protected option bytes, interrupted slot writes, power-cut journals, radiation susceptibility and actual RF cessation require HIL evidence. A development release is not authorized for flight.

## Operations and retirement

The local service has no spacecraft RF adapter. Use server-held signing keys, owner-only local credentials, auditable requests/results and persistent replay protection. Rehearse commissioning, operator handover, backup stations, anomalies, key custody and recovery before spacecraft connection. Archive actual received frames, provenance, station receipt corroboration and approved command history. Accept launch-provider/environmental requirements, spectrum coordination, debris/passivation plans and cessation tests before operations readiness.

Sources: [NPR 7150.2D](https://nodis3.gsfc.nasa.gov/displayDir.cfm?t=NPR&c=7150&s=2D), [NASA-STD-8739.8B](https://standards.nasa.gov/standard/nasa/nasa-std-87398), [GEVS](https://standards.nasa.gov/standard/gsfc/gsfc-std-7000), [47 CFR 97.207](https://www.ecfr.gov/current/title-47/chapter-I/subchapter-D/part-97/subpart-C/section-97.207).
