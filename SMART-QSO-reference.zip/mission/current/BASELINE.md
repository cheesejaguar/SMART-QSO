# SMART-QSO controlled mission baseline

Version 1.0.0 | 2026-10-14 | Repository demonstration

One 3U CubeSat provides open short-message store-and-forward service to ordinary licensed packet stations. The nominal life is 12 months. The MCU owns safety, telemetry, scheduling, radio inhibits and optional payload power. Onboard language generation explains verified status only. Core service works without it.

The JSON configuration in this directory is authoritative. Reference thresholds are demonstration defaults, not hardware acceptance values. The starting point is software only: no institution, hardware, funding, spectrum authorization or launch commitment is secured.

## Interfaces
AX.25 UI/1200-baud AFSK through KISS TNCs; amateur UHF uplink and VHF downlink, exact frequencies pending coordination. Public messages and telemetry are readable. Telecommands use Ed25519 and a persistent sequence floor. There is no on-orbit training or federated upload service.

## Success
Minimum: 30 days of commissioning, safe fallback and independent-station delivery. Full: 1,000 acknowledged deliveries involving 20 stations across three regions during 90 days. Research: matched delivered-message/Wh comparison with uncertainty and zero safety-limit violations. Extended: 12 months and published reproducible results.

## Gate ownership
Every review requires named people, evidence, action closure and acceptance. Mission risk class and software classification are separate assessments, both pending independent approval. Use findings.json, requirements.json, work_packages.json and gates.json for actionable program work. No historical review is an accepted current gate.
