---
name: SMART-QSO
description: Engineering journal and local mission instruments with visible evidence and provenance.
colors:
  journal-paper: "#fafafa"
  journal-graphite: "#142029"
  journal-vermilion: "#c64b30"
  journal-vermilion-hover: "#aa3c25"
  journal-secondary-hover: "#f3e9e4"
  journal-secondary-text: "#52606c"
  journal-rule: "#cbd0d5"
  console-ground: "#121a22"
  console-panel: "#172530"
  console-text: "#eef2f5"
  console-muted: "#aebecb"
  console-orange: "#e17b54"
  console-orange-hover: "#ee926e"
  console-line: "#304451"
  console-control: "#1b2c38"
  console-control-hover: "#283e4e"
  console-selected: "#20323f"
  console-field: "#101c26"
  console-field-border: "#526979"
typography:
  journal-display:
    fontFamily: "'Manrope Variable', sans-serif"
    fontSize: "clamp(40px, 4.25vw, 65px)"
    fontWeight: 850
    lineHeight: 1.05
    letterSpacing: "-0.04em"
  journal-headline:
    fontFamily: "'Manrope Variable', sans-serif"
    fontSize: "clamp(30px, 3.6vw, 49px)"
    fontWeight: 800
    lineHeight: 1.15
    letterSpacing: "-0.035em"
  journal-body:
    fontFamily: "'Manrope Variable', sans-serif"
    fontSize: "16px"
    lineHeight: 1.8
  console-title:
    fontFamily: "'Manrope Variable', sans-serif"
    fontSize: "28px"
    fontWeight: 800
    letterSpacing: "-0.02em"
  console-panel-title:
    fontFamily: "monospace"
    fontSize: "15px"
    fontWeight: 650
    lineHeight: 1.5
  console-body:
    fontFamily: "'Manrope Variable', sans-serif"
    fontSize: "13px"
    lineHeight: 1.8
  console-data:
    fontFamily: "monospace"
    fontSize: "11px"
rounded:
  journal-square: "0px"
  console-control: "3px"
spacing:
  compact: "10px"
  field: "12px"
  mobile-inset: "16px"
  console-gap: "20px"
  panel-inset: "22px"
  console-inset: "26px"
  journal-inset: "48px"
components:
  journal-button-primary:
    backgroundColor: "{colors.journal-vermilion}"
    textColor: "white"
    rounded: "{rounded.journal-square}"
    padding: "15px 23px"
  journal-button-secondary:
    backgroundColor: "transparent"
    textColor: "{colors.journal-graphite}"
    rounded: "{rounded.journal-square}"
    padding: "15px 23px"
  console-button:
    backgroundColor: "{colors.console-control}"
    textColor: "#edf3f7"
    rounded: "{rounded.console-control}"
    padding: "11px 15px"
  console-button-primary:
    backgroundColor: "{colors.console-orange}"
    textColor: "{colors.console-ground}"
    rounded: "{rounded.console-control}"
    padding: "11px 15px"
  console-button-quiet:
    backgroundColor: "transparent"
    textColor: "#edf3f7"
    rounded: "{rounded.console-control}"
    padding: "11px 15px"
  console-field:
    backgroundColor: "{colors.console-field}"
    textColor: "{colors.console-text}"
    rounded: "{rounded.console-control}"
    padding: "{spacing.field}"
  console-panel:
    backgroundColor: "{colors.console-panel}"
    rounded: "{rounded.console-control}"
    padding: "{spacing.panel-inset}"
  console-provenance:
    textColor: "{colors.console-orange}"
    padding: "7px 12px"
---

# Design System: SMART-QSO

## Overview

**Creative North Star: "The Engineering Journal and Mission Instrument"**

The user chose an engineering journal for the public site and dark instruments for the local console. Public pages use paper, graphite, vermilion, heavy Manrope headings and open ruled sections to make mission mechanism and evidence inspectable. The console keeps the same type family and wordmark, then changes to graphite panels, restrained orange feedback and monospaced operational data.

The shared character is precise, approachable and explicit about evidence. Concept imagery is labeled as unbuilt; simulated values, replay archives, unavailable service and stale samples receive visible text. These are identity constraints, not optional annotations. This system records the public site and console built in `software/web`; it does not establish spacecraft, hardware or institutional acceptance.

**Key Characteristics:**

- Open editorial sections and thin structural rules on public pages.
- Compact, flat instrument panels with labeled controls in the console.
- Self-hosted Manrope for reading and hierarchy; monospace for operational values.
- Persistent provenance, freshness and evidence language beside the relevant content.

## Colors

Paper and graphite carry reading; vermilion and orange identify actions, selection and focus. Frontmatter records the implemented values, correcting the earlier provisional rule color.

### Primary

- **Journal Vermilion:** Public primary actions, wordmark accent, focus outline and numbered relay steps; a darker hover color reinforces action.
- **Instrument Orange:** Console primary actions, selected navigation, focus outline, safety values and reference track; a lighter hover color marks interaction.

### Neutral

- **Journal Paper / Graphite:** Public background and text; Secondary Text supports explanatory prose.
- **Journal Rule:** Details and evidence-row separation. Stronger gray rules frame major sections.
- **Console Ground / Panel:** Surrounding canvas and slightly lighter instruments.
- **Console Text / Muted:** Readable values and supporting operational context.
- **Console Line / Control / Selected / Field:** Boundaries, button surfaces, navigation selection and recessed editable fields.

Public evidence rows pair green, amber or gray dots with explicit status words. Console error and notice regions use subdued warm or blue-gray surfaces with explanatory text.

**The Labeled State Rule.** Color supports a written state; it never substitutes for provenance, availability, safety or evidence status.

## Typography

**Display Font:** Manrope Variable, with sans-serif fallback.
**Body Font:** Manrope Variable, imported through `@fontsource-variable/manrope` in every public page and the console entry point; fonts are served locally with the build.
**Label/Mono Font:** CSS `monospace` for time, units, command names, table fields and instrument headings.

Manrope supplies tight, heavy headlines and calmer reading text. Monospace marks operational information; console metrics and tables use tabular numbers.

- **Public display:** The frontmatter clamp is the desktop hero; it becomes 46px at the intermediate breakpoint and 42px on narrow screens. Public document titles use 48px, then 35px on mobile.
- **Public hierarchy:** Section headlines use the frontmatter clamp; mobile sections use 33px. Introductory copy is 22px/1.55, then 18px. Document prose is 16px/1.8; explanatory copy generally uses 14–18px with generous leading and architecture prose bounded at 65ch.
- **Console hierarchy:** Page titles use 28px, then 25px on phones. Monospaced panel titles use 15px/1.5, then 13px. Explanatory copy is 12–13px; fields use 13px. Metric values use 27px monospace, then 20px on phones.
- **Operational tables:** 11px monospace with tabular numbers. Preserve unbroken identifiers, callsigns and states; wrap message prose in its own column rather than shrinking the table to fit the viewport.

**The Reading and Instrument Rule.** Use Manrope for explanations and controls; use monospace where the content is a timestamp, identifier, measurement or operational record.

## Layout

Public masthead, main and footer share a centered 1440px maximum width and 48px horizontal insets. Insets become 30px at 1050px and 22px at 700px. Desktop hero and architecture pair text with illustration or mechanism; relay explanation has three open columns and the reference strip four entries. At 700px, these become stacked reading sections, except the reference strip becomes two columns. Sections move from 70px to 45px vertical padding. Public documents cap their reading container at 900px.

The console starts with a 185px navigation rail and flexible main area; the rail becomes 155px at 1250px. Main padding is 26px, then 20px at 900px and 16px at 550px. Panels commonly use 20px gaps. At 900px, navigation becomes a horizontal row and overview, relay/safety and command layouts stack. At 550px, navigation icons sit above text, message forms become one column and event records stack. The three top metrics remain compact columns.

Horizontal tables stay inside their own scroll region with a minimum width of 780px. Message queues are named, keyboard-focusable regions with visible scroll guidance; left and right arrows scroll 180px. This applies on desktop as well as phones because nested panels can be narrower than their table. Estimated-pass tables also use a named focusable scroll region, but do not currently implement the queue's custom arrow handler or visible guidance.

**The Reachable Receipt Rule.** Keep message fields and receipt controls reachable by horizontal scrolling; preserve visible guidance and keyboard focus instead of compressing or permanently clipping the final columns.

## Elevation & Depth

There are no interface box shadows, glass effects or glows. Public depth comes from whitespace, rules and the isolated concept illustration. Console depth comes from slightly lighter panels, recessed fields and thin borders. The generated spacecraft's physical lighting belongs to the concept asset, not UI elevation.

Motion is limited to native state changes and smooth public anchor scrolling. Reduced-motion preference changes public scrolling to automatic. The reference-track marker updates from simulation uptime; it is illustrative geometry, not flight ephemeris.

**The Flat Instrument Rule.** Separate interface regions with space, tone and thin borders; do not add shadows to imply authority or interactivity.

## Shapes

Public controls and architecture nodes are square rectangles. Console panels, buttons and fields use restrained 3px corners. Borders are ordinarily 1px; focus outlines are 3px accent with visible offset. Circular numbered relay steps communicate sequence, and small evidence dots communicate status alongside text. Neither circle establishes a pill-based control system.

## Components

### Buttons

Public links are rectangular actions: primary vermilion with white text, secondary transparent with graphite text and a vermilion border. They have a 52px minimum height, 15px by 23px padding, 14px text at weight 750 and inline SVG arrows when present. Mobile padding becomes 13px by 16px with 12px text. Hover darkens primary fill or warms the secondary surface; focus uses the public accent outline.

Console buttons have 3px corners, 11px by 15px padding, 12px text at weight 650 and a blue-gray border. Primary uses orange on graphite at weight 800. Quiet retains the outline with transparent background. Text actions are smaller unfilled controls inside panel headings. Hover lightens the relevant fill; focus uses orange. Disabled controls use half opacity and a not-allowed cursor.

### Inputs / Fields

Fields have persistent labels, dark recessed surfaces, 1px borders, 3px corners, 12px padding and a 42px minimum height. Textareas are at least 100px tall and vertically resizable. The operator token is a password field, separate from the local signing key. Global focus outlines remain visible for inputs, selects and textareas.

### Navigation

Public navigation is a plain text row that wraps and sits below the wordmark on phones. Console navigation pairs inline SVG with text; selection uses orange text and a brighter graphite background plus `aria-current`. Hash routes include Overview, Passes, Relay, Commands and Evidence. The rail becomes horizontal below 900px and compact icon-over-label controls below 550px. Both main surfaces include a focus-revealed skip link.

### Provenance and freshness

The console header displays an outlined SIMULATION, REPLAY or OFFLINE badge. A separate wrapping freshness row retains UTC sample time and sample age below the title, including when the compact header hides its timestamp. Replay identifies a historical sample; offline identifies unavailable freshness. Stale telemetry gets an explanatory status region. Unknown or unarchived values use words or an em dash instead of inferred healthy readings. After service restart, archived samples may remain in the trend while current health is unavailable: battery displays a dash, freshness shows “No sample” and “Freshness unavailable,” and the status region says “Telemetry unavailable since service start.” A new simulation sample establishes current health; retained archive data does not.

**The Visible Provenance Rule.** Keep sample origin, UTC time and age visible with the data; mark historical, stale and unavailable states explicitly.

### Panels and evidence rows

Console panels use Panel fill, Line borders, 22px padding and 3px corners, reducing padding to 17px on phones. Public evidence and audit content remains open ruled rows. Native disclosures reveal closure criteria or architecture explanations without overlaying the reading surface. Charts have textual SVG summaries and unit-bearing legends; the map identifies its geometry as illustrative.

### Review and estimate flows

Local commands progress from selection to effect preview, then an operator-token execution action. Execution is disabled during replay, offline or pending state and when the service reports no executable signer setup. Visual documentation records these UI gates; it does not certify backend safety.

Pass planning accepts a supplied TLE and station location, then displays epoch, age, stale warnings, calculation limits and clipped-window indicators. SMART-QSO has no assigned orbit. Estimates do not enable transmissions or commands.

## Do's and Don'ts

### Do:

- **Do** preserve the public paper/graphite/vermilion and console graphite/orange material relationship.
- **Do** load self-hosted Manrope and preserve the reading-versus-instrument typography distinction.
- **Do** keep simulation, replay, offline, stale, UTC timestamp and age language visible with the relevant data.
- **Do** preserve labeled fields, visible focus, reachable scroll regions and receipt controls across viewport widths.
- **Do** identify generated spacecraft imagery as an unbuilt concept and keep evidence states attached to claims.
- **Do** retain command effect review, operator-token entry and visibly disabled execution when control is unavailable.

### Don't:

- **Don't** turn concept imagery, illustrative orbit geometry or supplied-TLE estimates into claims of assigned orbit or measured spacecraft state.
- **Don't** infer healthy values from absent service or archived fields that were never recorded.
- **Don't** replace open public evidence sections with decorative cards or add glow, glass and shadow styling to the flat console.
- **Don't** reduce table typography to force every field into a narrow viewport or remove horizontal-scroll guidance from message queues.
- **Don't** present the finish review as whole-surface acceptance, hardware qualification, NASA compliance or mission readiness.

<!-- Evidence: PRODUCT.md; software/web/public/src/pages/*.astro and styles/global.css; software/web/console/index.html and src/{main.tsx,instruments.tsx,style.css}; supplied .impeccable/review captures. FINISH_REVIEW.md has disposition ship only at scored-fix scope. No fresh browser run was performed for this documentation pass. Raster prompts and origins: docs/design/assets.json and PNG metadata. docs/design/public-concept.png and console-concept.png are critique references, not literal approved comps. concept-seed-record.json preserves key 289f052b, assigned own candidate 3; the user chose a custom world, not a catalog QUALITY BAR card. Promotional mast-note/hero-foot microcopy and their tiny tracking-heavy styling are not canonized as reusable primitives. -->
