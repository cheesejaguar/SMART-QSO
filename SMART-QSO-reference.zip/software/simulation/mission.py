"""Dimensionally explicit preliminary budgets and matched relay scheduling experiment."""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def power_trace(config: dict, orbits: int = 30, scale: float = 1.0) -> dict:
    p = config["power"]
    capacity = p["battery_wh"] * p["battery_eol_fraction"]
    energy = capacity * p["initial_soc"]
    minimum = energy
    generated = consumed = 0.0
    dt = 10
    history = []
    for time in range(0, p["orbit_s"] * orbits, dt):
        phase = time % p["orbit_s"]
        sunlight = phase < p["sunlit_s"]
        solar = p["solar_sunlit_w"] * p["solar_eol_fraction"] * scale if sunlight else 0
        load = p["base_load_w"]
        # Scheduled service burst; compute energy uses an entire measured-cycle allocation.
        if 600 <= phase < 660:
            load += p["tx_increment_w"]
        if (
            time // p["orbit_s"] % p["payload_every_orbits"] == 0
            and 900 <= phase < 900 + p["payload_cycle_s"]
            and energy / capacity > 0.65
        ):
            load += p["payload_cycle_w"]
        generated += solar * dt / 3600
        consumed += load * dt / 3600
        net = solar - load
        energy = min(
            capacity,
            max(
                0,
                energy
                + net
                * dt
                / 3600
                * (p["charge_efficiency"] if net >= 0 else 1 / p["discharge_efficiency"]),
            ),
        )
        minimum = min(minimum, energy)
        if time % 600 == 0:
            history.append(
                {"time_s": time, "soc": energy / capacity, "load_w": load, "solar_w": solar}
            )
    return {
        "min_soc": minimum / capacity,
        "end_soc": energy / capacity,
        "generated_wh": generated,
        "consumed_wh": consumed,
        "reserve_met": minimum / capacity >= p["soc_reserve"],
        "history": history,
    }


def budgets(config: dict) -> dict:
    mass = sum(config["mass"]["items_kg"].values()) * (1 + config["mass"]["system_margin_fraction"])
    v = config["volume"]
    usable = math.prod(v["envelope_mm"]) / 1e6 * v["usable_fraction"]
    link = config["link"]
    fspl = 32.44 + 20 * math.log10(link["frequency_mhz"]) + 20 * math.log10(link["slant_range_km"])
    receive = (
        10 * math.log10(link["tx_w"] * 1000)
        + link["spacecraft_gain_dbi"]
        + link["ground_gain_dbi"]
        - link["loss_db"]
        - fspl
    )
    d = config["data"]
    capacity = d["baud"] / 8 * d["protocol_efficiency"] * d["contact_s_per_day"]
    m = config["memory"]
    allocated = sum(
        m[key] for key in ["boot_kb", "app_a_kb", "app_b_kb", "recovery_kb", "state_kb"]
    )
    estimates = {
        "mass_kg": mass,
        "mass_margin_kg": config["mass"]["limit_kg"] - mass,
        "volume_margin_l": usable - v["allocated_litres"],
        "link_margin_db": receive - link["receiver_threshold_dbm"],
        "daily_relay_capacity_messages": max(
            0, int((capacity - d["housekeeping_downlink_bytes"]) / d["message_bytes"])
        ),
        "flash_allocated_kb": allocated,
        "flash_fits": allocated <= m["device_flash_kb"],
        "power": power_trace(config),
    }
    estimates["feasibility_closed"] = False
    estimates["provenance"] = "preliminary analysis; unmeasured estimates"
    estimates["blocking_inputs"] = config["open_inputs"]
    return estimates


def matched_experiment(seed: int, predictive: bool) -> dict:
    """Identical arrivals/contacts, explicit energy cost; predictor cannot bypass reserve."""
    rng = random.Random(seed)
    contacts = [rng.random() < 0.35 for _ in range(1440)]
    arrivals = [rng.randrange(5) for _ in range(1440)]
    queue = [0] * 5
    delivered = [0] * 5
    energy_wh = 0.0
    cursor = 0
    for contact, sender in zip(contacts, arrivals, strict=True):
        queue[sender] = min(queue[sender] + 1, 8)
        energy_wh += 1.2 / 60
        # Ideal availability indicator is deliberately labeled an upper-bound oracle, not flight ML.
        wake = contact if predictive else True
        if wake:
            energy_wh += 0.35 / 60
        if wake and contact:
            for offset in range(5):
                index = (cursor + offset) % 5
                if queue[index]:
                    queue[index] -= 1
                    delivered[index] += 1
                    cursor = (index + 1) % 5
                    energy_wh += 6 * 2 / 3600
                    break
    fairness = sum(delivered) ** 2 / (5 * sum(x * x for x in delivered)) if any(delivered) else 0
    return {
        "delivered": sum(delivered),
        "consumed_wh": energy_wh,
        "messages_per_wh": sum(delivered) / energy_wh,
        "jain_fairness": fairness,
        "safety_violations": 0,
    }


def experiment_report(seeds: int = 30) -> dict:
    pairs = [(matched_experiment(s, False), matched_experiment(s, True)) for s in range(seeds)]
    differences = [b["messages_per_wh"] - a["messages_per_wh"] for a, b in pairs]
    mean = statistics.mean(differences)
    interval = 1.96 * statistics.stdev(differences) / math.sqrt(seeds) if seeds > 1 else 0
    return {
        "provenance": "synthetic matched experiment",
        "model": "perfect contact oracle upper bound; not a trained or flight-validated predictor",
        "seeds": seeds,
        "baseline": pairs[0][0],
        "oracle": pairs[0][1],
        "paired_mean_delta_messages_per_wh": mean,
        "approximate_95pct_ci": [mean - interval, mean + interval],
        "flight_benefit_proven": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "output/engineering-analysis.json")
    args = parser.parse_args()
    config = json.loads((ROOT / "mission/current/budgets.json").read_text())
    report = {"budgets": budgets(config), "research": experiment_report()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report["budgets"].items() if k != "power"}, indent=2))


if __name__ == "__main__":
    main()
