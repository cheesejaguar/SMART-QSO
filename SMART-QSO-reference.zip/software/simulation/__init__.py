"""Reproducible preliminary engineering models; measured correlation remains a gate."""
