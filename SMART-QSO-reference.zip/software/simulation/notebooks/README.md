> **Historical / unverified baseline (superseded 2026-10-14).** This record is preserved for provenance. Completion, compliance, approvals, hardware results, frequencies and budgets in this document are not accepted current evidence. Use [the controlled mission baseline](../../../mission/current/BASELINE.md).

# Simulation Notebooks

- Power/energy balance per orbit
- Link margin vs. elevation and antenna gain
- Fairness metric evolution across regions
