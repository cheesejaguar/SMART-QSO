"""Ground-trained model bounds, chronological holdout and production safety policy."""

import ctypes
import math

import pytest

from software.common.tests.test_update_payload import payload_rig
from software.simulation.predictors import (
    Advice,
    ContactEnergyModel,
    paired_run,
    report,
    synthetic_records,
)


def test_offline_training_reproducible_and_held_out():
    training = synthetic_records(42, 0, 1440)
    a = ContactEnergyModel.train(training)
    b = ContactEnergyModel.train(training)
    assert a.export() == b.export() and not a.export()["flight_approved"]
    assert len(a.export()["contact_permille"]) == 16
    eval_records = synthetic_records(100, 1440 * 60, 240)
    assert paired_run(eval_records, a, True, 100) == paired_run(eval_records, b, True, 100)
    results = report(2)
    assert results["training_window_s"][1] < results["evaluation_window_s"][0]
    assert not results["flight_benefit_proven"]
    assert all(
        run[policy]["safety_violations"] == 0
        for run in results["runs"]
        for policy in ("baseline", "learned")
    )


@pytest.mark.parametrize(
    "change",
    [
        {"elapsed_s": -0.5},
        {"elapsed_s": math.nan},
        {"attempt_energy_j": math.inf},
        {"contact": 1},
        {"attempt_energy_j": 0},
    ],
)
def test_invalid_training_data_fails_closed(change):
    records = synthetic_records(1, 0, 100)
    records[0].update(change)
    with pytest.raises(ValueError):
        ContactEnergyModel.train(records)


def test_unaccepted_stale_or_invalid_advice_cannot_enable_rf():
    core, _, _ = payload_rig()
    lib = core.lib
    lib.sq_resource_admit.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(Advice),
        ctypes.c_bool,
        ctypes.c_uint32,
        ctypes.c_uint32,
    ]
    lib.sq_resource_admit.restype = ctypes.c_bool
    for probability in (0, 1000, 65535):
        advice = Advice(0, 1, probability)
        assert not lib.sq_resource_admit(core.pointer, ctypes.byref(advice), True, 1000000, 40000)
    assert not lib.sq_resource_admit(core.pointer, None, False, 1000000, 0)


def test_fitted_advice_gates_transmission_only_after_deterministic_limits():
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

    from software.common.core import MissionCore
    from software.common.tests.test_update_payload import command

    key = Ed25519PrivateKey.generate()
    core = MissionCore(
        key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw), lambda data: True
    )
    core.tick(0)
    core.separation()
    core.tick(1800)
    assert core.receive(command(key, 1, "SET_MODE", b"\x02")) == 0
    assert core.receive(command(key, 2, "TX_ENABLE")) == 0
    lib = core.lib
    lib.sq_resource_admit.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(Advice),
        ctypes.c_bool,
        ctypes.c_uint32,
        ctypes.c_uint32,
    ]
    lib.sq_resource_admit.restype = ctypes.c_bool
    fresh = Advice(1800, 10000, 100)
    assert not lib.sq_resource_admit(core.pointer, ctypes.byref(fresh), True, 40000, 20000)
    assert lib.sq_resource_admit(core.pointer, ctypes.byref(fresh), False, 40000, 20000)
    fresh.contact_permille = 900
    assert lib.sq_resource_admit(core.pointer, ctypes.byref(fresh), True, 40000, 20000)
    assert not lib.sq_resource_admit(core.pointer, ctypes.byref(fresh), True, 19000, 20000)
    fresh.observed_s = 1700
    fresh.contact_permille = 0
    assert lib.sq_resource_admit(core.pointer, ctypes.byref(fresh), True, 40000, 20000)
