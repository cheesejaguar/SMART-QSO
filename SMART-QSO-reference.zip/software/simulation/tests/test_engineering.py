import copy
import json

from software.simulation.mission import (
    ROOT,
    budgets,
    experiment_report,
    matched_experiment,
    power_trace,
)


def config():
    return json.loads((ROOT / "mission/current/budgets.json").read_text())


def test_budget_units_and_no_false_closure():
    report = budgets(config())
    assert report["flash_allocated_kb"] == 1024 and report["flash_fits"]
    assert report["mass_kg"] > 0 and report["daily_relay_capacity_messages"] > 0
    assert not report["feasibility_closed"]
    assert report["blocking_inputs"]


def test_no_solar_depletes_and_soc_bounds():
    result = power_trace(config(), 30, scale=0)
    assert not result["reserve_met"]
    assert all(0 <= p["soc"] <= 1 for p in result["history"])
    assert result["generated_wh"] == 0


def test_whole_cycle_energy_changes_budget():
    c = config()
    other = copy.deepcopy(c)
    other["power"]["payload_cycle_w"] *= 2
    assert power_trace(other)["consumed_wh"] > power_trace(c)["consumed_wh"]


def test_matched_experiment_reproducible_and_labeled():
    assert matched_experiment(4, False) == matched_experiment(4, False)
    report = experiment_report()
    assert report["baseline"]["delivered"] == report["oracle"]["delivered"]
    assert not report["flight_benefit_proven"] and "oracle" in report["model"]
    assert report["baseline"]["safety_violations"] == 0
