"""Compact ground-trained contact/energy tables; no flight model or on-orbit training.

The matched experiment charges all attempt and predictor energy, keeps essential reception
on, and calls the production C safety gate and relay. Synthetic data is not flight evidence.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from software.common.core import MissionCore
from software.common.protocol import KINDS, RelayMessage, acknowledgment, frame
from software.common.protocol_generated import COMMANDS

BINS = 16
ORBIT_S = 5700


class ContactEnergyModel:
    def __init__(
        self, probabilities: list[int], energy_mj: list[int], samples: list[int], data_hash: str
    ):
        if (
            len(probabilities) != BINS
            or len(energy_mj) != BINS
            or len(samples) != BINS
            or any(type(v) is not int or not 0 <= v <= 1000 for v in probabilities)
            or any(type(v) is not int or not 1 <= v <= 1000000 for v in energy_mj)
            or any(type(v) is not int or v < 0 for v in samples)
            or len(data_hash) != 64
        ):
            raise ValueError("Invalid bounded predictor table")
        self.probabilities, self.energy_mj, self.samples, self.data_hash = (
            probabilities,
            energy_mj,
            samples,
            data_hash,
        )

    @classmethod
    def train(cls, records: list[dict]):
        if not 32 <= len(records) <= 100000:
            raise ValueError("Training requires 32..100000 ground records")
        grouped: list[list[dict]] = [[] for _ in range(BINS)]
        last = -1.0
        for record in records:
            t, energy = record["elapsed_s"], record["attempt_energy_j"]
            if (
                not math.isfinite(t)
                or not 0 <= t < 2**64
                or t <= last
                or not math.isfinite(energy)
                or not 0 < energy <= 1000
                or type(record["contact"]) is not bool
            ):
                raise ValueError(
                    "Ordered times, finite measured energy and boolean contacts required"
                )
            last = t
            grouped[int(t % ORBIT_S / ORBIT_S * BINS)].append(record)
        probability = []
        cost = []
        counts = []
        for group in grouped:
            counts.append(len(group))
            probability.append(
                round(1000 * (1 + sum(r["contact"] for r in group)) / (2 + len(group)))
            )
            energies = sorted(r["attempt_energy_j"] for r in group)
            cost.append(
                math.ceil(1000 * energies[min(len(energies) - 1, math.floor(0.95 * len(energies)))])
                if energies
                else 1000000
            )
        digest = hashlib.sha256(
            json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        return cls(probability, cost, counts, digest)

    def predict(self, elapsed_s: int) -> tuple[int, int]:
        if not 0 <= elapsed_s < 2**64:
            raise ValueError("Invalid prediction time")
        bin_id = int(elapsed_s % ORBIT_S / ORBIT_S * BINS)
        return self.probabilities[bin_id], self.energy_mj[bin_id]

    def export(self) -> dict:
        return {
            "schema": 1,
            "algorithm": "Beta-smoothed phase-bin contact frequency and empirical 95th-percentile attempt energy",
            "orbit_s": ORBIT_S,
            "contact_permille": self.probabilities,
            "energy_mj": self.energy_mj,
            "samples": self.samples,
            "training_sha256": self.data_hash,
            "license": "MIT",
            "flight_approved": False,
            "training_location": "ground only",
        }


class Advice(ctypes.Structure):
    _fields_ = [
        ("observed_s", ctypes.c_uint64),
        ("energy_mj", ctypes.c_uint32),
        ("contact_permille", ctypes.c_uint16),
    ]


def synthetic_records(seed: int, start_s: int, minutes: int, outage: bool = False) -> list[dict]:
    rng = random.Random(seed)
    records = []
    for step in range(minutes):
        t = start_s + step * 60
        phase = t % ORBIT_S / ORBIT_S
        # Repeatable synthetic visibility windows with RF loss/collision and long outage.
        geometric = 0.10 <= phase < 0.22 or 0.62 <= phase < 0.75
        contact = geometric and rng.random() > 0.18
        if outage and minutes // 3 <= step < 2 * minutes // 3:
            contact = False
        records.append(
            {
                "elapsed_s": t,
                "contact": contact,
                "attempt_energy_j": 8 + 3 * math.sin(2 * math.pi * phase) ** 2 + rng.random() * 2,
            }
        )
    return records


def paired_run(
    records: list[dict],
    model: ContactEnergyModel,
    learned: bool,
    seed: int,
    solar_scale: float = 1,
    aging: float = 1,
) -> dict:
    key = Ed25519PrivateKey.generate()
    public = key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    core = MissionCore(public, lambda data: True)
    core.tick(0)
    core.separation()
    core.tick(1800)
    for seq, (name, params) in enumerate([("SET_MODE", b"\x02"), ("TX_ENABLE", b"")], 1):
        raw = frame(KINDS["COMMAND"], seq, bytes([COMMANDS[name]]) + params)
        if core.receive(raw + key.sign(raw)) != 0:
            raise RuntimeError("Simulation commissioning failed")
    lib = core.lib
    lib.sq_resource_admit.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(Advice),
        ctypes.c_bool,
        ctypes.c_uint32,
        ctypes.c_uint32,
    ]
    lib.sq_resource_admit.restype = ctypes.c_bool
    capacity = 20 * aging
    energy = capacity * 0.8
    consumed = 0.0
    delivered = [0] * 20
    attempts = rejected = expired = safety = 0
    latencies = []
    arrivals = {}
    rng = random.Random(seed)
    next_id = 1
    for index, r in enumerate(records):
        now = 1800 + index * 60
        phase = r["elapsed_s"] % ORBIT_S
        solar = (
            2.5 * solar_scale * (0.75 + 0.25 * abs(math.cos(index / 1440 * math.pi)))
            if phase < 3600
            else 0
        )
        essential_j = 1.2 * 60  # Essential MCU/telecommand receiver never duty-gated by predictor.
        energy = min(capacity, max(0, energy + (solar * 60 - essential_j) / 3600))
        consumed += essential_j / 3600
        core.tick(now, round(1000 * energy / capacity), 2200)
        if index % 3 == 0 or rng.random() < 0.25:
            sender = rng.randrange(20)
            mid = next_id
            next_id += 1
            code = core.receive(
                RelayMessage(
                    mid, f"W{sender:02d}ABC", "K6XYZ", "Synthetic research packet", 7200
                ).encode()
            )
            if code == 0:
                arrivals[str(mid)] = now
            else:
                rejected += 1
        probability, cost = model.predict(int(r["elapsed_s"]))
        advice = Advice(now, cost, probability)
        headroom = max(0, min(1000000, int((energy - capacity * 0.25) * 3600000)))
        permitted = bool(
            lib.sq_resource_admit(core.pointer, ctypes.byref(advice), learned, headroom, 40000)
        )
        if learned:
            energy = max(0, energy - 0.01 / 3600)
            consumed += 0.01 / 3600  # Explicit synthetic compute cost, not measured.
        if permitted:
            code, message = core.next()
            if code == 0 and message:
                attempts += 1
                expense = r["attempt_energy_j"]
                energy = max(0, energy - expense / 3600)
                consumed += expense / 3600
                safety += int(energy < capacity * 0.25)
                if r["contact"]:
                    if core.receive(acknowledgment(int(message["id"]), "K6XYZ")) != 0:
                        raise RuntimeError("Receipt failed")
                    sender = int(message["sender"][1:3])
                    delivered[sender] += 1
                    latencies.append(now - arrivals[message["id"]])
                elif message["attempts"] == 3:
                    expired += 1
    total = sum(delivered)
    fairness = total**2 / (20 * sum(n * n for n in delivered)) if total else 0
    return {
        "delivered": total,
        "attempts": attempts,
        "consumed_wh": consumed,
        "messages_per_wh": total / consumed,
        "jain_fairness": fairness,
        "median_latency_s": statistics.median(latencies) if latencies else None,
        "rejected_arrivals": rejected,
        "exhausted_after_rf_loss": expired,
        "safety_violations": safety,
    }


def report(seeds: int = 30) -> dict:
    if not 2 <= seeds <= 100:
        raise ValueError("Use 2..100 paired seeds")
    training = synthetic_records(20261014, 0, 4320)
    model = ContactEnergyModel.train(training)
    runs: list[dict] = []
    for seed in range(seeds):
        evaluation = synthetic_records(seed, 4320 * 60, 1440, outage=seed % 3 == 0)
        scale = 0.8 if seed % 3 == 1 else 1.0
        aging = 0.7 if seed % 3 == 2 else 1.0
        runs.append(
            {
                "seed": seed,
                "baseline": paired_run(evaluation, model, False, seed, scale, aging),
                "learned": paired_run(evaluation, model, True, seed, scale, aging),
            }
        )
    deltas = [r["learned"]["messages_per_wh"] - r["baseline"]["messages_per_wh"] for r in runs]
    mean = statistics.mean(deltas)
    ci = 1.96 * statistics.stdev(deltas) / math.sqrt(seeds)
    return {
        "provenance": "synthetic held-out matched experiment using production C relay and safety gate",
        "model": model.export(),
        "model_sha256": hashlib.sha256(
            json.dumps(model.export(), sort_keys=True).encode()
        ).hexdigest(),
        "training_window_s": [0, 4320 * 60 - 60],
        "evaluation_window_s": [4320 * 60, (4320 + 1440) * 60 - 60],
        "scenarios": "Eclipse, seasonal/attitude solar uncertainty, battery degradation, RF loss/collision, heavy arrivals and 8-hour contact outage",
        "runs": runs,
        "paired_delta_messages_per_wh": mean,
        "approximate_95pct_ci": [mean - ci, mean + ci],
        "flight_benefit_proven": False,
        "limits": [
            "Visibility is synthetic phase windows, not mission ephemerides",
            "Power, collision/loss and compute energy are unmeasured inputs",
            "One shared downlink recipient; geographic exposure not proven",
            "No accepted flight model, device timing or environmental evidence",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=int, default=30)
    parser.add_argument("--output", type=Path, default=Path("output/predictor-experiment.json"))
    args = parser.parse_args()
    data = report(args.seeds)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(data, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: data[k]
                for k in (
                    "provenance",
                    "paired_delta_messages_per_wh",
                    "approximate_95pct_ci",
                    "flight_benefit_proven",
                )
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
