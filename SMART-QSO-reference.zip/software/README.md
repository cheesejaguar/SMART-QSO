# Active software

The active mission core is software/flight/core, shared by the host service and STM32 reference target. The earlier src modules remain host-only legacy research code with explicitly inventoried tests. They are not linked into reference firmware.

Root pyproject.toml and uv.lock control Python deployment. The payload-local legacy packaging metadata is superseded. Web workspaces and package-lock.json live in software/web. See the root README for the integrated build and service.
