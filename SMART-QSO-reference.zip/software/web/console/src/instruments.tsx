import {useMemo} from 'react';
import {geoEquirectangular,geoPath} from 'd3-geo';
import {feature} from 'topojson-client';
import world from 'world-atlas/countries-110m.json';

export type Sample={id:number;timestamp:string;uptime_s:number;soc_permille:number;temperature_centi_c:number;provenance:string};
export function Icon({name}:{name:string}){const shapes:Record<string,string>={Passes:'M3 12h18M12 3v18M5 5l14 14M5 19 19 5',Overview:'M3 11 12 3l9 8M5 10v11h5v-6h4v6h5V10',Relay:'M4 12a8 8 0 0 1 16 0M7 12a5 5 0 0 1 10 0M10 12a2 2 0 0 1 4 0M12 14v7',Commands:'m4 6 6 6-6 6m10 0h6',Evidence:'M6 3h9l4 4v14H6Zm8 0v5h5M9 12h7m-7 4h7',Shield:'M12 3 3 7v5c0 5 9 9 9 9s9-4 9-9V7Zm-5 9 3 3 6-6',Battery:'M4 7h15v11H4Zm15 4h2v3h-2',Queue:'M4 7c0-5 16-5 16 0s-16 5-16 0m0 0v10c0 5 16 5 16 0V7M4 12c0 5 16 5 16 0',Arrow:'M4 12h15m-6-6 6 6-6 6'};return <svg viewBox="0 0 24 24" aria-hidden="true"><path d={shapes[name]??shapes.Arrow}/></svg>}
export function GroundTrack({uptime}:{uptime:number}){
 const geometry=useMemo(()=>{
  const projection=geoEquirectangular().translate([350,155]).scale(106);
  const path=geoPath(projection);
  const countries=feature(world as never,world.objects.countries as never);
  return {land:path(countries as never)??'',project:projection};
 },[]);
 const track=useMemo(()=>Array.from({length:121},(_,i)=>{const angle=i/120*Math.PI*2;const lat=Math.asin(Math.sin(51.6*Math.PI/180)*Math.sin(angle))*180/Math.PI;return [i/120*360-180,lat] as [number,number]}),[]);
 const positions=track.map(p=>geometry.project(p)!);
 const point=positions[Math.floor((uptime%5700)/5700*120)];
 return <figure className="map"><svg viewBox="0 0 700 320" role="img" aria-label="Illustrative reference ground track at 51.6 degree inclination; not propagated flight ephemeris"><rect x="8" y="8" width="684" height="304" className="map-boundary"/>{Array.from({length:7},(_,i)=><path key={`v${i}`} d={`M${20+i*110} 10v300`} className="gridline"/>)}{Array.from({length:5},(_,i)=><path key={`h${i}`} d={`M10 ${25+i*65}h680`} className="gridline"/>)}<path d={geometry.land} className="land"/><polyline points={positions.map(p=>p.join(',')).join(' ')} className="orbit-path"/><circle cx={point[0]} cy={point[1]} r="5" className="sat-dot"/></svg><figcaption><span><i className="line-key orange"/>Reference ground track</span><span>51.6° / 5700 s / illustrative geometry</span></figcaption></figure>
}
export function EnergyChart({samples}:{samples:Sample[]}){
 const values=samples.slice(-60);
 if(values.length<2)return <div className="chart-empty"><Icon name="Battery"/><p>Advance the simulation to collect a trend.</p><small>No measured spacecraft data is available.</small></div>;
 const start=values[0].uptime_s,end=values[values.length-1].uptime_s;
 const points=(temperature:boolean)=>values.map(s=>`${45+(s.uptime_s-start)/Math.max(1,end-start)*330},${210-(temperature?(s.temperature_centi_c/100+20):s.soc_permille/10)/100*170}`).join(' ');
 return <><svg className="chart" viewBox="0 0 420 250" role="img" aria-label={`Battery state of charge ${values[values.length-1].soc_permille/10} percent. Temperature ${values[values.length-1].temperature_centi_c/100} Celsius. Simulated trend.`}>{[0,25,50,75,100].map(v=><g key={v}><path d={`M45 ${210-v/100*170}h330`} className="gridline"/><text x="6" y={215-v/100*170}>{v}</text><text x="380" y={215-v/100*170}>{v-20}</text></g>)}<polyline points={points(false)} className="soc-line"/><polyline points={points(true)} className="temp-line"/><text x="45" y="237">{start}s</text><text x="330" y="237">{end}s</text></svg><div className="chart-legend"><span><i className="line-key"/>SOC · % (left)</span><span><i className="line-key orange"/>Temperature · °C (right)</span></div></>
}
