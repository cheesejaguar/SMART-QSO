import { useEffect, useState } from "react";
type Progress = {
  faulted?: boolean;
  recovering?: boolean;
  active?: boolean;
  complete?: boolean;
  written?: number;
  accepted_version?: string;
  trial_version?: string;
  operations_done?: number;
  operations_total?: number;
  reason?: string;
  error?: string | null;
};
type Preview = {
  preparation_id: string;
  version: string;
  target_slot: number;
  length: number;
  sha256: string;
  effect: string;
};
async function request<T>(
  path: string,
  token: string,
  body?: unknown,
): Promise<T> {
  const response = await fetch(`/api/updates${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const value = await response.json();
  if (!response.ok)
    throw new Error(
      typeof value.detail === "string"
        ? value.detail
        : JSON.stringify(value.detail),
    );
  return value;
}
export function FirmwarePanel({
  disabled,
  available,
  token,
  onToken,
}: {
  disabled: boolean;
  available: boolean;
  token: string;
  onToken: (value: string) => void;
}) {
  const [file, setFile] = useState<File | null>(null),
    [preview, setPreview] = useState<Preview | null>(null),
    [progress, setProgress] = useState<Progress>({}),
    [reviewed, setReviewed] = useState(false),
    [resume, setResume] = useState(false),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState("");
  useEffect(() => {
    let live = true;
    const poll = () =>
      void request<Progress>("", token)
        .then((p) => {
          if (live) setProgress(p);
        })
        .catch(() => {
          if (live) setNotice("Update service unavailable");
        });
    poll();
    const timer = setInterval(poll, 5000);
    return () => {
      live = false;
      clearInterval(timer);
    };
  }, [token]);
  const action = async (fn: () => Promise<void>) => {
    setBusy(true);
    setNotice("");
    try {
      await fn();
    } catch (err) {
      setNotice((err as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const blocked = disabled || busy || !available || !token;
  return (
    <section className="panel" aria-label="Authenticated firmware updates">
      <h2>Authenticated firmware updates</h2>
      <p className="muted">
        File-backed simulation. The MCU verifies a separate firmware signature
        and every signed transfer command. SAFE mode, retained RF inhibit,
        payload off, adequate battery and temperature are required. Uploading an
        image does not confirm a successful boot.
      </p>
      {!available && (
        <p className="muted">
          Provision a command signer, operator token and separate update public
          key on the local service to enable this workflow.
        </p>
      )}
      <label>
        Firmware operator token
        <input
          type="password"
          autoComplete="off"
          value={token}
          onChange={(e) => onToken(e.target.value)}
        />
      </label>
      <label>
        Signed application image
        <input
          type="file"
          accept=".sqfw,.bin"
          disabled={disabled || busy}
          onChange={(e) => {
            setFile(e.target.files?.[0] ?? null);
            setPreview(null);
            setReviewed(false);
            setNotice("");
          }}
        />
      </label>
      <label className="review-check">
        <input
          type="checkbox"
          checked={resume}
          disabled={disabled || busy}
          onChange={(e) => {
            setResume(e.target.checked);
            setPreview(null);
            setReviewed(false);
          }}
        />
        Resume the same signed image after a reset or contact outage.
      </label>
      <button
        disabled={blocked || !file || !!progress.active}
        onClick={() =>
          void action(async () => {
            if (!file) return;
            if (file.size > 384 * 1024)
              throw new Error("Image exceeds the application slot");
            const bytes = new Uint8Array(await file.arrayBuffer());
            let binary = "";
            for (const b of bytes) binary += String.fromCharCode(b);
            setPreview(
              await request<Preview>("/prepare", token, {
                image_base64: btoa(binary),
              }),
            );
            setReviewed(false);
            setNotice(
              "Signature, content hash and target inspected. Review before writing.",
            );
          })
        }
      >
        Inspect signed image
      </button>
      {preview && (
        <div className="command-preview">
          <h3>Review firmware version {preview.version}</h3>
          <p>
            Target: application {preview.target_slot === 0 ? "A" : "B"} ·{" "}
            {preview.length.toLocaleString()} application bytes
          </p>
          <p className="firmware-hash">
            SHA-256 <code>{preview.sha256}</code>
          </p>
          <p>{preview.effect}</p>
          <label className="review-check">
            <input
              type="checkbox"
              checked={reviewed}
              disabled={disabled || busy}
              onChange={(e) => setReviewed(e.target.checked)}
            />
            I reviewed the target, version and shutdown requirements.
          </label>
          <button
            disabled={blocked || !reviewed}
            onClick={() =>
              void action(async () => {
                setProgress(
                  await request<Progress>("/begin", token, {
                    preparation_id: preview.preparation_id,
                    resume,
                  }),
                );
                setPreview(null);
                setReviewed(false);
                setNotice(
                  "Inactive-slot transfer opened. Continue with bounded batches.",
                );
              })
            }
          >
            Begin reviewed simulation update
          </button>
        </div>
      )}
      <p role="status">{notice}</p>
      <div className="safety-list">
        <div>
          <span>
            Accepted-version floor
            <strong>{progress.accepted_version ?? "Unavailable"}</strong>
          </span>
        </div>
        <div>
          <span>
            Transfer
            <strong>
              {progress.complete
                ? "Published; trial boot pending"
                : progress.recovering
                  ? "Rebuilding hash from durable checkpoints"
                  : progress.active
                    ? `${(progress.written ?? 0).toLocaleString()} bytes verified`
                    : "No active transfer"}
            </strong>
          </span>
        </div>
        <div>
          <span>
            Trial version
            <strong>{progress.trial_version ?? "Unavailable"}</strong>
          </span>
        </div>
      </div>
      {progress.active && (
        <button
          disabled={blocked}
          onClick={() =>
            void action(async () => {
              const p = await request<Progress>("/step", token, {});
              setProgress(p);
              setNotice(
                p.complete
                  ? "Signed image published. Boot/confirmation remain separate verification steps."
                  : "Batch verified. Continue transfer.",
              );
            })
          }
        >
          Transfer next batch
        </button>
      )}
      <button
        disabled={blocked || !progress.active}
        onClick={() =>
          void action(async () => {
            setProgress(await request<Progress>("/abort", token, {}));
            setPreview(null);
            setNotice("Transfer aborted; incomplete slot remains unpublished.");
          })
        }
      >
        Abort transfer
      </button>
      {progress.faulted && (
        <p className="error">
          Update I/O fault. Acceptance is disabled until the service or MCU
          restarts and reloads protected state.
        </p>
      )}
      {progress.error && <p className="error">{progress.error}</p>}
      <small>
        Signed resume verifies completed page checkpoints after a restart. Boot
        and recovery partitions cannot be remotely written. No physical device
        or radio is connected.
      </small>
    </section>
  );
}
