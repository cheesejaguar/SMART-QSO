import {defineConfig} from 'astro/config';
export default defineConfig({
  output: 'static',
  site: process.env.SQ_PUBLIC_SITE || undefined,
  base: process.env.SQ_PUBLIC_BASE || '/',
});
