// Astro also applies BASE_URL to generated styles/fonts. Explicit links need the same base.
export const sitePath = (path: string = '') =>
  `${import.meta.env.BASE_URL.replace(/\/$/, '')}/${path.replace(/^\//, '')}`;
export const consolePath = import.meta.env.PUBLIC_SQ_STATIC === '1'
  ? sitePath('participate/#local-demo')
  : sitePath('console/');
