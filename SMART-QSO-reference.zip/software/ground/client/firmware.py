"""Inspect/deliver authenticated firmware through an explicit KISS serial transport.

No transmission occurs without --send. Readable device receipts are unverified; a timeout
stops delivery rather than guessing whether a command ran. No browser sees either key.
"""

import argparse
import json
import time
from pathlib import Path

import serial

from software.common.firmware_update import inspect_image, transactions
from software.common.protocol import KINDS, KissDecoder, ax25_info, ax25_ui, kiss_encode, unpack
from software.common.protocol_generated import COMMANDS
from software.ground.service.signing import Signer
from software.ground.service.store import Store


def send_update(
    port,
    image: bytes,
    update_key: bytes,
    signer: Signer,
    sequences: Store,
    source: str,
    destination: str,
    floor: int = 0,
    timeout_s: float = 10,
    resume: bool = False,
    offset: int = 0,
    receipts: bool = True,
    pace_s: float = 2.5,
    recovery_wait_s: float = 10,
) -> dict:
    if not 0 < timeout_s <= 60:
        raise ValueError("Receipt timeout must be 0..60 seconds")
    if not 0 <= pace_s <= 60 or not 0 <= recovery_wait_s <= 60:
        raise ValueError("Invalid bounded pacing/recovery interval")
    info = inspect_image(image, update_key)
    if signer.public_key == update_key:
        raise ValueError("Command and firmware verification keys must be separate")
    decoder = KissDecoder()
    completed = 0
    for command_id, params in transactions(image, info["target_slot"], offset, resume):
        seq = sequences.sequence(floor)
        packet = signer.command(command_id, seq, params)
        wire = kiss_encode(ax25_ui(packet, source, destination))
        sequences.event(
            "serial-update-request",
            json.dumps({"command": command_id, "sequence": str(seq),
                        "image_sha256": info["sha256"], "frame_hex": packet.hex(),
                        "signer_public_key_hex": signer.public_key.hex()}),
            provenance="serial transport; RF provenance unknown",
        )
        if port.write(wire) != len(wire):
            raise OSError("Partial transport write; delivery stopped")
        port.flush()
        if not receipts:
            sequences.event(
                "serial-update-uplink",
                json.dumps({"sequence": seq, "execution_verified": False}),
                provenance="serial transport; RF provenance unknown",
            )
            completed += 1
            time.sleep(recovery_wait_s if command_id == COMMANDS["UPDATE_RESUME"] else pace_s)
            continue
        if command_id == COMMANDS["UPDATE_RESUME"]:
            time.sleep(recovery_wait_s)
        deadline = time.monotonic() + timeout_s
        receipt = None
        while time.monotonic() < deadline and receipt is None:
            for received in decoder.feed(port.read(256)):
                try:
                    kind, echoed, payload, _ = unpack(ax25_info(received))
                except ValueError:
                    continue
                if (
                    kind == KINDS["COMMAND_RESULT"]
                    and echoed == seq
                    and len(payload) == 2
                    and payload[0] == command_id
                ):
                    receipt = payload[1]
        sequences.event(
            "serial-update-receipt",
            json.dumps(
                {"sequence": seq, "result": receipt, "authentication": "unsigned/unverified"}
            ),
            provenance="serial transport; RF provenance unknown",
        )
        if receipt is None:
            raise TimeoutError(
                "Receipt missing; stop and reconcile persisted sequence/slot state before retry"
            )
        if receipt != 0:
            raise RuntimeError(
                f"Device rejected command {command_id}: result {receipt}; stop and reconcile"
            )
        completed += 1
    return {
        **info,
        "commands_sent": completed,
        "command_receipts_received": completed if receipts else 0,
        "receipt_authentication": "unsigned/unverified"
        if receipts
        else "No receipts; execution unverified",
        "boot_confirmed": False,
        "instruction_execution_verified": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=Path, required=True)
    parser.add_argument("--update-public-key", required=True)
    parser.add_argument("--command-key", type=Path)
    parser.add_argument("--sequence-db", type=Path)
    parser.add_argument("--sequence-floor", type=int, default=0)
    parser.add_argument("--port")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--source")
    parser.add_argument("--destination")
    parser.add_argument("--send", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--offset",
        type=int,
        default=0,
        help="Verified durable-page offset after signed resume/status reconciliation",
    )
    parser.add_argument(
        "--no-receipts",
        action="store_true",
        help="Explicit paced uplink-only mode when RF is inhibited; never reports execution success",
    )
    parser.add_argument("--pace", type=float, default=2.5)
    parser.add_argument("--recovery-wait", type=float, default=10)
    args = parser.parse_args()
    try:
        key = bytes.fromhex(args.update_public_key)
        image = args.image.read_bytes()
        info = inspect_image(image, key)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    if not args.send:
        print(
            json.dumps(
                {
                    **info,
                    "transmitted": False,
                    "commands": len(
                        transactions(image, info["target_slot"], args.offset, args.resume)
                    ),
                },
                indent=2,
            )
        )
        return
    if not all((args.command_key, args.sequence_db, args.source, args.destination, args.port)):
        parser.error(
            "--send requires command key, sequence database, callsigns and explicit serial port"
        )
    if (
        not args.port.startswith("/dev/")
        or not 1200 <= args.baud <= 921600
        or args.sequence_floor < 0
    ):
        parser.error("Invalid serial device, baud or sequence floor")
    signer = Signer(args.command_key)
    store = Store(args.sequence_db)
    with serial.Serial(args.port, args.baud, timeout=0.1, write_timeout=2) as port:
        print(
            json.dumps(
                send_update(
                    port,
                    image,
                    key,
                    signer,
                    store,
                    args.source,
                    args.destination,
                    args.sequence_floor,
                    resume=args.resume,
                    offset=args.offset,
                    receipts=not args.no_receipts,
                    pace_s=args.pace,
                    recovery_wait_s=args.recovery_wait,
                ),
                indent=2,
            )
        )


if __name__ == "__main__":
    main()
