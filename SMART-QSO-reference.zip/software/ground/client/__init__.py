"""Ordinary KISS TNC reference client."""
