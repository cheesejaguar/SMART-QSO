"""Create/receive SMART-QSO AX.25 packets; transmitting requires explicit --send."""

import argparse
import json
import secrets

from software.common.protocol import (
    KINDS,
    KissDecoder,
    RelayMessage,
    acknowledgment,
    ax25_info,
    ax25_ui,
    decode_description,
    decode_health,
    kiss_encode,
    relay_request,
    unpack,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from", dest="sender", required=True)
    parser.add_argument("--to", dest="destination")
    parser.add_argument("--text")
    parser.add_argument(
        "--request",
        action="store_true",
        help="Request a queued message for --from during this contact",
    )
    parser.add_argument("--id", type=int)
    parser.add_argument("--ack", type=int, help="Acknowledge a received message as --from")
    parser.add_argument(
        "--satellite",
        default="N0CALL",
        help="Reference development address; replace after callsign coordination",
    )
    parser.add_argument("--ttl", type=int, default=3600)
    parser.add_argument("--port", help="Serial KISS TNC path")
    parser.add_argument("--baud", type=int, default=115200, help="UART speed, not RF baud")
    parser.add_argument(
        "--send",
        action="store_true",
        help="Explicitly transmit using a licensed/coordinated station",
    )
    parser.add_argument("--receive", action="store_true")
    args = parser.parse_args()
    if args.port and not args.port.startswith("/dev/"):
        parser.error("Use an explicit /dev/ serial device")
    if not 1200 <= args.baud <= 921600:
        parser.error("Unsupported UART baud")
    if sum((args.receive, args.request, args.ack is not None, args.text is not None)) != 1:
        parser.error("Choose exactly one of --receive, --request, --ack or --text")
    if args.receive:
        if not args.port:
            parser.error("--receive requires --port")
        import serial

        decoder = KissDecoder()
        with serial.Serial(args.port, args.baud, timeout=1) as tnc:
            try:
                while True:
                    for packet in decoder.feed(tnc.read(512)):
                        try:
                            info = ax25_info(packet)
                            kind, sequence, payload, _ = unpack(info)
                            if kind == KINDS["MESSAGE"]:
                                decoded = {"kind": "message", **RelayMessage.decode(info).__dict__}
                            elif kind == KINDS["HEALTH"]:
                                decoded = {"kind": "health", **decode_health(info)}
                                if not decoded["flags"] & 16:
                                    decoded["soc_permille"] = None
                                    decoded["temperature_centi_c"] = None
                            elif kind == KINDS["DESCRIPTION"]:
                                decoded = {
                                    "kind": "advisory-description",
                                    **decode_description(info),
                                }
                            elif kind == KINDS["COMMAND_RESULT"] and len(payload) == 2:
                                decoded = {
                                    "kind": "unsigned-command-receipt",
                                    "sequence": str(sequence),
                                    "command_id": payload[0],
                                    "result": payload[1],
                                    "execution_verified": False,
                                }
                            else:
                                continue
                            print(json.dumps(decoded), flush=True)
                        except ValueError:
                            continue
            except KeyboardInterrupt:
                return
    if args.request or args.ack is not None:
        raw = relay_request(args.sender) if args.request else acknowledgment(args.ack, args.sender)
        wire = kiss_encode(ax25_ui(raw, args.sender, args.satellite))
        if args.send:
            if not args.port:
                parser.error("--send requires --port")
            import serial

            with serial.Serial(args.port, args.baud, timeout=1, write_timeout=1) as tnc:
                if tnc.write(wire) != len(wire):
                    raise OSError("Partial request write")
        print(
            json.dumps(
                {
                    "station": args.sender,
                    "kind": "request" if args.request else "acknowledgment",
                    "kiss_hex": wire.hex(),
                    "sent": args.send,
                }
            )
        )
        return
    if args.text and not args.destination:
        parser.error("--text requires --to recipient")
    if not args.text:
        parser.error("--text required for message creation")
    msg = RelayMessage(
        args.id if args.id is not None else secrets.randbits(63),
        args.sender,
        args.destination,
        args.text,
        args.ttl,
    )
    packet = kiss_encode(ax25_ui(msg.encode(), args.sender, args.satellite))
    if args.send:
        if not args.port:
            parser.error("--send requires --port")
        import serial

        with serial.Serial(args.port, args.baud, timeout=1, write_timeout=1) as tnc:
            if tnc.write(packet) != len(packet):
                raise OSError("Partial station packet write")
    print(json.dumps({"message": msg.__dict__, "kiss_hex": packet.hex(), "sent": args.send}))


if __name__ == "__main__":
    main()
