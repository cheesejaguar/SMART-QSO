"""SGP4 fixture is Vanguard verification data, not a SMART-QSO operational orbit."""

import math
from datetime import UTC, datetime

import pytest
from sgp4.propagation import gstime

from software.ground.service.passes import look_angles, predict

L1 = "1 00005U 58002B   00179.78495062  .00000023  00000-0  28098-4 0  4753"
L2_BODY = "2 00005  34.2682 331.5174 1849677 331.7664  19.3264 10.8241915741366"
L2 = L2_BODY + str(sum(int(c) if c.isdigit() else 1 if c == "-" else 0 for c in L2_BODY) % 10)


def test_overhead_and_horizon_geometry():
    jd = 2451545.0
    angle = gstime(jd)
    position = (6878.137 * math.cos(angle), 6878.137 * math.sin(angle), 0)
    elevation, distance = look_angles(position, jd, 0, 0, 0)
    assert elevation == pytest.approx(90)
    assert distance == pytest.approx(500)


def test_bounded_propagation_and_no_operational_claim():
    result = predict(L1, L2, 37, -122, 0, datetime(2000, 6, 29, tzinfo=UTC))
    assert result["satellite_id"] == 5
    assert result["provenance"] == "operator-supplied TLE estimate"
    assert result["resolution_s"] == 30
    assert all(10 <= p["maximum_elevation_deg"] <= 90 for p in result["passes"])
    stale = predict(L1, L2, 37, -122, 0, datetime(2000, 7, 10, tzinfo=UTC), hours=1)
    assert stale["stale"]


def test_invalid_tle_and_unbounded_window_rejected():
    with pytest.raises(ValueError, match="checksum"):
        predict(L1[:-1] + "0", L2, 0, 0, 0, datetime.now(UTC))
    with pytest.raises(ValueError, match="limits"):
        predict(L1, L2, 0, 0, 0, datetime.now(UTC), hours=25)
    with pytest.raises(ValueError, match="timezone"):
        predict(L1, L2, 0, 0, 0, datetime(2000, 6, 29))
