# Ground demonstration and station client

The service shares the C mission core with the STM32 reference image. It binds only to 127.0.0.1. HTTP activity changes the local simulation, never RF. Public station frames remain readable; commands are authenticated separately.

## Build and run

```
uv sync --frozen --extra dev
cmake -S software/flight -B build
cmake --build build
npm --prefix software/web ci
npm --prefix software/web run build
uv run python -m software.ground.service.app
```

Open http://127.0.0.1:8000/ and /console/. Simulation timestamps/freshness are visible. Advance 60 seconds for trends. Submit a message on Relay; per-sender quotas and persistent duplicates apply. Simulate the 1800-second deployment wait before enabling relay.

## Local development signing

Run `uv run python -m tools.provision_operator`. The key and operator token are owner-only files under ignored `.state/operator/`. Do not commit them. Supply `SQ_SIGNING_KEY` with the absolute signer PEM path and `SQ_OPERATOR_TOKEN` from the token file when launching the local service. Paste the token into the console's operator-token field after reviewing a command. The browser never receives the signing key. Before hardware provisioning, separate operator and software-update keys, review custody/backup/rotation, and replace development credentials.

Changing the key on an existing database is not an automatic re-provisioning operation. Preserve/review the replay floor and device public-key configuration. With no signer the console remains useful and command previews are non-executable. A corrupt state database refuses startup; recover a reviewed backup rather than deleting the replay history.

After simulation deployment, review and execute SET_MODE (RELAY) and TX_ENABLE. Then attempt the next packet and record the recipient acknowledgment. TX_DISABLE persists the inhibit before acceptance. RESET enters SAFE. These are local demonstrations, not transmitted commands.

## Radio client

`uv run python -m software.ground.client.packet --from W6ABC --to K6XYZ --text "73!"` emits a KISS frame without sending. Add `--send --port /dev/ttyUSB0` only for an authorized, licensed and coordinated station. UART baud defaults to 115200; RF remains 1200 baud AFSK via your TNC. Use `--receive` for bounded streaming decode. The TNC supplies HDLC/FCS and modem behavior. Ground acknowledgments are readable and spoofable; verified mission delivery requires corroborating recipient logs, not a bare ACK counter.

## Operations gate

A live spacecraft adapter, selected-radio HIL, verified ACK/telemetry semantics, named licensed operators, primary/backup stations and commissioning rehearsals remain required before flight operations. The archive replay endpoint is read-only; console replay disables commanding. No API presents demonstration telemetry as live spacecraft data.

## Reference pass estimates

The console Passes view and `/api/passes` require operator-supplied complete, checksum-valid TLEs and a station location. No mission orbit or invented passes are supplied. SGP4 estimates use a WGS84 station and a GMST TEME/Earth-fixed approximation, a 10° console elevation mask, and 30-second sampling; narrow contacts can be missed. TLE age and clipped windows are explicit. EOP/refraction, RF success and approved flight ephemerides require a selected operational tracking system. Planning never enables the transmitter.

## Payload and firmware integration

See [payload integration](../../docs/resurrection/PAYLOAD_INTEGRATION.md) and [authenticated update/recovery](../../docs/resurrection/FIRMWARE_UPDATES.md). Set `SQ_UPDATE_PUBLIC_KEY` separately from the command signer to enable the simulation console's signed-image inspection, bounded transfer and durable resume. Firmware is signed offline with a separate owner-only private key; only its public key reaches the service. No image/runtime artifact is implicitly trusted.

The serial firmware CLI `uv run python -m software.ground.client.firmware` inspects without transmitting unless `--send` is explicit. Missing receipts stop delivery; uplink-only mode is explicit and never claims execution. Request queued messages with `software.ground.client.packet --from K6XYZ --request`; acknowledge with `--ack <message-id>`. All station commands default to no transmission. END_MISSION is a persistent software retirement latch; physical battery passivation remains a separate required circuit/test.
