"""Crash-consistent mission snapshots and command audit log."""

import sqlite3
import threading
from datetime import UTC, datetime
from pathlib import Path


class Store:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), image BLOB NOT NULL);
        CREATE TABLE IF NOT EXISTS sequences(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, timestamp TEXT NOT NULL, kind TEXT NOT NULL, provenance TEXT NOT NULL, detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS telemetry(id INTEGER PRIMARY KEY, timestamp TEXT NOT NULL, provenance TEXT NOT NULL, uptime_s INTEGER NOT NULL, soc_permille INTEGER NOT NULL, temperature_centi_c INTEGER NOT NULL);
        """)
        # SQLite INTEGER is signed 64-bit. Migrate the old counter atomically to
        # canonical decimal text so all wire uint64 nonces remain exact.
        with self.lock, self.db:
            self.db.execute("BEGIN IMMEDIATE")
            columns = self.db.execute("PRAGMA table_info(sequences)").fetchall()
            if next(row["type"] for row in columns if row["name"] == "value") != "TEXT":
                self.db.execute("ALTER TABLE sequences RENAME TO old_sequences")
                self.db.execute("CREATE TABLE sequences(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)")
                self.db.execute("INSERT INTO sequences SELECT id, CAST(value AS TEXT) FROM old_sequences")
                self.db.execute("DROP TABLE old_sequences")

    def save(self, image: bytes) -> bool:
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO state VALUES (1,?) ON CONFLICT(id) DO UPDATE SET image=excluded.image",
                (image,),
            )
        return True

    def load(self) -> bytes | None:
        row = self.db.execute("SELECT image FROM state WHERE id=1").fetchone()
        return bytes(row[0]) if row else None

    def sequence(self, floor: int, terminal: bool = False) -> int:
        if type(floor) is not int or not 0 <= floor < 2**64:
            raise ValueError("Invalid signing sequence floor")
        with self.lock, self.db:
            self.db.execute("BEGIN IMMEDIATE")
            row = self.db.execute("SELECT value FROM sequences WHERE id=1").fetchone()
            previous = row[0] if row else "0"
            if not isinstance(previous, str) or not previous.isascii() or not previous.isdecimal():
                raise RuntimeError("Corrupt signing sequence: recovery review required")
            seq = max(int(previous), floor) + 1
            if seq >= 2**64 or (seq == 2**64 - 1 and not terminal):
                raise RuntimeError("Signing sequence exhausted: key/control review required")
            self.db.execute(
                "INSERT INTO sequences VALUES (1,?) ON CONFLICT(id) DO UPDATE SET value=excluded.value",
                (str(seq),),
            )
            return seq

    def event(self, kind: str, detail: str, provenance: str = "simulation"):
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO events(timestamp,kind,provenance,detail) VALUES (?,?,?,?)",
                (datetime.now(UTC).isoformat(), kind, provenance, detail),
            )

    def sample(self, status: dict, provenance: str = "simulation"):
        with self.lock, self.db:
            self.db.execute(
                "INSERT INTO telemetry(timestamp,provenance,uptime_s,soc_permille,temperature_centi_c) VALUES (?,?,?,?,?)",
                (
                    datetime.now(UTC).isoformat(),
                    provenance,
                    status["uptime_s"],
                    status["soc_permille"],
                    status["temperature_centi_c"],
                ),
            )
            self.db.execute(
                "DELETE FROM telemetry WHERE id NOT IN (SELECT id FROM telemetry ORDER BY id DESC LIMIT 10000)"
            )

    def rows(self, table: str, limit: int = 120) -> list[dict]:
        if table not in ("telemetry", "events"):
            raise ValueError("Unknown archive")
        return [
            dict(r)
            for r in self.db.execute(
                f"SELECT * FROM {table} ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        ][::-1]
