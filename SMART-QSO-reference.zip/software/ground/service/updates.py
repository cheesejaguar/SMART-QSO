"""Operator-guarded simulation update sessions, using signed commands and the MCU writer."""

from __future__ import annotations

import base64
import json
import secrets
import time
from pathlib import Path

from software.common.core import MissionCore
from software.common.firmware_update import FirmwareUpdater, FlashStore, inspect_image, transactions
from software.common.protocol_generated import COMMANDS

from .signing import Signer
from .store import Store


class UpdateSession:
    def __init__(self, core: MissionCore, store: Store, directory: Path, key: bytes):
        self.core, self.store, self.key = core, store, key
        self.updater = FirmwareUpdater(core, FlashStore(directory), key)
        self.prepared: dict | None = None
        self.operations: list[tuple[int, bytes]] = []
        self.at = 0
        self.error: str | None = None
        self.resuming = False
        self.transfer_image: bytes | None = None
        self.target = 0

    def prepare(self, encoded: str) -> dict:
        if self.updater.status()["active"]:
            raise ValueError("Abort the existing update first")
        self.prepared = None
        image = base64.b64decode(encoded, validate=True)
        info = inspect_image(image, self.key)
        if int(info["version"]) <= int(self.updater.status()["accepted_version"]):
            raise ValueError("Image version must exceed the persistent accepted-version floor")
        self.prepared = {
            "id": secrets.token_hex(16),
            "expires": time.monotonic() + 120,
            "image": image,
            "info": info,
        }
        return {
            "preparation_id": self.prepared["id"],
            **info,
            "provenance": "file-backed simulation",
            "hardware_written": False,
            "effect": "Write inactive slot; publish signed manifest after verification; boot remains a separate action",
        }

    def command(self, signer: Signer, operation: tuple[int, bytes]) -> int:
        command, params = operation
        try:
            seq = self.store.sequence(self.core.status()["sequence"])
        except RuntimeError as exc:
            raise ValueError(str(exc)) from exc
        packet = signer.command(command, seq, params)
        self.store.event("update-command-request", json.dumps({
            "id": command, "sequence": str(seq), "frame_hex": packet.hex(),
            "signer_public_key_hex": signer.public_key.hex(), "rf_transmitted": False,
        }))
        code = self.core.receive(packet)
        self.store.event("update-command-result", f"id={command} sequence={seq} result={code}")
        return code

    def begin(self, preparation_id: str, signer: Signer, resume: bool = False) -> int:
        prepared = self.prepared
        if not prepared or not secrets.compare_digest(prepared["id"], preparation_id):
            raise ValueError("Unknown preparation; inspect the signed image first")
        self.prepared = None
        if time.monotonic() > prepared["expires"]:
            raise ValueError("Preparation expired")
        self.operations = transactions(
            prepared["image"], prepared["info"]["target_slot"], resume=resume
        )
        self.at = 0
        self.error = None
        self.transfer_image = prepared["image"]
        self.target = prepared["info"]["target_slot"]
        self.resuming = resume
        code = self.command(signer, self.operations[0])
        if code == 0:
            self.at = 1
        else:
            self.error = f"Begin rejected: {code}"
            self.operations = []
        return code

    def step(self, signer: Signer, chunks: int = 8) -> int:
        if self.resuming:
            current = self.updater.status()
            if current["recovering"]:
                return 0
            if not current["active"]:
                raise ValueError("Resume verification failed")
            assert self.transfer_image is not None
            self.operations = transactions(
                self.transfer_image, self.target, offset=current["written"], resume=True
            )
            self.at = 1
            self.resuming = False
        if not self.operations or self.at == len(self.operations):
            raise ValueError("No active transfer")
        if not 1 <= chunks <= 8:
            raise ValueError("At most eight commands per service step")
        for _ in range(chunks):
            code = self.command(signer, self.operations[self.at])
            if code:
                self.error = f"Transfer rejected at operation {self.at}: {code}"
                self.operations = []
                return code
            self.at += 1
            if self.at == len(self.operations):
                break
        return 0

    def abort(self, signer: Signer) -> int:
        code = self.command(signer, (COMMANDS["UPDATE_ABORT"], b""))
        if code == 0:
            self.operations = []
            self.prepared = None
            self.error = None
        return code

    def status(self) -> dict:
        return {
            **self.updater.status(),
            "operations_done": self.at,
            "operations_total": len(self.operations),
            "error": self.error,
            "prepared": self.prepared is not None,
            "restart_policy": "Signed resume verifies durable page checkpoints; unfinished page retransmitted; final hash/signature mandatory",
            "boot_confirmation": "Trial/rollback must be exercised separately; upload is not confirmation",
        }
