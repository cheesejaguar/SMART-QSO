"""Local ground demonstration service; no RF hardware is connected by default."""
