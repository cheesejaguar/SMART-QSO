"""Private signing material stays in an operator-provisioned local file."""

import os
import stat
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
    load_pem_private_key,
)

from software.common.protocol import KINDS, frame
from software.common.protocol_generated import COMMANDS


class Signer:
    def __init__(self, path: Path):
        if path.is_symlink() or stat.S_IMODE(path.stat().st_mode) & 0o077:
            raise ValueError("Signing key must be a non-symlink file readable only by its owner")
        if path.stat().st_uid != os.getuid():
            raise ValueError("Signing key must belong to the service operator")
        key = load_pem_private_key(path.read_bytes(), password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise ValueError("An Ed25519 key is required")
        self._key = key
        self.public_key = key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)

    def command(self, command_id: int, sequence: int, params: bytes = b"") -> bytes:
        if sequence == 2**64 - 1 and command_id != COMMANDS["END_MISSION"]:
            raise ValueError("Terminal telecommand sequence is reserved for END_MISSION")
        raw = frame(KINDS["COMMAND"], sequence, bytes([command_id]) + params)
        return raw + self._key.sign(raw)

    def sign_manifest(self, manifest: bytes) -> bytes:
        if len(manifest) != 48 or manifest[:4] != b"SQFW":
            raise ValueError("Invalid update manifest")
        return self._key.sign(manifest)
