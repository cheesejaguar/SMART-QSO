"""Local simulation/replay service sharing the firmware C core.

Hardware transport is intentionally explicit: this API never silently transmits RF.
"""

from __future__ import annotations

import argparse
import json
import os
import secrets
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware

from software.common.core import ROOT, MissionCore
from software.common.obc_payload import ObcPayload
from software.common.protocol import RelayMessage, acknowledgment
from software.common.protocol_generated import COMMANDS

from .passes import predict
from .signing import Signer
from .store import Store
from .updates import UpdateSession


class MessageRequest(BaseModel):
    id: int = Field(ge=0, lt=2**64)
    sender: str = Field(min_length=3, max_length=9)
    destination: str = Field(min_length=3, max_length=9)
    text: str = Field(min_length=1, max_length=128)
    ttl_s: int = Field(default=3600, ge=1, le=86400)


class CommandRequest(BaseModel):
    name: Literal[
        "NOP",
        "RESET",
        "GET_STATUS",
        "TX_ENABLE",
        "TX_DISABLE",
        "PAYLOAD_ENABLE",
        "PAYLOAD_DISABLE",
        "SET_MODE",
        "END_MISSION",
    ]
    mode: int | None = Field(default=None, ge=0, le=2)


class UpdatePrepareRequest(BaseModel):
    image_base64: str = Field(min_length=2744, max_length=524288)


class UpdateBeginRequest(BaseModel):
    preparation_id: str = Field(min_length=32, max_length=32)
    resume: bool = False


class PayloadResponseRequest(BaseModel):
    frame_hex: str = Field(min_length=48, max_length=480)


class AdvanceRequest(BaseModel):
    seconds: int = Field(default=60, ge=0, le=86400)
    soc_permille: int = Field(default=760, ge=0, le=1000)
    temperature_centi_c: int = Field(default=2200, ge=-5000, le=10000)
    separation: bool = False


class PassRequest(BaseModel):
    line1: str = Field(min_length=69, max_length=69)
    line2: str = Field(min_length=69, max_length=69)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    altitude_m: float = Field(default=0, ge=-500, le=10000)
    start_utc: datetime
    hours: int = Field(default=24, ge=1, le=24)
    minimum_elevation: float = Field(default=10, ge=0, le=90)


class AckRequest(BaseModel):
    id: int = Field(ge=0, lt=2**64)
    recipient: str = Field(min_length=3, max_length=9)


RESULTS = [
    "accepted",
    "invalid",
    "authentication failed",
    "replay rejected",
    "queue or sender quota full",
    "duplicate",
    "storage failure",
    "not allowed",
    "not found",
]


def create_app(
    db_path: Path | None = None,
    key_path: Path | None = None,
    operator_token: str | None = None,
    update_key: bytes | None = None,
    service_port: int = 8000,
) -> FastAPI:
    if not 1 <= service_port <= 65535:
        raise ValueError("Invalid local service port")
    origins = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        f"http://localhost:{service_port}",
        f"http://127.0.0.1:{service_port}",
    ]
    store = Store(db_path or Path(os.environ.get("SQ_DATABASE", ".state/mission.sqlite")))
    key_path = key_path or (
        Path(os.environ["SQ_SIGNING_KEY"]) if os.environ.get("SQ_SIGNING_KEY") else None
    )
    token = operator_token or os.environ.get("SQ_OPERATOR_TOKEN")
    signer = Signer(key_path) if key_path else None
    core = MissionCore(signer.public_key if signer else bytes(32), store.save, store.load())
    payload = ObcPayload(core)
    pending_payload_request = b""
    update_key = update_key or (
        bytes.fromhex(os.environ["SQ_UPDATE_PUBLIC_KEY"])
        if os.environ.get("SQ_UPDATE_PUBLIC_KEY")
        else None
    )
    if update_key is not None and (len(update_key) != 32 or not any(update_key)):
        raise ValueError("Firmware verification key must be 32 nonzero bytes")
    if update_key is not None and signer is not None and update_key == signer.public_key:
        raise ValueError("Command and firmware verification keys must be separate")
    updates = (
        UpdateSession(core, store, store.path.parent / (store.path.stem + "-flash"), update_key)
        if update_key
        else None
    )
    health_available = False
    if not store.load():
        health_available = True
        core.tick(0)
        store.save(core.snapshot())
        store.sample(core.status())
    app = FastAPI(title="SMART-QSO local mission service", version="1.0.0")
    app.add_middleware(
        TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "testserver"]
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "Authorization"],
    )
    app.state.core, app.state.store = core, store

    def allowed_origin(request: Request):
        origin = request.headers.get("origin")
        if origin and origin not in origins:
            raise HTTPException(403, "Untrusted request origin")

    def operator(request: Request):
        allowed_origin(request)
        supplied = request.headers.get("authorization", "").removeprefix("Bearer ")
        if not token or not secrets.compare_digest(supplied, token):
            raise HTTPException(401, "An operator-provisioned bearer token is required")

    def result(code: int):
        if code != 0:
            raise HTTPException(
                409 if code in (3, 4, 5, 7, 8) else 503 if code == 6 else 400, RESULTS[code]
            )

    @app.get("/api/status")
    def status():
        with store.lock:
            history = store.rows("telemetry")
            observed = history[-1]["timestamp"] if history and health_available else None
            age = (
                (datetime.now(UTC) - datetime.fromisoformat(observed)).total_seconds()
                if observed
                else None
            )
            return {
                **core.status(),
                "sequence": str(core.status()["sequence"]),
                "mode_name": ["SAFE", "IDLE", "RELAY"][core.status()["mode"]],
                "provenance": "simulation",
                "connection": "No spacecraft connection",
                "observed_at": observed,
                "age_s": age,
                "stale": age is None or age > 120,
                "signer_available": signer is not None and token is not None,
                "description": payload.status()["text"]
                if health_available
                else "Safe mode. Battery telemetry unavailable. Radio inhibited.",
                "health_available": health_available,
                "soc_permille": core.status()["soc_permille"] if health_available else None,
                "temperature_centi_c": core.status()["temperature_centi_c"]
                if health_available
                else None,
                "capacity": 32,
                "payload_supervisor": payload.status(),
                "updates_available": updates is not None
                and signer is not None
                and token is not None,
            }

    @app.get("/api/messages")
    def messages():
        with store.lock:
            return {"provenance": "simulation", "messages": core.messages()}

    @app.post("/api/messages")
    def submit(body: MessageRequest, request: Request):
        allowed_origin(request)
        try:
            packet = RelayMessage(**body.model_dump()).encode()
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        with store.lock:
            code = core.receive(packet)
            store.event("message", json.dumps({"id": str(body.id), "result": RESULTS[code]}))
            result(code)
            return {"result": "accepted", "provenance": "simulation", "frame_hex": packet.hex()}

    @app.post("/api/ack")
    def ack(body: AckRequest, request: Request):
        allowed_origin(request)
        try:
            packet = acknowledgment(body.id, body.recipient)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        with store.lock:
            code = core.receive(packet)
            store.event("ack", json.dumps({"id": str(body.id), "result": RESULTS[code]}))
            result(code)
            return {"result": "acknowledged", "provenance": "simulation"}

    @app.post("/api/relay/next")
    def relay_next(request: Request):
        allowed_origin(request)
        with store.lock:
            code, packet = core.next()
            result(code)
            store.event("relay-attempt", json.dumps(packet))
            return {"provenance": "simulation", "message": packet, "rf_transmitted": False}

    @app.post("/api/simulation/advance")
    def advance(body: AdvanceRequest, request: Request):
        nonlocal health_available, pending_payload_request
        allowed_origin(request)
        with store.lock:
            current = core.status()["uptime_s"]
            if current + body.seconds >= 2**63:
                raise HTTPException(409, "Simulation archive clock exhausted; recovery review required")
            if body.separation:
                core.separation()
            core.tick(current + body.seconds, body.soc_permille, body.temperature_centi_c)
            produced = payload.poll()
            if produced:
                pending_payload_request = produced
            if not payload.status()["pending"]:
                pending_payload_request = b""
            if updates:
                updates.updater.status()
            store.save(core.snapshot())
            store.sample(core.status())
            health_available = True
            store.event("simulation-step", json.dumps(body.model_dump()))
            return status()

    @app.post("/api/commands/preview")
    def preview(body: CommandRequest):
        if body.name == "SET_MODE" and body.mode is None:
            raise HTTPException(422, "SET_MODE requires mode")
        return {
            "command_id": COMMANDS[body.name],
            "name": body.name,
            "authentication": "Ed25519",
            "provenance": "simulation",
            "effect": {
                "TX_DISABLE": "Retain transmit inhibit over reset; stop all relay attempts",
                "RESET": "Enter SAFE and disable payload request",
                "END_MISSION": "Permanently latch software retirement and RF/payload off. Rearming is rejected after reset. Physical battery passivation is not performed by this simulation.",
            }.get(body.name, "Validated by the deterministic mission core"),
            "executable": signer is not None and token is not None,
            "rf_transmitted": False,
        }

    @app.post("/api/commands/execute")
    def execute(body: CommandRequest, request: Request):
        operator(request)
        if signer is None:
            raise HTTPException(503, "No signing key provisioned")
        if body.name == "SET_MODE" and body.mode is None:
            raise HTTPException(422, "SET_MODE requires mode")
        with store.lock:
            try:
                seq = store.sequence(core.status()["sequence"], terminal=body.name == "END_MISSION")
            except RuntimeError as exc:
                raise HTTPException(503, str(exc)) from exc
            params = (
                bytes([body.mode]) if body.name == "SET_MODE" and body.mode is not None else b""
            )
            packet = signer.command(COMMANDS[body.name], seq, params)
            store.event("command-request", json.dumps({
                "name": body.name, "sequence": str(seq), "params_hex": params.hex(),
                "frame_hex": packet.hex(), "signer_public_key_hex": signer.public_key.hex(),
                "rf_transmitted": False,
            }))
            code = core.receive(packet)
            store.event(
                "command-result",
                json.dumps({"name": body.name, "sequence": seq, "result": RESULTS[code]}),
            )
            result(code)
            return {
                "result": "accepted",
                "sequence": str(seq),
                "provenance": "simulation",
                "rf_transmitted": False,
            }

    @app.post("/api/payload/request")
    def payload_request(request: Request):
        nonlocal pending_payload_request
        allowed_origin(request)
        with store.lock:
            packet = payload.poll() or pending_payload_request
            pending_payload_request = b""
            return {"request_hex": packet.hex(), **payload.status(), "provenance": "simulation"}

    @app.post("/api/payload/response")
    def payload_response(body: PayloadResponseRequest, request: Request):
        allowed_origin(request)
        try:
            packet = bytes.fromhex(body.frame_hex)
        except ValueError as exc:
            raise HTTPException(422, "Invalid hex frame") from exc
        with store.lock:
            code = payload.receive(packet)
            store.event("payload-result", json.dumps({"result": RESULTS[code]}))
            result(code)
            return {**payload.status(), "provenance": "simulation"}

    @app.get("/api/updates")
    def update_status():
        with store.lock:
            return (
                updates.status()
                if updates
                else {
                    "available": False,
                    "provenance": "simulation",
                    "reason": "Separate update public key must be provisioned",
                }
            )

    def update_guard(request: Request):
        operator(request)
        if updates is None or signer is None:
            raise HTTPException(
                503, "Command signer and separate firmware verification key required"
            )
        return updates, signer

    @app.post("/api/updates/prepare")
    def update_prepare(body: UpdatePrepareRequest, request: Request):
        session, signing = update_guard(request)
        with store.lock:
            try:
                prepared = session.prepare(body.image_base64)
                store.event("update-preview", json.dumps(prepared))
                return prepared
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc

    @app.post("/api/updates/begin")
    def update_begin(body: UpdateBeginRequest, request: Request):
        session, signing = update_guard(request)
        with store.lock:
            try:
                result(session.begin(body.preparation_id, signing, body.resume))
                return session.status()
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc

    @app.post("/api/updates/step")
    def update_step(request: Request):
        session, signing = update_guard(request)
        with store.lock:
            try:
                result(session.step(signing))
                return session.status()
            except ValueError as exc:
                raise HTTPException(409, str(exc)) from exc

    @app.post("/api/updates/abort")
    def update_abort(request: Request):
        session, signing = update_guard(request)
        with store.lock:
            result(session.abort(signing))
            return session.status()

    @app.get("/api/telemetry")
    def telemetry():
        with store.lock:
            return {"provenance": "simulation", "samples": store.rows("telemetry")}

    @app.get("/api/events")
    def events():
        with store.lock:
            return {"events": store.rows("events")}

    @app.get("/api/evidence")
    def evidence():
        return {
            name: json.loads((ROOT / f"mission/current/{name}.json").read_text())
            for name in ["baseline", "requirements", "findings", "gates", "work_packages"]
        }

    @app.post("/api/passes")
    def passes(body: PassRequest):
        try:
            return predict(
                body.line1,
                body.line2,
                body.latitude,
                body.longitude,
                body.altitude_m,
                body.start_utc,
                body.hours,
                body.minimum_elevation,
            )
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/api/replay")
    def replay():
        with store.lock:
            return {
                "provenance": "replay",
                "samples": store.rows("telemetry"),
                "commanding_enabled": False,
            }

    from fastapi.staticfiles import StaticFiles

    web = ROOT / "software/web/public/dist"
    if web.exists():
        app.mount("/", StaticFiles(directory=web, html=True), name="public")
    return app


def main():
    import uvicorn

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    uvicorn.run(create_app(service_port=args.port), host="127.0.0.1", port=args.port)


if __name__ == "__main__":
    main()
