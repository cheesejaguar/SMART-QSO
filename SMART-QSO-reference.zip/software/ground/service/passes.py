"""Bounded SGP4 pass estimates from operator-supplied TLEs; never a flight ephemeris."""

import math
from datetime import UTC, datetime, timedelta
from typing import TypedDict

from sgp4.api import Satrec, jday
from sgp4.propagation import gstime


class VisibilityPass(TypedDict):
    rise_utc: str
    peak_utc: str
    set_utc: str
    maximum_elevation_deg: float
    minimum_range_km: float
    clipped_start: bool
    clipped_end: bool


def look_angles(
    position: tuple, jd: float, latitude: float, longitude: float, altitude_m: float
) -> tuple[float, float]:
    # SGP4 TEME -> Earth-fixed approximation using Greenwich mean sidereal time.
    # Polar motion/EOP corrections and atmospheric refraction are not modeled.
    angle = gstime(jd)
    x = math.cos(angle) * position[0] + math.sin(angle) * position[1]
    y = -math.sin(angle) * position[0] + math.cos(angle) * position[1]
    z = position[2]
    lat, lon = math.radians(latitude), math.radians(longitude)
    a, eccentricity2 = 6378.137, 0.00669437999014
    radius = a / math.sqrt(1 - eccentricity2 * math.sin(lat) ** 2)
    dx = x - (radius + altitude_m / 1000) * math.cos(lat) * math.cos(lon)
    dy = y - (radius + altitude_m / 1000) * math.cos(lat) * math.sin(lon)
    dz = z - (radius * (1 - eccentricity2) + altitude_m / 1000) * math.sin(lat)
    east = -math.sin(lon) * dx + math.cos(lon) * dy
    north = (
        -math.sin(lat) * math.cos(lon) * dx
        - math.sin(lat) * math.sin(lon) * dy
        + math.cos(lat) * dz
    )
    up = (
        math.cos(lat) * math.cos(lon) * dx + math.cos(lat) * math.sin(lon) * dy + math.sin(lat) * dz
    )
    return math.degrees(math.atan2(up, math.hypot(east, north))), math.sqrt(
        dx * dx + dy * dy + dz * dz
    )


def predict(
    line1: str,
    line2: str,
    latitude: float,
    longitude: float,
    altitude_m: float,
    start: datetime,
    hours: int = 24,
    minimum_elevation: float = 10,
) -> dict:
    for number, line in enumerate((line1, line2), 1):
        if len(line) != 69 or not line.startswith(str(number) + " ") or not line[-1].isdigit():
            raise ValueError("Supply two complete 69-character TLE lines")
        checksum = sum(int(c) if c.isdigit() else 1 if c == "-" else 0 for c in line[:68]) % 10
        if checksum != int(line[-1]):
            raise ValueError("TLE checksum mismatch")
    if line1[2:7] != line2[2:7] or start.tzinfo is None:
        raise ValueError("TLE satellite IDs must agree and start must have a timezone")
    if not (
        -90 <= latitude <= 90
        and -180 <= longitude <= 180
        and -500 <= altitude_m <= 10000
        and 1 <= hours <= 24
        and 0 <= minimum_elevation <= 90
    ):
        raise ValueError("Station or time-window limits exceeded")
    satellite = Satrec.twoline2rv(line1, line2)
    start = start.astimezone(UTC)
    epoch = datetime(2000, 1, 1, 12, tzinfo=UTC) + timedelta(
        days=satellite.jdsatepoch + satellite.jdsatepochF - 2451545
    )
    active: VisibilityPass | None = None
    passes: list[VisibilityPass] = []
    # At most 2881 propagations. Rise/set resolution is 30 seconds; narrow passes can be missed.
    for seconds in range(0, hours * 3600 + 1, 30):
        at = start + timedelta(seconds=seconds)
        jd, fraction = jday(at.year, at.month, at.day, at.hour, at.minute, at.second)
        error, position, _ = satellite.sgp4(jd, fraction)
        if error:
            raise ValueError(f"SGP4 could not propagate the supplied TLE (code {error})")
        elevation, distance = look_angles(position, jd + fraction, latitude, longitude, altitude_m)
        if elevation >= minimum_elevation:
            if active is None:
                active = {
                    "rise_utc": at.isoformat(),
                    "peak_utc": at.isoformat(),
                    "maximum_elevation_deg": elevation,
                    "minimum_range_km": distance,
                    "clipped_start": seconds == 0,
                    "clipped_end": False,
                    "set_utc": at.isoformat(),
                }
            if elevation > active["maximum_elevation_deg"]:
                active["maximum_elevation_deg"], active["peak_utc"] = elevation, at.isoformat()
            active["minimum_range_km"] = min(active["minimum_range_km"], distance)
        if active is not None and (elevation < minimum_elevation or seconds == hours * 3600):
            active["set_utc"] = at.isoformat()
            active["clipped_end"] = seconds == hours * 3600
            passes.append(active)
            active = None
    return {
        "provenance": "operator-supplied TLE estimate",
        "satellite_id": satellite.satnum,
        "epoch_utc": epoch.isoformat(),
        "tle_age_days": (start - epoch).total_seconds() / 86400,
        "stale": abs((start - epoch).total_seconds()) > 7 * 86400,
        "resolution_s": 30,
        "limits": "Approximate TEME/Earth-fixed conversion; no EOP/refraction, link availability or approved mission orbit. Not for operational commanding.",
        "passes": passes,
    }
