#include "mission_core.h"

#include <stdio.h>
#include <string.h>
static uint8_t image[SQ_SNAPSHOT_BYTES];
static bool persist(const uint8_t *data, size_t n, void *context)
{
    (void)context;
    (void)memcpy(image, data, n);
    return true;
}
int main(void)
{
    SqMission mission;
    sq_init(&mission, NULL, persist, NULL);
    sq_tick(&mission, 0, 760, 2200);
    sq_separation(&mission);
    (void)printf(
        "SMART-QSO host demonstration: queue=%zu, TX inhibited=%d, unsigned commands rejected.\n",
        sq_queue_count(&mission),
        (int)mission.tx_inhibited);
    return (image[0U] == 0x53U) ? 0 : 1;
}
