/* Historical host/test support only. Not linked into current ARM firmware.
 * Legacy NASA/classification/heritage claims below are unverified; no compliance
 * or flight qualification is established. Current authority: mission/current/. */
/**
 * @file time_utils.c
 * @brief Time Utility Functions Implementation
 *
 * Provides time-related utility functions for the flight software.
 */

/* Required for clock_gettime on POSIX-compliant systems */
#define _XOPEN_SOURCE 600

#include "smart_qso.h"
#include "hal/hal_timer.h"

#include <time.h>

/*===========================================================================*/
/* Public API Implementation                                                  */
/*===========================================================================*/

uint64_t smart_qso_now_ms(void)
{
#ifdef SIMULATION_BUILD
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        return 0;
    }
    return (uint64_t)ts.tv_sec * 1000ULL + (uint64_t)(ts.tv_nsec / 1000000L);
#else
    return hal_timer_get_ms();
#endif
}
