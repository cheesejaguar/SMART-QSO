#ifndef SQ_PRODUCTION_FIXTURE_H
#define SQ_PRODUCTION_FIXTURE_H
/* Test-only keys and file-free persistence: never compiled into reference firmware. */
#include "journal.h"
#include "mission_core.h"
#include "monocypher-ed25519.h"
#include "payload_link.h"
#include "runtime.h"
#include "transport.h"
#include "update.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef struct
{
    SqMission mission;
    uint8_t saved[SQ_SNAPSHOT_BYTES];
    uint8_t secret[64], key[32];
    bool fail;
    size_t saves;
} SqTest;
static bool test_persist(const uint8_t *data, size_t size, void *context)
{
    SqTest *test = context;
    assert(size == sizeof(test->saved));
    if (test->fail) {
        return false;
    }
    memcpy(test->saved, data, size);
    test->saves++;
    return true;
}
static void test_init(SqTest *test)
{
    memset(test, 0, sizeof(*test));
    uint8_t seed[32] = {77};
    crypto_ed25519_key_pair(test->secret, test->key, seed);
    sq_init(&test->mission, test->key, test_persist, test);
    sq_tick(&test->mission, 0, 760, 2200);
}
static void test_header(uint8_t *frame, uint8_t kind, uint64_t sequence, size_t size)
{
    memset(frame, 0, SQ_FRAME_MAX);
    frame[0] = 'S';
    frame[1] = 'Q';
    frame[2] = SQ_PROTOCOL_VERSION;
    frame[3] = kind;
    for (unsigned i = 0; i < 8; i++) {
        frame[4 + i] = (uint8_t)(sequence >> (8 * i));
    }
    frame[12] = (uint8_t)size;
    frame[13] = (uint8_t)(size >> 8);
}
static size_t test_command_frame(SqTest *test,
                                 uint8_t *frame,
                                 uint8_t id,
                                 uint64_t sequence,
                                 int mode)
{
    test_header(frame, SQ_KIND_COMMAND, sequence, mode < 0 ? 1 : 2);
    frame[14] = id;
    if (mode >= 0) {
        frame[15] = (uint8_t)mode;
    }
    size_t length = sq_frame_finish(frame, mode < 0 ? 15 : 16, SQ_FRAME_MAX);
    crypto_ed25519_sign(&frame[length], test->secret, frame, length);
    return length + 64;
}
static SqResult test_command(SqTest *test, uint8_t id, uint64_t sequence, int mode)
{
    uint8_t frame[SQ_FRAME_MAX];
    size_t length = test_command_frame(test, frame, id, sequence, mode);
    return sq_receive(&test->mission, frame, length);
}
static void test_ready(SqTest *test)
{
    uint64_t separated = test->mission.time_s;
    assert(separated <= UINT64_MAX - 1800U);
    sq_separation(&test->mission);
    sq_tick(&test->mission, separated + 1800U, 760, 2200);
    assert(test_command(test, SQ_CMD_SET_MODE, 1, SQ_RELAY) == SQ_OK);
    assert(test_command(test, SQ_CMD_TX_ENABLE, 2, -1) == SQ_OK);
}
static SqResult test_message(SqTest *test,
                             uint64_t id,
                             const char *source,
                             const char *dest,
                             const char *text,
                             uint32_t ttl)
{
    uint8_t frame[SQ_FRAME_MAX];
    size_t size = strlen(text);
    assert(strlen(source) < 10 && strlen(dest) < 10 && size <= 128);
    test_header(frame, SQ_KIND_MESSAGE, id, 33 + size);
    for (unsigned i = 0; i < 8; i++) {
        frame[14 + i] = (uint8_t)(id >> (8 * i));
    }
    memcpy(&frame[22], source, strlen(source));
    memcpy(&frame[32], dest, strlen(dest));
    for (unsigned i = 0; i < 4; i++) {
        frame[42 + i] = (uint8_t)(ttl >> (8 * i));
    }
    frame[46] = (uint8_t)size;
    memcpy(&frame[47], text, size);
    return sq_receive(&test->mission, frame, sq_frame_finish(frame, 47 + size, sizeof(frame)));
}
static uint64_t test_le(const uint8_t *data, size_t size)
{
    uint64_t value = 0;
    for (size_t i = 0; i < size; i++) {
        value |= (uint64_t)data[i] << (8 * i);
    }
    return value;
}
#endif
