#include "mission_core.h"
#include "monocypher-ed25519.h"
#include "resource_advisor.h"

#include <stdio.h>
#include <string.h>
#define CHECK(x)                                                           \
    do {                                                                   \
        if (!(x)) {                                                        \
            fprintf(stderr, "Failed %s:%d: %s\n", __FILE__, __LINE__, #x); \
            return 1;                                                      \
        }                                                                  \
    } while (0)
static uint8_t saved[SQ_SNAPSHOT_BYTES];
static bool storage_fail;
static bool persist(const uint8_t *data, size_t n, void *context)
{
    (void)context;
    if (storage_fail) {
        return false;
    }
    memcpy(saved, data, n);
    return true;
}
static void header(uint8_t *frame, uint8_t kind, uint64_t seq, uint16_t len)
{
    memset(frame, 0, SQ_FRAME_MAX);
    frame[0] = 'S';
    frame[1] = 'Q';
    frame[2] = SQ_PROTOCOL_VERSION;
    frame[3] = kind;
    for (size_t i = 0; i < 8; i++) {
        frame[4 + i] = (uint8_t)(seq >> (i * 8));
    }
    frame[12] = (uint8_t)len;
    frame[13] = (uint8_t)(len >> 8);
}
static size_t cmd(uint8_t *frame, uint8_t id, uint64_t seq, const uint8_t secret[64])
{
    header(frame, 2, seq, 1);
    frame[14] = id;
    size_t n  = sq_frame_finish(frame, 15, SQ_FRAME_MAX);
    crypto_ed25519_sign(frame + n, secret, frame, n);
    return n + 64;
}
int main(void)
{
    SqMission m, restarted;
    uint8_t seed[32] = {1}, secret[64], key[32], frame[SQ_FRAME_MAX];
    crypto_ed25519_key_pair(secret, key, seed);
    sq_init(&m, key, persist, NULL);
    CHECK(m.tx_inhibited);
    CHECK(!sq_tx_allowed(&m));
    sq_tick(&m, 1, 760, 2200);
    sq_separation(&m);
    sq_tick(&m, 1801, 760, 2200);
    size_t len = cmd(frame, SQ_CMD_TX_ENABLE, 1, secret);
    CHECK(sq_receive(&m, frame, len) == SQ_OK);
    CHECK(!m.tx_inhibited);
    SqResourceAdvice advice = {.observed_s = 1801, .energy_mj = 12000, .contact_permille = 900};
    m.mode                  = SQ_RELAY;
    CHECK(sq_resource_admit(&m, &advice, true, 40000, 20000));
    CHECK(!sq_resource_admit(&m, &advice, true, 10000, 20000));
    advice.contact_permille = 100;
    CHECK(!sq_resource_admit(&m, &advice, true, 40000, 20000));
    CHECK(sq_resource_admit(&m, &advice, false, 40000, 20000));
    CHECK(sq_receive(&m, frame, len) == SQ_REPLAY);
    frame[20] ^= 1;
    CHECK(sq_receive(&m, frame, len) == SQ_AUTH);
    header(frame, 1, 7, 35);
    frame[14] = 7;
    memcpy(frame + 22, "W6ABC", 5);
    memcpy(frame + 32, "K6XYZ", 5);
    frame[42] = 60;
    frame[46] = 2;
    memcpy(frame + 47, "73", 2);
    CHECK(sq_receive(&m, frame, sq_frame_finish(frame, 49, sizeof(frame))) == SQ_OK);
    CHECK(sq_receive(&m, frame, sq_frame_finish(frame, 49, sizeof(frame))) == SQ_DUPLICATE);
    CHECK(sq_queue_count(&m) == 1);
    sq_init(&restarted, key, persist, NULL);
    CHECK(sq_load(&restarted, saved, sizeof(saved)) == SQ_OK);
    CHECK(restarted.command_sequence == 1);
    CHECK(sq_queue_count(&restarted) == 1);
    CHECK(restarted.mode == SQ_SAFE);
    len = cmd(frame, SQ_CMD_TX_DISABLE, 2, secret);
    CHECK(sq_receive(&m, frame, len) == SQ_OK);
    sq_init(&restarted, key, persist, NULL);
    CHECK(sq_load(&restarted, saved, sizeof(saved)) == SQ_OK);
    CHECK(restarted.tx_inhibited);
    saved[65] ^= 1;
    CHECK(sq_load(&restarted, saved, sizeof(saved)) == SQ_IO);
    CHECK(restarted.tx_inhibited);
    CHECK(sq_receive(&restarted, frame, len) == SQ_IO);
    storage_fail = true;
    len          = cmd(frame, SQ_CMD_NOP, 3, secret);
    CHECK(sq_receive(&m, frame, len) == SQ_IO);
    CHECK(m.tx_inhibited);
    CHECK(!m.storage_healthy);
    for (size_t n = 0; n < SQ_FRAME_MAX; n++) {
        memset(frame, 0, sizeof(frame));
        CHECK(sq_receive(&restarted, frame, n) != SQ_OK);
    }
    puts("Mission core: signatures, replay, persistence, corruption, inhibits, duplicate and "
         "bounded malformed frames verified.");
    return 0;
}
