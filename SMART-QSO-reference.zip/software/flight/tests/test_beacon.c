/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    SqPayload payload;
    sq_payload_init(&payload);
    uint8_t frame[SQ_FRAME_MAX];
    size_t length = sq_payload_beacon(&payload, &test.mission, 1, frame, sizeof(frame));
    assert(length && frame[3] == SQ_KIND_DESCRIPTION && frame[22] == 0
           && sq_frame_valid(frame, length));
    assert(strstr(sq_payload_description(&payload, &test.mission), "Safe mode"));
    sq_tick_unavailable(&test.mission, 1);
    assert(strstr(sq_payload_description(&payload, &test.mission), "telemetry unavailable"));
    assert(!sq_payload_beacon(&payload, &test.mission, 2, frame, 20));
    assert(!sq_payload_beacon(&payload, &test.mission, 2, NULL, sizeof(frame)));
    payload.accepted = true;
    payload.observed = 1;
    payload.soc      = 760;
    strcpy(payload.description, "Untrusted text");
    assert(strstr(sq_payload_description(&payload, &test.mission), "unavailable")
           && !payload.accepted);
    SqPeriodic schedule;
    assert(sq_periodic_init(&schedule, 60));
    assert(sq_periodic_due(&schedule, 0, false));
    assert(!sq_periodic_due(&schedule, 59, false));
    assert(sq_periodic_due(&schedule, 60, false));
    puts("test_beacon.c: production scenarios passed");
    return 0;
}
