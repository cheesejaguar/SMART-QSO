/* Production B-dot/calibration tests. No fake hardware/sun/TRIAD claims. */
#include "adcs.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
int main(void)
{
    SqMagCalibration calibration = {{0, 0, 0}, {1000000, 1000000, 1000000}, true};
    SqBdot controller;
    int32_t field[3] = {30000, 0, 10000}, moments[3] = {0}, output[3];
    assert(!sq_mag_calibrate(NULL, field, output));
    assert(output[0] == 0);
    assert(sq_mag_calibrate(&calibration, field, output));
    assert(output[0] == 30000);
    calibration.bias_nt[0]   = 1000;
    calibration.scale_ppm[0] = 1500000;
    assert(sq_mag_calibrate(&calibration, field, output) && output[0] == 43500);
    calibration.scale_ppm[0] = 499999;
    assert(!sq_mag_calibrate(&calibration, field, output));
    assert(!output[0]);
    calibration.bias_nt[0]   = 0;
    calibration.scale_ppm[0] = 1000000;
    sq_bdot_init(&controller, 50, 200000);
    assert(!sq_bdot_step(&controller, &calibration, field, 1000, true, true, moments));
    field[0] += 1000;
    assert(sq_bdot_step(&controller, &calibration, field, 2000, true, true, moments));
    assert(moments[0] == -50000 && moments[1] == 0 && moments[2] == 0);
    field[0] -= 2000;
    assert(sq_bdot_step(&controller, &calibration, field, 3000, true, true, moments));
    assert(moments[0] == 100000);
    field[0] = 200000;
    field[1] = 200000;
    field[2] = 200000;
    assert(sq_bdot_step(&controller, &calibration, field, 3100, true, true, moments));
    int64_t total = 0;
    for (unsigned i = 0; i < 3; i++) {
        assert(moments[i] >= -200000 && moments[i] <= 200000);
        total += moments[i] < 0 ? -(int64_t)moments[i] : moments[i];
    }
    assert(total <= 200000);
    assert(!sq_bdot_step(&controller, &calibration, field, 3099, true, true, moments));
    assert(!controller.history && !moments[0]);
    assert(!sq_bdot_step(&controller, &calibration, field, 4000, true, true, moments));
    assert(!sq_bdot_step(&controller, &calibration, field, 5000, true, false, moments));
    assert(!controller.history);
    assert(!sq_bdot_step(&controller, &calibration, field, 6000, false, true, moments));
    calibration.reviewed = false;
    assert(!sq_bdot_step(&controller, &calibration, field, 6000, true, true, moments));
    calibration.reviewed = true;
    field[0]             = INT32_MIN;
    assert(!sq_mag_calibrate(&calibration, field, output));
    sq_bdot_init(&controller, UINT32_MAX, 200000);
    assert(!sq_bdot_step(&controller, &calibration, field, 0, true, true, moments));
    moments[0] = 12345;
    assert(!sq_bdot_step(NULL, &calibration, field, 0, true, true, moments));
    assert(moments[0] == 0);
    int32_t inplace[3] = {30000, 0, 10000};
    assert(sq_mag_calibrate(&calibration, inplace, inplace) && inplace[0] == 30000);
    puts("ADCS: calibration bounds, B-dot sign, total actuation bound and fail-closed history "
         "passed");
    return 0;
}
