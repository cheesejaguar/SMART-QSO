#include "payload_link.h"
#include "transport.h"

#include <stdio.h>
#include <string.h>
#define CHECK(x)                                                            \
    do {                                                                    \
        if (!(x)) {                                                         \
            fprintf(stderr, "payload failure line %d: %s\n", __LINE__, #x); \
            return 1;                                                       \
        }                                                                   \
    } while (0)
static void response(uint8_t *f, const SqPayload *p, const char *text)
{
    size_t n = strlen(text);
    memset(f, 0, 240);
    memcpy(f, "SQ", 2);
    f[2] = SQ_PROTOCOL_VERSION;
    f[3] = SQ_KIND_PAYLOAD_RESULT;
    for (size_t i = 0; i < 8; i++) {
        f[4 + i]  = (uint8_t)(p->sequence >> (8U * i));
        f[14 + i] = (uint8_t)(p->observed >> (8U * i));
    }
    f[12] = (uint8_t)(9 + n);
    f[22] = (uint8_t)n;
    memcpy(f + 23, text, n);
    (void)sq_frame_finish(f, 23 + n, SQ_FRAME_MAX);
}
int main(void)
{
    SqMission m;
    SqPayload p;
    uint8_t f[240], wire[500], out[240];
    sq_init(&m, NULL, NULL, NULL);
    sq_payload_init(&p);
    CHECK(sq_payload_poll(&p, &m, f, sizeof(f)) == 0);
    CHECK(!p.powered);
    m.mode              = SQ_IDLE;
    m.payload_requested = true;
    sq_tick(&m, 0, 761, 2200);
    CHECK(sq_payload_poll(&p, &m, f, sizeof(f)) == 0 && p.powered);
    sq_tick(&m, 30, 761, 2200);
    CHECK(sq_payload_poll(&p, &m, f, sizeof(f)) == 33);
    CHECK(p.pending);
    response(f, &p, "Idle mode. Battery at 76.1%. Radio inhibited.");
    CHECK(sq_payload_receive(&p, &m, f, 27 + f[22]) == SQ_OK);
    CHECK(p.accepted);
    CHECK(sq_payload_receive(&p, &m, f, 27 + f[22]) == SQ_NOT_ALLOWED);
    sq_tick(&m, 35, 761, 2200);
    sq_payload_poll(&p, &m, f, sizeof(f));
    CHECK(!p.powered);
    sq_tick(&m, 635, 761, 2200);
    sq_payload_poll(&p, &m, f, sizeof(f));
    CHECK(p.powered);
    sq_tick(&m, 665, 761, 2200);
    CHECK(sq_payload_poll(&p, &m, f, sizeof(f)) == 33);
    response(f, &p, "Battery at 99%");
    CHECK(sq_payload_receive(&p, &m, f, 27 + f[22]) == SQ_INVALID);
    response(f, &p, "Idle mode. Idle mode");
    CHECK(sq_payload_receive(&p, &m, f, 27 + f[22]) == SQ_INVALID);
    response(f, &p, "In eclipse");
    CHECK(sq_payload_receive(&p, &m, f, 27 + f[22]) == SQ_INVALID);
    sq_tick(&m, 686, 761, 2200);
    CHECK(sq_payload_poll(&p, &m, f, sizeof(f)) == 0);
    CHECK(!p.powered && p.timeouts == 1);
    CHECK(strstr(sq_payload_description(&p, &m), "Battery at 76.1%"));
    sq_tick(&m, 1286, 761, 2200);
    sq_payload_poll(&p, &m, f, sizeof(f));
    CHECK(p.powered);
    sq_tick(&m, 1316, 761, 2200);
    CHECK(sq_payload_poll(&p, &m, f, sizeof(f)) == 33);
    response(f, &p, "73!");
    sq_tick(&m, 1317, 760, 2200);
    CHECK(sq_payload_receive(&p, &m, f, 30) == SQ_NOT_ALLOWED);
    m.time_s = 1;
    sq_payload_poll(&p, &m, f, sizeof(f));
    CHECK(!p.powered && p.faulted);
    SqKiss decoder;
    sq_kiss_init(&decoder);
    uint8_t escaped[] = {0xC0, 0xDB, 0x42};
    size_t n = sq_kiss_encode(escaped, 3, wire, sizeof(wire)), got = 0;
    for (size_t i = 0; i < n; i++) {
        size_t x = sq_raw_kiss_feed(&decoder, wire[i], out, sizeof(out));
        if (x) {
            got = x;
        }
    }
    CHECK(got == 3 && !memcmp(out, escaped, 3));
    for (size_t i = 0; i < 4000; i++) {
        memset(f, (int)(i % 256), sizeof(f));
        CHECK(sq_payload_receive(&p, &m, f, i % 241) != SQ_OK);
    }
    puts("Payload supervisor: independent facts, duplicates, timeout/power gate, rollover and "
         "malformed responses verified");
    return 0;
}
