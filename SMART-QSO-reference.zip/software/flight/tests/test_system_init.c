/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    assert(test_command(&test, SQ_CMD_PAYLOAD_ENABLE, 1, -1) == SQ_OK);
    test.mission.payload_on = true;
    test.fail               = true;
    assert(test_command(&test, SQ_CMD_NOP, 2, -1) == SQ_IO);
    assert(!test.mission.storage_healthy && test.mission.tx_inhibited && !test.mission.payload_on);
    assert(test.mission.mode == SQ_SAFE);
    SqMission no_storage;
    sq_init(&no_storage, test.key, NULL, NULL);
    sq_separation(&no_storage);
    assert(!no_storage.storage_healthy && no_storage.tx_inhibited);
    assert(sq_snapshot(&no_storage, NULL, 5952) == 0);
    assert(sq_snapshot(&no_storage, test.saved, 5951) == 0);
    puts("test_system_init.c: production scenarios passed");
    return 0;
}
