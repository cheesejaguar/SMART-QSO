#include "journal.h"
#include "monocypher-ed25519.h"
#include "update_stream.h"

#include <stdio.h>
#include <string.h>
#define CHECK(x)                                                           \
    do {                                                                   \
        if (!(x)) {                                                        \
            fprintf(stderr, "update failure line %d: %s\n", __LINE__, #x); \
            return 1;                                                      \
        }                                                                  \
    } while (0)
static uint8_t flash[2][SQ_SLOT_BYTES], saved[SQ_SNAPSHOT_BYTES];
static unsigned mutations, fail_at = 9999;
static bool persist_fail, corrupt;
static bool persist(const uint8_t *p, size_t n, void *ctx)
{
    (void)ctx;
    if (persist_fail) {
        return false;
    }
    memcpy(saved, p, n);
    return true;
}
static bool erase(void *ctx, unsigned s, uint32_t o)
{
    (void)ctx;
    if (mutations++ == fail_at) {
        return false;
    }
    if (s > 1U || o % 2048U || o > SQ_SLOT_BYTES - 2048U) {
        return false;
    }
    memset(flash[s] + o, 255, 2048);
    return true;
}
static bool write(void *ctx, unsigned s, uint32_t o, const uint8_t *p, size_t n)
{
    (void)ctx;
    if (mutations++ == fail_at) {
        memcpy(flash[s] + o, p, n / 2U);
        return false;
    }
    if (s > 1U || o > SQ_SLOT_BYTES - n) {
        return false;
    }
    memcpy(flash[s] + o, p, n);
    return true;
}
static bool read_flash(void *ctx, unsigned s, uint32_t o, uint8_t *p, size_t n)
{
    (void)ctx;
    if (s > 1U || o > SQ_SLOT_BYTES - n) {
        return false;
    }
    memcpy(p, flash[s] + o, n);
    if (corrupt) {
        p[0] ^= 1;
    }
    return true;
}
static bool save_boot(void *ctx, SqBootState *s)
{
    (void)ctx;
    (void)s;
    return mutations++ != fail_at;
}
static size_t command(uint8_t *f,
                      uint64_t sequence,
                      const uint8_t *p,
                      size_t n,
                      const uint8_t secret[64])
{
    memset(f, 0, SQ_FRAME_MAX);
    memcpy(f, "SQ", 2);
    f[2] = SQ_PROTOCOL_VERSION;
    f[3] = 2;
    for (size_t i = 0; i < 8; i++) {
        f[4 + i] = (uint8_t)(sequence >> (8U * i));
    }
    f[12] = (uint8_t)n;
    memcpy(f + 14, p, n);
    size_t total = sq_frame_finish(f, 14 + n, SQ_FRAME_MAX);
    crypto_ed25519_sign(f + total, secret, f, total);
    return total + 64;
}
int main(void)
{
    uint8_t seed[32] = {7}, secret[64], key[32], body[257], manifest[112], p[140], frame[240];
    crypto_ed25519_key_pair(secret, key, seed);
    memset(body, 0x42, sizeof(body));
    uint32_t vector[2] = {0x20018000U, 0x08070809U};
    memcpy(body, vector, 8);
    memset(manifest, 0, 112);
    memcpy(manifest, "SQFW", 4);
    manifest[4]  = 2;
    manifest[12] = 1;
    manifest[13] = 1;
    crypto_blake2b(manifest + 16, 32, body, sizeof(body));
    crypto_ed25519_sign(manifest + 48, secret, manifest, 48);
    for (unsigned fault = 0; fault < 10U; fault++) {
        memset(flash, 0xA5, sizeof(flash));
        SqMission m;
        SqUpdater u;
        SqBootState boot = {.accepted = 1, .confirmed = 1};
        sq_init(&m, key, persist, NULL);
        sq_tick(&m, 0, 760, 2200);
        mutations    = 0;
        fail_at      = fault;
        persist_fail = false;
        corrupt      = false;
        sq_update_init(&u, &m, &boot, key, 0, 0, erase, write, read_flash, save_boot, NULL);
        m.extended_command = sq_update_command;
        m.command_context  = &u;
        p[0]               = SQ_CMD_UPDATE_BEGIN;
        p[1]               = 1;
        memcpy(p + 2, manifest, 112);
        size_t n        = command(frame, 1, p, 114, secret);
        SqResult result = sq_receive(&m, frame, n);
        CHECK(sq_receive(&m, frame, n)
              != SQ_OK); /* persisted replay floor even when erase failed */
        uint64_t seq = 2;
        for (uint32_t off = 0; result == SQ_OK && off < sizeof(body); off += 128U) {
            size_t amount = sizeof(body) - off;
            if (amount > 128U) {
                amount = 128U;
            }
            p[0] = SQ_CMD_UPDATE_CHUNK;
            for (size_t i = 0; i < 4; i++) {
                p[1 + i] = (uint8_t)(off >> (8U * i));
            }
            memcpy(p + 5, body + off, amount);
            n      = command(frame, seq++, p, amount + 5U, secret);
            result = sq_receive(&m, frame, n);
        }
        if (result == SQ_OK) {
            p[0]   = SQ_CMD_UPDATE_COMMIT;
            n      = command(frame, seq, p, 1, secret);
            result = sq_receive(&m, frame, n);
        }
        uint64_t version = 0;
        bool valid       = sq_image_validate(flash[1], SQ_SLOT_BYTES, key, &version);
        CHECK(!valid || (result == SQ_OK && u.complete && version == 2U));
        for (size_t i = 0; i < SQ_SLOT_BYTES; i++) {
            CHECK(flash[0][i] == 0xA5);
        }
    }
    fail_at = 9999;
    SqMission m;
    SqUpdater u;
    SqBootState boot = {.accepted = 1, .confirmed = 1};
    sq_init(&m, key, persist, NULL);
    sq_tick(&m, 0, 760, 2200);
    sq_update_init(&u, &m, &boot, key, 0, 0, erase, write, read_flash, save_boot, NULL);
    m.extended_command = sq_update_command;
    m.command_context  = &u;
    p[0]               = SQ_CMD_UPDATE_BEGIN;
    p[1]               = 0;
    memcpy(p + 2, manifest, 112);
    size_t n = command(frame, 1, p, 114, secret);
    CHECK(sq_receive(&m, frame, n) == SQ_NOT_ALLOWED);
    p[1] = 1;
    p[60] ^= 1;
    n = command(frame, 1, p, 114, secret);
    CHECK(sq_receive(&m, frame, n) == SQ_AUTH);
    p[60] ^= 1;
    persist_fail    = true;
    n               = command(frame, 1, p, 114, secret);
    unsigned before = mutations;
    CHECK(sq_receive(&m, frame, n) == SQ_IO);
    CHECK(mutations == before);
    persist_fail = false;
    sq_init(&m, key, persist, NULL);
    sq_tick(&m, 0, 760, 2200);
    m.extended_command = sq_update_command;
    m.command_context  = &u;
    n                  = command(frame, 1, p, 114, secret);
    CHECK(sq_receive(&m, frame, n) == SQ_OK);
    sq_tick(&m, 121, 760, 2200);
    sq_update_poll(&u);
    CHECK(!u.active);
    CHECK(sq_image_vectors(body, 0x08070000U, sizeof(body)));
    CHECK(!sq_image_vectors(body, 0x08010000U, sizeof(body)));
    uint8_t head[16];
    uint32_t gen = 0;
    sq_journal_header(7, saved, sizeof(saved), head);
    CHECK(sq_journal_valid(head, saved, sizeof(saved), &gen));
    CHECK(gen == 7);
    for (unsigned byte = 0; byte < 16U; byte++) {
        for (unsigned bit = 0; bit < 8U; bit++) {
            head[byte] ^= (uint8_t)(1U << bit);
            CHECK(!sq_journal_valid(head, saved, sizeof(saved), &gen));
            head[byte] ^= (uint8_t)(1U << bit);
        }
    }
    saved[100] ^= 1;
    CHECK(!sq_journal_valid(head, saved, sizeof(saved), &gen));
    puts("Authenticated streaming updates: write cuts, replay, key, vectors, persistence and "
         "timeout verified");
    return 0;
}
