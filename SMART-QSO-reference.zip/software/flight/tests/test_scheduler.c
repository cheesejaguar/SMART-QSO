/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqRuntime runtime = {0};
    sq_runtime_begin(&runtime, UINT32_MAX - 20, 50);
    for (unsigned i = 0; i < 4; i++) {
        sq_runtime_vote(&runtime, i, true);
    }
    assert(sq_runtime_healthy(&runtime, 10));
    assert(runtime.max_elapsed_ms == 31);
    sq_runtime_begin(&runtime, 100, 50);
    sq_runtime_vote(&runtime, 4, true);
    assert(!sq_runtime_healthy(&runtime, 101));
    for (unsigned i = 0; i < 4; i++) {
        sq_runtime_vote(&runtime, i, i != 2);
    }
    assert(!sq_runtime_healthy(&runtime, 101));
    sq_runtime_vote(&runtime, 2, true);
    assert(sq_runtime_healthy(&runtime, 150));
    assert(!sq_runtime_healthy(&runtime, 151));
    runtime.faults = UINT32_MAX;
    assert(!sq_runtime_healthy(&runtime, 99));
    assert(runtime.faults == UINT32_MAX);
    SqPeriodic schedule;
    assert(!sq_periodic_init(&schedule, 0));
    assert(!sq_periodic_due(&schedule, 100, false));
    assert(!sq_periodic_init(&schedule, 86401));
    assert(sq_periodic_init(&schedule, 60));
    assert(sq_periodic_due(&schedule, 100, false));
    assert(!sq_periodic_due(&schedule, 100, false));
    assert(sq_periodic_due(&schedule, 101, true));
    assert(schedule.next_s == 161);
    assert(!sq_periodic_due(&schedule, 100, false) && schedule.faulted);
    assert(sq_periodic_init(&schedule, 60));
    assert(sq_periodic_due(&schedule, UINT64_MAX, false));
    assert(!sq_periodic_due(&schedule, UINT64_MAX, true) && schedule.exhausted);
    puts("test_scheduler.c: production scenarios passed");
    return 0;
}
