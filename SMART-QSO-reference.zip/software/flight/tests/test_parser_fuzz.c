#include "mission_core.h"
#include "transport.h"
#include <stdio.h>
#include <string.h>
static bool persist(const uint8_t *data,size_t n,void *context){(void)data;(void)n;(void)context;return true;}
int main(void){uint32_t seed=1234567;uint8_t bytes[512],out[240];SqMission mission;SqKiss decoder;
 for(unsigned test=0;test<4000U;test++){
  sq_init(&mission,NULL,persist,NULL);sq_kiss_init(&decoder);
  size_t length=test%512U;
  for(size_t i=0;i<length;i++){seed=1664525U*seed+1013904223U;bytes[i]=(uint8_t)(seed>>24U);(void)sq_kiss_feed(&decoder,bytes[i],out,sizeof(out));}
  (void)sq_receive(&mission,bytes,length);
  if(!mission.tx_inhibited||sq_tx_allowed(&mission)||decoder.length>512U){return 1;}
 }
 puts("4000 deterministic malformed protocol/KISS streams completed with RF inhibited");return 0;
}
