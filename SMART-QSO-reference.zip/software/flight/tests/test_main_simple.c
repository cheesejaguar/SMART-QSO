/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    assert(test_command(&test, SQ_CMD_GET_STATUS, 1, -1) == SQ_OK);
    assert(test_command(&test, SQ_CMD_GET_STATUS, 1, -1) == SQ_REPLAY);
    uint8_t frame[SQ_FRAME_MAX];
    size_t length = test_command_frame(&test, frame, SQ_CMD_PAYLOAD_ENABLE, 2, -1);
    frame[length - 1] ^= 1;
    assert(sq_receive(&test.mission, frame, length) == SQ_AUTH);
    assert(!test.mission.payload_requested && test.mission.command_sequence == 1);
    assert(test_command(&test, SQ_CMD_SET_MODE, 2, 99) == SQ_INVALID);
    assert(test.mission.command_sequence == 1);
    puts("test_main_simple.c: production scenarios passed");
    return 0;
}
