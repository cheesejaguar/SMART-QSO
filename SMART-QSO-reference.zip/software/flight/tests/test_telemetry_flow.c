/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    uint8_t frame[SQ_FRAME_MAX], packet[256], wire[520], decoded[SQ_FRAME_MAX];
    size_t length = sq_health_frame(&test.mission, 44, frame, sizeof(frame));
    const uint8_t addresses[16] =
        {156, 96, 134, 130, 152, 152, 96, 156, 96, 134, 130, 152, 152, 97, 3, 240};
    memcpy(packet, addresses, 16);
    memcpy(&packet[16], frame, length);
    size_t encoded = sq_kiss_encode(packet, 16 + length, wire, sizeof(wire));
    assert(encoded);
    SqKiss kiss;
    sq_kiss_init(&kiss);
    size_t received = 0;
    for (size_t i = 0; i < encoded; i++) {
        size_t got = sq_kiss_feed(&kiss, wire[i], decoded, sizeof(decoded));
        if (got) {
            assert(!received);
            received = got;
        }
    }
    assert(received == length && !memcmp(decoded, frame, length));
    wire[1] = 0x10;
    sq_kiss_init(&kiss);
    for (size_t i = 0; i < encoded; i++) {
        assert(!sq_kiss_feed(&kiss, wire[i], decoded, sizeof(decoded)));
    }
    const uint8_t escaped[3] = {0xC0, 0xDB, 0x00};
    encoded                  = sq_kiss_encode(escaped, 3, wire, sizeof(wire));
    sq_kiss_init(&kiss);
    received = 0;
    for (size_t i = 0; i < encoded; i++) {
        received = sq_raw_kiss_feed(&kiss, wire[i], decoded, sizeof(decoded));
    }
    assert(received == 3 && !memcmp(decoded, escaped, 3));
    puts("test_telemetry_flow.c: production scenarios passed");
    return 0;
}
