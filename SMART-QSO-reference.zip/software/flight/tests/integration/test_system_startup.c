/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "../production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    test_ready(&test);
    assert(test_command(&test, SQ_CMD_PAYLOAD_ENABLE, 3, -1) == SQ_OK);
    sq_tick(&test.mission, 1801, 760, 2200);
    assert(test.mission.payload_on);
    assert(test_message(&test, 1, "W6ABC", "K6XYZ", "Startup", 86400) == SQ_OK);
    SqMission restored;
    sq_init(&restored, test.key, test_persist, &test);
    assert(sq_load(&restored, test.saved, sizeof(test.saved)) == SQ_OK);
    assert(restored.mode == SQ_SAFE && !restored.payload_on && !restored.payload_requested);
    assert(restored.command_sequence == 3 && restored.separated && sq_queue_count(&restored) == 1);
    sq_tick_unavailable(&restored, 1802);
    assert(!sq_tx_allowed(&restored));
    test.saved[60] ^= 1;
    assert(sq_load(&restored, test.saved, sizeof(test.saved)) == SQ_IO);
    assert(restored.tx_inhibited && !restored.storage_healthy && !restored.payload_on);
    puts("integration/test_system_startup.c: production scenarios passed");
    return 0;
}
