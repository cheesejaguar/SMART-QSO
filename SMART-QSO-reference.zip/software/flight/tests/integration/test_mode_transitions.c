/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "../production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    test_ready(&test);
    assert(test_command(&test, SQ_CMD_SET_MODE, 3, SQ_IDLE) == SQ_OK);
    assert(test_command(&test, SQ_CMD_PAYLOAD_ENABLE, 4, -1) == SQ_OK);
    sq_tick(&test.mission, 1801, 760, 2200);
    assert(test.mission.payload_on);
    assert(test_command(&test, SQ_CMD_SET_MODE, 5, SQ_SAFE) == SQ_OK);
    assert(!test.mission.payload_on && !sq_tx_allowed(&test.mission));
    assert(test_command(&test, SQ_CMD_SET_MODE, 6, SQ_RELAY) == SQ_OK);
    sq_tick(&test.mission, 1802, 249, 2200);
    assert(test.mission.mode == SQ_SAFE && !sq_tx_allowed(&test.mission));
    sq_tick(&test.mission, 1803, 760, 2200);
    assert(test_command(&test, SQ_CMD_SET_MODE, 7, SQ_RELAY) == SQ_OK);
    assert(test_command(&test, SQ_CMD_END_MISSION, 8, -1) == SQ_OK);
    assert(test_command(&test, SQ_CMD_TX_ENABLE, 9, -1) == SQ_NOT_ALLOWED);
    assert(test_command(&test, SQ_CMD_PAYLOAD_ENABLE, 9, -1) == SQ_NOT_ALLOWED);
    assert(test_command(&test, SQ_CMD_SET_MODE, 9, SQ_RELAY) == SQ_NOT_ALLOWED);
    sq_tick(&test.mission, 1804, 760, 2200);
    assert(test.mission.retired && test.mission.mode == SQ_SAFE);
    puts("integration/test_mode_transitions.c: production scenarios passed");
    return 0;
}
