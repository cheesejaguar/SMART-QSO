/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "../production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    test_ready(&test);
    assert(test_command(&test, SQ_CMD_PAYLOAD_ENABLE, 3, -1) == SQ_OK);
    sq_tick(&test.mission, 1801, 760, 2200);
    SqPayload payload;
    sq_payload_init(&payload);
    uint8_t frame[SQ_FRAME_MAX];
    assert(!sq_payload_poll(&payload, &test.mission, frame, sizeof(frame)) && payload.powered);
    sq_tick(&test.mission, 1831, 760, 2200);
    assert(sq_payload_poll(&payload, &test.mission, frame, sizeof(frame)) == 33);
    sq_tick(&test.mission, 1852, 760, 2200);
    assert(!sq_payload_poll(&payload, &test.mission, frame, sizeof(frame)));
    assert(!payload.powered && payload.timeouts == 1 && !payload.accepted);
    sq_tick(&test.mission, 1853, 760, 5500);
    assert(test.mission.mode == SQ_SAFE && !sq_tx_allowed(&test.mission));
    sq_tick(&test.mission, 1854, 1001, 2200);
    assert(!test.mission.eps_valid);
    sq_tick(&test.mission, 1850, 760, 2200);
    assert(!test.mission.eps_valid && test.mission.time_s == 1853);
    test.fail = true;
    assert(test_command(&test, SQ_CMD_TX_DISABLE, 4, -1) == SQ_IO);
    assert(test.mission.tx_inhibited && !test.mission.storage_healthy);
    SqRuntime runtime = {0};
    sq_runtime_begin(&runtime, 100, 500);
    assert(!sq_runtime_healthy(&runtime, 601) && runtime.faults == 1);
    puts("integration/test_fault_scenarios.c: production scenarios passed");
    return 0;
}
