/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    assert(test.mission.mode == SQ_SAFE && test.mission.tx_inhibited
           && test.mission.storage_healthy);
    assert(!test.mission.payload_on && !sq_tx_allowed(&test.mission));
    assert(test_command(&test, SQ_CMD_TX_ENABLE, 1, -1) == SQ_NOT_ALLOWED);
    assert(test_message(&test, 9, "W6ABC", "K6XYZ", "73!", 3600) == SQ_OK);
    assert(sq_queue_count(&test.mission) == 1);
    SqMessage output;
    assert(sq_next(&test.mission, &output) == SQ_NOT_ALLOWED);
    test_ready(&test);
    assert(sq_next(&test.mission, &output) == SQ_OK);
    assert(output.id == 9 && !strcmp(output.text, "73!"));
    assert(sq_acknowledge(&test.mission, 9, "K6XYZ") == SQ_OK);
    assert(sq_queue_count(&test.mission) == 0);
    puts("test_main.c: production scenarios passed");
    return 0;
}
