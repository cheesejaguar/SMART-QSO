/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    uint8_t frame[SQ_FRAME_MAX];
    sq_tick(&test.mission, UINT64_MAX - 1, 1000, -5000);
    size_t length = sq_health_frame(&test.mission, UINT64_MAX, frame, sizeof(frame));
    assert(length == 33 && sq_frame_valid(frame, length));
    assert(test_le(&frame[4], 8) == UINT64_MAX && test_le(&frame[14], 8) == UINT64_MAX - 1);
    assert(test_le(&frame[22], 2) == 1000 && (int16_t)test_le(&frame[24], 2) == -5000);
    assert((frame[27] & 16) != 0 && (frame[27] & 1) != 0);
    assert(!sq_health_frame(&test.mission, 0, frame, 0));
    for (size_t i = 0; i < length; i++) {
        frame[i] ^= 1;
        assert(!sq_frame_valid(frame, length));
        frame[i] ^= 1;
    }
    sq_tick_unavailable(&test.mission, UINT64_MAX - 1);
    assert(sq_health_frame(&test.mission, 4, frame, sizeof(frame)) == 33);
    assert(!(frame[27] & 16));
    assert(sq_command_result_frame(55, SQ_CMD_GET_STATUS, SQ_REPLAY, frame, 20) == 20);
    assert(frame[3] == SQ_KIND_COMMAND_RESULT && frame[14] == SQ_CMD_GET_STATUS
           && frame[15] == SQ_REPLAY);
    assert(test_le(&frame[4], 8) == 55 && sq_frame_valid(frame, 20));
    assert(!sq_command_result_frame(1, 0, (SqResult)99, frame, sizeof(frame)));
    puts("test_telemetry.c: production scenarios passed");
    return 0;
}
