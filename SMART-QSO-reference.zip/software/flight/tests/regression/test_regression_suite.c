/* Production replacement; original source and intent retained in legacy_test_migration.json. */
#include "../production_fixture.h"
int main(void)
{
    SqTest test;
    test_init(&test);
    test_ready(&test);
    assert(test_message(&test, UINT64_MAX, "W6ABC", "K6XYZ", "Maximum identifier", 1) == SQ_OK);
    assert(test_message(&test, UINT64_MAX, "W6ABC", "K6XYZ", "Maximum identifier", 1)
           == SQ_DUPLICATE);
    assert(sq_acknowledge(&test.mission, UINT64_MAX, "K6XYZ") == SQ_NOT_ALLOWED);
    SqMessage output;
    assert(sq_next(&test.mission, &output) == SQ_OK && output.id == UINT64_MAX);
    assert(sq_acknowledge(&test.mission, UINT64_MAX, "W6BAD") == SQ_NOT_FOUND);
    assert(sq_acknowledge(&test.mission, UINT64_MAX, "K6XYZ") == SQ_OK);
    sq_tick(&test.mission, 1801, 760, 2200);
    assert(sq_queue_count(&test.mission) == 0);
    SqKiss kiss;
    uint8_t out[240];
    sq_kiss_init(&kiss);
    assert(!sq_kiss_feed(&kiss, 0xC0, out, sizeof(out)));
    for (unsigned i = 0; i < 600; i++) {
        assert(!sq_kiss_feed(&kiss, 0x11, out, sizeof(out)));
    }
    assert(!kiss.active && !kiss.length);
    assert(!sq_kiss_feed(&kiss, 0xC0, out, sizeof(out)));
    assert(!sq_kiss_feed(&kiss, 0xDB, out, sizeof(out)));
    assert(!sq_kiss_feed(&kiss, 0x01, out, sizeof(out)));
    assert(!kiss.active);
    assert(sq_crc32((const uint8_t *)"123456789", 9) == 0xCBF43926U);
    uint8_t head[16];
    uint32_t generation = 0;
    sq_journal_header(8, test.saved, sizeof(test.saved), head);
    assert(sq_journal_valid(head, test.saved, sizeof(test.saved), &generation) && generation == 8);
    for (unsigned bit = 0; bit < 128; bit++) {
        head[bit / 8] ^= (uint8_t)(1U << (bit % 8));
        assert(!sq_journal_valid(head, test.saved, sizeof(test.saved), &generation));
        head[bit / 8] ^= (uint8_t)(1U << (bit % 8));
    }
    puts("regression/test_regression_suite.c: production scenarios passed");
    return 0;
}
