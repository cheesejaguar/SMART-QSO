/* Boundary behavior of production interfaces, not simulated device readiness. */
#include "monocypher.h"
#include "production_fixture.h"
#include "update_stream.h"
static unsigned progress_calls;
static void progress(void *unused)
{
    (void)unused;
    progress_calls++;
}
int main(void)
{
    SqTest test;
    test_init(&test);
    SqRuntime cycle = {0};
    sq_runtime_begin(&cycle, 0, 250);
    for (unsigned task = 0; task < 4; task++) {
        sq_runtime_vote(&cycle, task, true);
    }
    assert(sq_runtime_healthy(&cycle, 100));
    /* An earlier valid vote cannot authorize feeding after a late flash phase. */
    assert(!sq_runtime_healthy(&cycle, 251));
    assert(test_message(&test, 1, "W6ABC-15", "K6XYZ-0", "SSID", 1) == SQ_OK);
    assert(test_message(&test, 2, "W6ABC-16", "K6XYZ", "bad SSID", 1) == SQ_INVALID);
    assert(test_message(&test, 2, "W6ABC-", "K6XYZ", "empty SSID", 1) == SQ_INVALID);
    assert(test_message(&test, 2, "W6ABC-x", "K6XYZ", "non-numeric SSID", 1) == SQ_INVALID);
    /* Exercise expiry-on-ingress without a preceding housekeeping tick. */
    test.mission.time_s = 1;
    assert(test_message(&test, 1, "W6ABC-15", "K6XYZ-0", "New session", 30) == SQ_OK);
    assert(test_command(&test, 0x7f, 1, -1) == SQ_INVALID);
    test_ready(&test);
    assert(test_command(&test, SQ_CMD_PAYLOAD_ENABLE, 3, -1) == SQ_OK);
    sq_tick(&test.mission, 1801, 1000, 2200);
    assert(test.mission.payload_on);
    SqPayload payload;
    sq_payload_init(&payload);
    assert(strstr(sq_payload_description(&payload, &test.mission), "100%"));
    assert(test_command(&test, SQ_CMD_RESET, 4, -1) == SQ_OK);
    assert(test.mission.reset_requested && test.mission.mode == SQ_SAFE
           && !test.mission.payload_on);
    SqBootState state    = {.accepted = 2, .confirmed = 1, .trial = 2};
    bool valid[3]        = {false, false, true};
    uint64_t versions[3] = {1, 2, 0};
    assert(sq_boot_select(&state, valid, versions) == 2 && state.failed == 2
           && state.accepted == 2);
    uint8_t image[4096] = {0};
    memset(&image[112], 255, 1936);
    memcpy(image, "SQFW", 4);
    image[4]  = 3;
    image[12] = 0;
    image[13] = 8;
    uint8_t digest[32];
    crypto_blake2b(digest, 32, &image[2048], 2048);
    memcpy(&image[16], digest, 32);
    crypto_ed25519_sign(&image[48], test.secret, image, 48);
    uint64_t version = 0;
    assert(sq_image_validate_progress(image, sizeof(image), test.key, &version, progress, NULL));
    assert(version == 3 && progress_calls == 2);
    image[112] = 0;
    assert(!sq_image_validate(image, sizeof(image), test.key, &version));
    image[112] = 255;
    image[2047] = 0;
    assert(!sq_image_validate(image, sizeof(image), test.key, &version));
    image[2047] = 255;
    uint8_t first[8] = {0, 0, 0, 0x20, 9, 8, 1, 8};
    assert(!sq_image_vectors(first, 0x08010000UL, 2048));
    first[0] = 8;
    assert(sq_image_vectors(first, 0x08010000UL, 2048));
    assert(!sq_image_validate_progress(image, 2055, test.key, &version, progress, NULL));
    assert(!sq_image_validate_progress(NULL, sizeof(image), test.key, &version, progress, NULL));
    SqUpdater updater     = {0};
    updater.mission       = &test.mission;
    updater.target        = 1;
    updater.boot.accepted = UINT64_MAX;
    updater.active        = true;
    updater.recovering    = true;
    updater.written       = 2048;
    updater.length        = 4096;
    uint8_t frame[240];
    assert(sq_update_status_frame(&updater, UINT64_MAX, frame, sizeof(frame)) == 36);
    assert(sq_frame_valid(frame, 36) && frame[3] == SQ_KIND_UPDATE_STATUS && frame[14] == 9
           && frame[15] == 1);
    assert(test_le(&frame[4], 8) == UINT64_MAX && test_le(&frame[16], 4) == 2048);
    assert(test_le(&frame[20], 4) == 4096 && test_le(&frame[24], 8) == UINT64_MAX);
    assert(!sq_update_status_frame(&updater, 0, frame, 35));
    assert(!sq_update_status_frame(&updater, 0, NULL, sizeof(frame)));
    uint8_t status[1] = {SQ_CMD_UPDATE_STATUS};
    assert(sq_update_command(NULL, status, 1, false) == SQ_INVALID);
    assert(sq_update_command(&updater, status, 1, false) == SQ_OK);
    assert(sq_update_command(&updater, status, 2, false) == SQ_INVALID);
    test.mission.mode              = SQ_IDLE;
    test.mission.payload_on        = true;
    test.mission.payload_requested = true;
    sq_payload_init(&payload);
    payload.powered  = true;
    payload.sequence = UINT64_MAX;
    assert(!sq_payload_poll(&payload, &test.mission, frame, sizeof(frame)));
    assert(payload.faulted && !payload.powered && !payload.pending);
    sq_payload_init(&payload);
    test.mission.time_s = UINT64_MAX - 20U;
    assert(!sq_payload_poll(&payload, &test.mission, frame, sizeof(frame)));
    assert(payload.faulted && !payload.powered);
    sq_payload_init(&payload);
    test.mission.time_s  = 2000;
    payload.powered      = true;
    payload.accepted     = true;
    payload.observed     = 1969;
    payload.next_request = 2100;
    strcpy(payload.description, "Stale description");
    assert(!sq_payload_poll(&payload, &test.mission, frame, sizeof(frame)));
    assert(!payload.accepted && strstr(payload.description, "100%"));
    test.mission.mode              = SQ_SAFE;
    test.mission.payload_requested = false;
    test.mission.payload_on        = false;
    test.mission.tx_inhibited      = true;
    updater.active                 = true;
    updater.recovering             = true;
    updater.started_s              = 2000;
    updater.last_s                 = 2000;
    updater.record_index           = 224;
    sq_update_poll(&updater);
    assert(!updater.recovering && updater.active);
    puts("Software boundaries: SSIDs, ingress expiry, reset, recovery, hash progress and wire "
         "update status passed");
    return 0;
}
