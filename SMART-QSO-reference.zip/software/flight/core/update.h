#ifndef SQ_UPDATE_H
#define SQ_UPDATE_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
typedef struct
{
    uint64_t accepted;
    uint64_t confirmed;
    uint64_t trial;
    uint64_t failed;
    uint32_t attempts;
    uint32_t generation;
} SqBootState;
bool sq_image_validate(const uint8_t *image,
                       size_t capacity,
                       const uint8_t key[32],
                       uint64_t *version);
typedef void (*SqImageProgress)(void *context);
bool sq_image_validate_progress(const uint8_t *image,
                                size_t capacity,
                                const uint8_t key[32],
                                uint64_t *version,
                                SqImageProgress progress,
                                void *context);
/* Returns 0/1 for app A/B, 2 recovery, -1 no valid image. State must persist before jump. */
int sq_boot_select(SqBootState *s, const bool valid[3], const uint64_t versions[3]);
bool sq_boot_confirm(SqBootState *s, uint64_t running);
void sq_boot_encode(const SqBootState *s, uint8_t out[64]);
bool sq_boot_decode(SqBootState *s, const uint8_t in[64]);
#endif
