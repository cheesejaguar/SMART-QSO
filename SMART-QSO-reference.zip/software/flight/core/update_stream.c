#include "update_stream.h"

#include "monocypher-ed25519.h"

#include <string.h>
static uint64_t stream_read_le(const uint8_t *data, size_t size)
{
    uint64_t value = 0U;
    for (size_t i = 0U; i < size; i++) {
        value |= ((uint64_t)data[i] << (8U * (uint64_t)i));
    }
    return value;
}
static void stream_put(uint8_t *data, uint64_t value, size_t size)
{
    for (size_t i = 0U; i < size; i++) {
        data[i] = (uint8_t)(value >> (8U * (uint64_t)i));
    }
}
bool sq_image_vectors(const uint8_t first[8], uint32_t address, uint32_t length)
{
    uint64_t stack = stream_read_le(first, 4U);
    uint64_t reset = stream_read_le(&first[4U], 4U);
    uint64_t start = (uint64_t)address + 2048U;
    return (stack > 0x20000000U) && (stack <= 0x20018000U) && ((stack % 8U) == 0U)
           && ((reset & 1U) != 0U) && (reset >= start) && (reset < (start + length));
}
void sq_update_init(SqUpdater *updater,
                    SqMission *mission,
                    const SqBootState *boot,
                    const uint8_t key[32],
                    unsigned active_slot,
                    unsigned confirmed_slot,
                    SqFlashErase erase,
                    SqFlashWrite write,
                    SqFlashRead read,
                    SqBootSave save_boot,
                    void *context)
{
    (void)memset(updater, 0, sizeof(*updater));
    updater->mission = mission;
    updater->boot    = *boot;
    (void)memcpy(updater->key, key, 32U);
    updater->active_slot    = active_slot;
    updater->confirmed_slot = confirmed_slot;
    updater->erase          = erase;
    updater->write          = write;
    updater->read           = read;
    updater->save_boot      = save_boot;
    updater->context        = context;
}
static bool safe(const SqUpdater *updater)
{
    const SqMission *mission = updater->mission;
    return !updater->faulted && !mission->retired && mission->eps_valid && mission->storage_healthy
           && (mission->mode == SQ_SAFE) && mission->tx_inhibited && !mission->payload_on
           && !mission->payload_requested && (mission->soc_permille >= 650U)
           && (mission->temperature_centi_c >= 0) && (mission->temperature_centi_c < 4500);
}
static SqResult io_fail(SqUpdater *updater)
{
    updater->active     = false;
    updater->recovering = false;
    updater->faulted    = true;
    return SQ_IO;
}
static void recover_page(SqUpdater *updater, uint64_t now)
{
    uint8_t record[8];
    if (updater->record_index >= 224U) {
        updater->recovering = false;
    } else if (!updater->read(updater->context,
                              updater->target,
                              256U + (8U * updater->record_index),
                              record,
                              8U)) {
        (void)io_fail(updater);
    } else if (stream_read_le(record, 8U) == UINT64_MAX) {
        updater->recovering = false;
    } else {
        updater->record_index++;
        uint32_t end = updater->written + 2048U;
        if (end > updater->length) {
            end = updater->length;
        }
        if ((updater->written != updater->length) && (stream_read_le(record, 4U) == end)) {
            uint8_t page[2048];
            size_t count = (size_t)end - updater->written;
            if (!updater->read(updater->context,
                               updater->target,
                               2048U + updater->written,
                               page,
                               count)) {
                (void)io_fail(updater);
            } else if (stream_read_le(&record[4U], 4U) == sq_crc32(page, count)) {
                crypto_blake2b_update(&updater->hash, page, count);
                updater->written = end;
                updater->last_s  = now;
            } else {
                /* Torn/duplicate checkpoints are skipped, never overwritten. */
            }
        }
    }
}
void sq_update_poll(SqUpdater *updater)
{
    uint64_t now = updater->mission->time_s;
    if (updater->active
        && (!safe(updater) || (now < updater->last_s) || ((now - updater->last_s) > 120U)
            || (now < updater->started_s) || ((now - updater->started_s) > 10800U))) {
        updater->active     = false;
        updater->recovering = false;
    }
    if (updater->active && updater->recovering) {
        recover_page(updater, now);
    }
}
static bool checkpoint(SqUpdater *updater)
{
    bool valid = false;
    if ((updater->record_index < 224U) && (updater->written != 0U)) {
        uint32_t start = ((updater->written - 1U) / 2048U) * 2048U;
        size_t count   = (size_t)updater->written - start;
        uint8_t page[2048];
        uint8_t record[8];
        if (updater->read(updater->context, updater->target, 2048U + start, page, count)) {
            stream_put(record, updater->written, 4U);
            stream_put(&record[4U], sq_crc32(page, count), 4U);
            uint8_t check[8];
            uint32_t offset = 256U + (8U * updater->record_index);
            valid           = updater->write(updater->context, updater->target, offset, record, 8U)
                    && updater->read(updater->context, updater->target, offset, check, 8U)
                    && (memcmp(record, check, 8U) == 0);
            if (valid) {
                updater->record_index++;
            }
        }
    }
    return valid;
}
size_t sq_update_status_frame(const SqUpdater *updater, uint64_t sequence, uint8_t *out, size_t cap)
{
    size_t length = 0U;
    if ((out != NULL) && (cap >= 36U)) {
        (void)memset(out, 0, 32U);
        out[0U] = 0x53U;
        out[1U] = 0x51U;
        out[2U] = SQ_PROTOCOL_VERSION;
        out[3U] = SQ_KIND_UPDATE_STATUS;
        stream_put(&out[4U], sequence, 8U);
        stream_put(&out[12U], 18U, 2U);
        out[14U] = (uint8_t)((updater->active ? 1U : 0U) | (updater->complete ? 2U : 0U)
                             | (updater->faulted ? 4U : 0U) | (updater->recovering ? 8U : 0U));
        out[15U] = (uint8_t)updater->target;
        stream_put(&out[16U], updater->written, 4U);
        stream_put(&out[20U], updater->length, 4U);
        stream_put(&out[24U], updater->boot.accepted, 8U);
        length = sq_frame_finish(out, 32U, cap);
    }
    return length;
}
static SqResult stage_validate(SqUpdater *updater, unsigned target, const uint8_t manifest[112])
{
    const uint8_t magic[4] = {0x53U, 0x51U, 0x55U, 0x50U};
    uint8_t stage[128];
    uint8_t marker[8];
    SqResult result = SQ_AUTH;
    if (!updater->read(updater->context, target, 128U, stage, 128U)
        || !updater->read(updater->context, target, 120U, marker, 8U)) {
        result = io_fail(updater);
    } else if ((memcmp(stage, magic, 4U) == 0) && (stage[4U] == 1U) && (stage[5U] == target)
               && (stream_read_le(&stage[120U], 4U) == sq_crc32(stage, 120U))
               && (memcmp(&stage[8U], manifest, 112U) == 0)
               && (stream_read_le(marker, 8U) == UINT64_MAX)) {
        result = SQ_OK;
    } else {
        /* A different/corrupt/aborted stage cannot be resumed. */
    }
    return result;
}
static SqResult stage_begin(SqUpdater *updater)
{
    uint8_t stage[128];
    uint8_t check[128];
    (void)memset(stage, 255, sizeof(stage));
    stage[0U] = 0x53U;
    stage[1U] = 0x51U;
    stage[2U] = 0x55U;
    stage[3U] = 0x50U;
    stage[4U] = 1U;
    stage[5U] = (uint8_t)updater->target;
    stage[6U] = 0U;
    stage[7U] = 0U;
    (void)memcpy(&stage[8U], updater->manifest, SQ_MANIFEST_BYTES);
    stream_put(&stage[120U], sq_crc32(stage, 120U), 4U);
    bool valid = updater->erase(updater->context, updater->target, 0U)
                 && updater->write(updater->context, updater->target, 128U, stage, 128U)
                 && updater->read(updater->context, updater->target, 128U, check, 128U)
                 && (memcmp(check, stage, 128U) == 0);
    return valid ? SQ_OK : io_fail(updater);
}
static SqResult begin(SqUpdater *updater,
                      const uint8_t *payload,
                      size_t size,
                      bool execute,
                      bool resume)
{
    const uint8_t magic[4] = {0x53U, 0x51U, 0x46U, 0x57U};
    SqResult result        = SQ_NOT_ALLOWED;
    if ((size == (SQ_MANIFEST_BYTES + 2U)) && !updater->active && (updater->boot.trial == 0U)
        && (payload[1U] <= 1U) && (payload[1U] != updater->active_slot)
        && (payload[1U] != updater->confirmed_slot)) {
        const uint8_t *manifest = &payload[2U];
        uint64_t version        = stream_read_le(&manifest[4U], 8U);
        uint32_t length         = (uint32_t)stream_read_le(&manifest[12U], 4U);
        bool key_set            = false;
        for (size_t i = 0U; i < 32U; i++) {
            key_set = key_set || (updater->key[i] != 0U);
        }
        result = SQ_AUTH;
        if ((memcmp(manifest, magic, 4U) == 0) && key_set
            && (crypto_ed25519_check(&manifest[48U], updater->key, manifest, 48U) == 0)) {
            result = SQ_INVALID;
            if ((version > updater->boot.accepted) && (length >= 8U)
                && (length <= (SQ_SLOT_BYTES - 2048U))) {
                result = SQ_IO;
                if ((updater->erase != NULL) && (updater->write != NULL) && (updater->read != NULL)
                    && (updater->save_boot != NULL)) {
                    result = resume ? stage_validate(updater, payload[1U], manifest) : SQ_OK;
                    if ((result == SQ_OK) && execute) {
                        updater->target       = payload[1U];
                        updater->version      = version;
                        updater->length       = length;
                        updater->written      = 0U;
                        updater->complete     = false;
                        updater->record_index = 0U;
                        updater->recovering   = resume;
                        (void)memcpy(updater->manifest, manifest, SQ_MANIFEST_BYTES);
                        result = resume ? SQ_OK : stage_begin(updater);
                        if (result == SQ_OK) {
                            crypto_blake2b_init(&updater->hash, 32U);
                            updater->started_s = updater->mission->time_s;
                            updater->last_s    = updater->mission->time_s;
                            updater->active    = true;
                        }
                    }
                }
            }
        }
    }
    return result;
}
static SqResult chunk(SqUpdater *updater, const uint8_t *payload, size_t size, bool execute)
{
    SqResult result = SQ_INVALID;
    if ((size >= 6U) && (size <= (SQ_UPDATE_CHUNK + 5U))) {
        uint32_t offset = (uint32_t)stream_read_le(&payload[1U], 4U);
        size_t amount   = size - 5U;
        if ((offset == updater->written) && (amount <= (updater->length - updater->written))
            && ((amount == SQ_UPDATE_CHUNK) || (amount == (updater->length - updater->written)))) {
            result = SQ_OK;
            if (execute) {
                uint32_t destination = 2048U + offset;
                bool valid           = ((destination % 2048U) != 0U)
                             || updater->erase(updater->context, updater->target, destination);
                uint8_t padded[SQ_UPDATE_CHUNK];
                uint8_t check[SQ_UPDATE_CHUNK];
                (void)memset(padded, 0xFF, sizeof(padded));
                (void)memcpy(padded, &payload[5U], amount);
                size_t aligned = (amount + 7U) & ~(size_t)7U;
                valid =
                    valid
                    && updater->write(updater->context,
                                      updater->target,
                                      destination,
                                      padded,
                                      aligned)
                    && updater->read(updater->context, updater->target, destination, check, aligned)
                    && (memcmp(check, padded, aligned) == 0);
                if (valid) {
                    crypto_blake2b_update(&updater->hash, check, amount);
                    updater->written += (uint32_t)amount;
                    updater->last_s = updater->mission->time_s;
                    valid           = (((updater->written % 2048U) != 0U)
                             && (updater->written != updater->length))
                            || checkpoint(updater);
                }
                if (!valid) {
                    result = io_fail(updater);
                }
            }
        }
    }
    return result;
}
static SqResult publish(SqUpdater *updater, size_t size, bool execute)
{
    SqResult result = SQ_INVALID;
    if ((size == 1U) && (updater->written == updater->length)) {
        result = SQ_OK;
        if (execute) {
            uint8_t digest[32];
            uint8_t vector[8];
            crypto_blake2b_final(&updater->hash, digest);
            updater->active = false;
            if (crypto_verify32(digest, &updater->manifest[16U]) != 0) {
                result = SQ_AUTH;
            } else if (!updater->read(updater->context, updater->target, 2048U, vector, 8U)) {
                result = io_fail(updater);
            } else if (!sq_image_vectors(vector,
                                         (updater->target == 0U) ? 0x08010000U : 0x08070000U,
                                         updater->length)) {
                result = SQ_INVALID;
            } else {
                uint8_t check[SQ_MANIFEST_BYTES];
                updater->boot.accepted = updater->version;
                updater->boot.trial    = updater->version;
                updater->boot.attempts = 0U;
                bool valid             = updater->save_boot(updater->context, &updater->boot)
                             && updater->erase(updater->context, updater->target, 0U)
                             && updater->write(updater->context,
                                               updater->target,
                                               0U,
                                               updater->manifest,
                                               SQ_MANIFEST_BYTES)
                             && updater->read(updater->context,
                                              updater->target,
                                              0U,
                                              check,
                                              SQ_MANIFEST_BYTES)
                             && (memcmp(check, updater->manifest, SQ_MANIFEST_BYTES) == 0);
                if (valid) {
                    updater->complete = true;
                } else {
                    result = io_fail(updater);
                }
            }
        }
    }
    return result;
}
static SqResult abort_transfer(SqUpdater *updater, size_t size, bool execute)
{
    SqResult result = (size == 1U) ? SQ_OK : SQ_INVALID;
    if ((result == SQ_OK) && execute) {
        if (updater->active && safe(updater)) {
            const uint8_t marker[8] = {0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U};
            if (!updater->write(updater->context, updater->target, 120U, marker, 8U)) {
                result = io_fail(updater);
            }
        }
        if (result == SQ_OK) {
            updater->recovering   = false;
            updater->active       = false;
            updater->complete     = false;
            updater->record_index = 0U;
        }
    }
    return result;
}
SqResult sq_update_command(SqUpdater *updater, const uint8_t *payload, size_t size, bool execute)
{
    SqResult result = SQ_INVALID;
    if ((updater != NULL) && (payload != NULL) && (size != 0U)) {
        sq_update_poll(updater);
        uint8_t id = payload[0U];
        if (id == SQ_CMD_UPDATE_STATUS) {
            result = (size == 1U) ? SQ_OK : SQ_INVALID;
        } else if (id == SQ_CMD_UPDATE_ABORT) {
            result = abort_transfer(updater, size, execute);
        } else if (!safe(updater)) {
            result = SQ_NOT_ALLOWED;
        } else if ((id == SQ_CMD_UPDATE_BEGIN) || (id == SQ_CMD_UPDATE_RESUME)) {
            result = begin(updater, payload, size, execute, id == SQ_CMD_UPDATE_RESUME);
        } else if (!updater->active || updater->recovering) {
            result = SQ_NOT_ALLOWED;
        } else if (id == SQ_CMD_UPDATE_CHUNK) {
            result = chunk(updater, payload, size, execute);
        } else if (id == SQ_CMD_UPDATE_COMMIT) {
            result = publish(updater, size, execute);
        } else {
            /* Unsupported update command. */
        }
    }
    return result;
}
