#include "transport.h"

#include <string.h>
void sq_kiss_init(SqKiss *decoder)
{
    (void)memset(decoder, 0, sizeof(*decoder));
}
static size_t extract(const uint8_t *data, size_t size, uint8_t *out, size_t cap)
{
    size_t length = 0U;
    if ((size >= 17U) && (data[0U] == 0U)) {
        size_t offset = 1U;
        bool end      = false;
        bool bounded  = true;
        for (unsigned i = 0U; (i < 10U) && !end && bounded; i++) {
            bounded = (size - offset) >= 7U;
            if (bounded) {
                end = (data[offset + 6U] & 1U) != 0U;
                offset += 7U;
            }
        }
        if (bounded && end && (offset >= 15U) && ((size - offset) >= 2U) && (data[offset] == 3U)
            && (data[offset + 1U] == 0xF0U)) {
            offset += 2U;
            size_t candidate = size - offset;
            if ((candidate != 0U) && (candidate <= cap)) {
                (void)memcpy(out, &data[offset], candidate);
                length = candidate;
            }
        }
    }
    return length;
}
static size_t feed(SqKiss *decoder, uint8_t input, uint8_t *out, size_t cap, bool raw)
{
    size_t length = 0U;
    uint8_t value = input;
    if (value == 0xC0U) {
        if (decoder->active && !decoder->escape) {
            if (!raw) {
                length = extract(decoder->data, decoder->length, out, cap);
            } else if ((decoder->length > 1U) && (decoder->data[0U] == 0U)
                       && ((decoder->length - 1U) <= cap)) {
                length = decoder->length - 1U;
                (void)memcpy(out, &decoder->data[1U], length);
            } else {
                /* Nonzero ports, empty frames and overflow are not data frames. */
            }
        }
        decoder->length = 0U;
        decoder->active = true;
        decoder->escape = false;
    } else if (decoder->active) {
        bool append = true;
        if (decoder->escape) {
            decoder->escape = false;
            if (value == 0xDCU) {
                value = 0xC0U;
            } else if (value == 0xDDU) {
                value = 0xDBU;
            } else {
                decoder->active = false;
                decoder->length = 0U;
                append          = false;
            }
        } else if (value == 0xDBU) {
            decoder->escape = true;
            append          = false;
        } else {
            /* Ordinary data byte. */
        }
        if (append) {
            if (decoder->length < sizeof(decoder->data)) {
                decoder->data[decoder->length] = value;
                decoder->length++;
            } else {
                decoder->active = false;
                decoder->length = 0U;
            }
        }
    } else {
        /* Ignore bytes until a delimiter re-establishes framing. */
    }
    return length;
}
size_t sq_kiss_feed(SqKiss *decoder, uint8_t value, uint8_t *out, size_t cap)
{
    return feed(decoder, value, out, cap, false);
}
size_t sq_raw_kiss_feed(SqKiss *decoder, uint8_t value, uint8_t *out, size_t cap)
{
    return feed(decoder, value, out, cap, true);
}
size_t sq_kiss_encode(const uint8_t *data, size_t size, uint8_t *out, size_t cap)
{
    size_t length = 0U;
    if ((data != NULL) && (out != NULL) && (size != 0U) && (size <= 496U)) {
        size_t need = 3U;
        for (size_t i = 0U; i < size; i++) {
            need += ((data[i] == 0xC0U) || (data[i] == 0xDBU)) ? 2U : 1U;
        }
        if (need <= cap) {
            out[0U] = 0xC0U;
            out[1U] = 0U;
            length  = 2U;
            for (size_t i = 0U; i < size; i++) {
                if ((data[i] == 0xC0U) || (data[i] == 0xDBU)) {
                    out[length] = 0xDBU;
                    length++;
                    out[length] = (data[i] == 0xC0U) ? 0xDCU : 0xDDU;
                } else {
                    out[length] = data[i];
                }
                length++;
            }
            out[length] = 0xC0U;
            length++;
        }
    }
    return length;
}
