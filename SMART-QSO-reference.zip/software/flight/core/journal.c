#include "journal.h"

#include "mission_core.h"

#include <string.h>
static void journal_put(uint8_t *p, uint32_t value)
{
    for (unsigned i = 0U; i < 4U; i++) {
        p[i] = (uint8_t)(value >> (8U * i));
    }
}
static uint32_t journal_get(const uint8_t *p)
{
    uint32_t value = 0U;
    for (unsigned i = 0U; i < 4U; i++) {
        value |= ((uint32_t)p[i] << (8U * i));
    }
    return value;
}
void sq_journal_header(uint32_t generation, const uint8_t *data, size_t size, uint8_t out[16])
{
    out[0U] = 0x53U;
    out[1U] = 0x51U;
    out[2U] = 0x4AU;
    out[3U] = 0x32U;
    journal_put(&out[4U], generation);
    journal_put(&out[8U], sq_crc32(data, size));
    journal_put(&out[12U], sq_crc32(out, 12U));
}
bool sq_journal_valid(const uint8_t head[16],
                      const uint8_t *data,
                      size_t size,
                      uint32_t *generation)
{
    bool valid =
        (head != NULL) && (data != NULL) && (generation != NULL) && (size == SQ_SNAPSHOT_BYTES);
    if (valid) {
        valid = (head[0U] == 0x53U) && (head[1U] == 0x51U) && (head[2U] == 0x4AU)
                && (head[3U] == 0x32U) && (journal_get(&head[12U]) == sq_crc32(head, 12U))
                && (journal_get(&head[8U]) == sq_crc32(data, size))
                && (journal_get(&head[4U]) != 0U);
        if (valid) {
            *generation = journal_get(&head[4U]);
        }
    }
    return valid;
}
