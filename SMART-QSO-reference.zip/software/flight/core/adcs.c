#include "adcs.h"

#include <stddef.h>
#include <string.h>
static int64_t adcs_absolute(int64_t value)
{
    return (value < 0) ? -value : value;
}
void sq_bdot_init(SqBdot *controller, uint32_t gain, uint32_t limit)
{
    (void)memset(controller, 0, sizeof(*controller));
    controller->gain_uam2_per_ntps = gain;
    controller->limit_uam2         = limit;
}
bool sq_mag_calibrate(const SqMagCalibration *calibration, const int32_t raw[3], int32_t out[3])
{
    int32_t input[3] = {0, 0, 0};
    if (raw != NULL) {
        (void)memcpy(input, raw, sizeof(input));
    }
    if (out != NULL) {
        for (unsigned i = 0U; i < 3U; i++) {
            out[i] = 0;
        }
    }
    bool valid = (calibration != NULL) && (raw != NULL) && (out != NULL);
    if (valid) {
        valid             = calibration->reviewed;
        int32_t result[3] = {0, 0, 0};
        bool nonzero      = false;
        for (unsigned i = 0U; (i < 3U) && valid; i++) {
            valid = (input[i] >= -200000) && (input[i] <= 200000)
                    && (calibration->bias_nt[i] >= -200000) && (calibration->bias_nt[i] <= 200000)
                    && (calibration->scale_ppm[i] >= 500000)
                    && (calibration->scale_ppm[i] <= 1500000);
            if (valid) {
                int64_t field =
                    (((int64_t)input[i] - calibration->bias_nt[i]) * calibration->scale_ppm[i])
                    / 1000000;
                valid = (field >= -200000) && (field <= 200000);
                if (valid) {
                    result[i] = (int32_t)field;
                    nonzero   = nonzero || (field != 0);
                }
            }
        }
        valid = valid && nonzero;
        for (unsigned i = 0U; i < 3U; i++) {
            out[i] = valid ? result[i] : 0;
        }
    }
    return valid;
}
bool sq_bdot_step(SqBdot *controller,
                  const SqMagCalibration *calibration,
                  const int32_t raw[3],
                  uint64_t now_ms,
                  bool sensor_valid,
                  bool permitted,
                  int32_t moment_uam2[3])
{
    bool active = false;
    if ((controller != NULL) && (moment_uam2 != NULL)) {
        int32_t field[3];
        bool valid = permitted && sensor_valid && (controller->gain_uam2_per_ntps >= 1U)
                     && (controller->gain_uam2_per_ntps <= 1000U) && (controller->limit_uam2 >= 1U)
                     && (controller->limit_uam2 <= 200000U)
                     && sq_mag_calibrate(calibration, raw, field);
        for (unsigned i = 0U; i < 3U; i++) {
            moment_uam2[i] = 0;
        }
        if (valid && controller->history) {
            valid = (now_ms > controller->observed_ms)
                    && ((now_ms - controller->observed_ms) >= 100U)
                    && ((now_ms - controller->observed_ms) <= 10000U);
        }
        if (!valid) {
            controller->history = false;
        } else {
            if (controller->history && (now_ms > controller->observed_ms)) {
                uint64_t delta = now_ms - controller->observed_ms;
                if ((delta >= 100U) && (delta <= 10000U)) {
                    int64_t moments[3];
                    int64_t total = 0;
                    for (unsigned i = 0U; i < 3U; i++) {
                        moments[i] = (-((int64_t)field[i] - controller->previous_nt[i])
                                      * (int64_t)controller->gain_uam2_per_ntps * 1000)
                                     / (int64_t)delta;
                        total += adcs_absolute(moments[i]);
                    }
                    for (unsigned i = 0U; i < 3U; i++) {
                        int64_t bounded = moments[i];
                        if (total > (int64_t)controller->limit_uam2) {
                            bounded = (bounded * (int64_t)controller->limit_uam2) / total;
                        }
                        moment_uam2[i] = (int32_t)bounded;
                    }
                    active = true;
                }
            }
            (void)memcpy(controller->previous_nt, field, sizeof(field));
            controller->observed_ms = now_ms;
            controller->history     = true;
        }
    } else if (moment_uam2 != NULL) {
        for (unsigned i = 0U; i < 3U; i++) {
            moment_uam2[i] = 0;
        }
    } else {
        /* No output buffer; never attempt actuation. */
    }
    return active;
}
