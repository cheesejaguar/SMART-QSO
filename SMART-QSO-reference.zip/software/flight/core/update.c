#include "update.h"

#include "mission_core.h"
#include "monocypher-ed25519.h"
#include "monocypher.h"

#include <string.h>

static const uint8_t BOOT_MAGIC[4] = {0x53U, 0x51U, 0x42U, 0x54U};
static uint64_t update_read_le(const uint8_t *p, size_t n)
{
    uint64_t value = 0U;
    for (size_t i = 0U; i < n; i++) {
        value |= ((uint64_t)p[i] << (8U * (uint64_t)i));
    }
    return value;
}
static void update_put(uint8_t *p, uint64_t value, size_t n)
{
    for (size_t i = 0U; i < n; i++) {
        p[i] = (uint8_t)(value >> (8U * (uint64_t)i));
    }
}
bool sq_image_validate_progress(const uint8_t *image,
                                size_t capacity,
                                const uint8_t key[32],
                                uint64_t *version,
                                SqImageProgress progress,
                                void *context)
{
    const uint8_t magic[4] = {0x53U, 0x51U, 0x46U, 0x57U};
    bool valid             = false;
    if ((image != NULL) && (key != NULL) && (version != NULL) && (capacity >= 2056U)) {
        size_t length      = (size_t)update_read_le(&image[12U], 4U);
        uint64_t candidate = update_read_le(&image[4U], 8U);
        bool provisioned   = false;
        for (size_t i = 0U; i < 32U; i++) {
            provisioned = provisioned || (key[i] != 0U);
        }
        bool canonical = true;
        for (size_t i = 112U; (i < 2048U) && canonical; i++) {
            canonical = image[i] == 0xFFU;
        }
        if ((memcmp(image, magic, 4U) == 0) && (length >= 8U) && (length <= (capacity - 2048U))
            && (candidate != 0U) && provisioned && canonical
            && (crypto_ed25519_check(&image[48U], key, image, 48U) == 0)) {
            uint8_t digest[32];
            crypto_blake2b_ctx hash;
            crypto_blake2b_init(&hash, 32U);
            for (size_t offset = 0U; offset < length; offset += 1024U) {
                size_t chunk = ((length - offset) > 1024U) ? 1024U : (length - offset);
                crypto_blake2b_update(&hash, &image[2048U + offset], chunk);
                if (progress != NULL) {
                    progress(context);
                }
            }
            crypto_blake2b_final(&hash, digest);
            valid = crypto_verify32(digest, &image[16U]) == 0;
            if (valid) {
                *version = candidate;
            }
        }
    }
    return valid;
}
bool sq_image_validate(const uint8_t *image,
                       size_t capacity,
                       const uint8_t key[32],
                       uint64_t *version)
{
    return sq_image_validate_progress(image, capacity, key, version, NULL, NULL);
}
int sq_boot_select(SqBootState *state, const bool valid[3], const uint64_t versions[3])
{
    int selected = -1;
    int newest   = -1;
    for (int i = 0; i < 2; i++) {
        if (valid[i] && (versions[i] > state->accepted)
            && ((newest < 0) || (versions[i] > versions[newest]))) {
            newest = i;
        }
    }
    if (newest >= 0) {
        state->accepted = versions[newest];
        state->trial    = state->accepted;
        state->attempts = 1U;
        selected        = newest;
    } else {
        if (state->trial != 0U) {
            if (state->attempts < 3U) {
                for (int i = 0; (i < 2) && (selected < 0); i++) {
                    if (valid[i] && (versions[i] == state->trial)) {
                        state->attempts++;
                        selected = i;
                    }
                }
            }
            if (selected < 0) {
                state->failed   = state->trial;
                state->trial    = 0U;
                state->attempts = 0U;
            }
        }
        if ((selected < 0) && (state->confirmed != 0U)) {
            for (int i = 0; (i < 2) && (selected < 0); i++) {
                if (valid[i] && (versions[i] == state->confirmed)
                    && (versions[i] != state->failed)) {
                    selected = i;
                }
            }
        }
        if ((selected < 0) && valid[2]) {
            selected = 2;
        }
    }
    return selected;
}
bool sq_boot_confirm(SqBootState *state, uint64_t running)
{
    bool valid = (running != 0U) && (running == state->trial);
    if (valid) {
        state->confirmed = running;
        state->trial     = 0U;
        state->attempts  = 0U;
    }
    return valid;
}
void sq_boot_encode(const SqBootState *state, uint8_t out[64])
{
    (void)memset(out, 0, 64U);
    (void)memcpy(out, BOOT_MAGIC, 4U);
    out[4U] = 1U;
    update_put(&out[8U], state->generation, 4U);
    update_put(&out[16U], state->accepted, 8U);
    update_put(&out[24U], state->confirmed, 8U);
    update_put(&out[32U], state->trial, 8U);
    update_put(&out[40U], state->failed, 8U);
    update_put(&out[48U], state->attempts, 4U);
    update_put(&out[60U], sq_crc32(out, 60U), 4U);
}
bool sq_boot_decode(SqBootState *state, const uint8_t in[64])
{
    bool valid = (state != NULL) && (in != NULL);
    if (valid) {
        valid = (memcmp(in, BOOT_MAGIC, 4U) == 0) && (in[4U] == 1U)
                && (update_read_le(&in[60U], 4U) == sq_crc32(in, 60U))
                && (update_read_le(&in[48U], 4U) <= 3U);
        uint64_t accepted = update_read_le(&in[16U], 8U);
        uint64_t trial    = update_read_le(&in[32U], 8U);
        uint64_t attempts = update_read_le(&in[48U], 4U);
        valid             = valid && (update_read_le(&in[24U], 8U) <= accepted)
                && (update_read_le(&in[40U], 8U) <= accepted)
                && ((trial == 0U) || (trial == accepted)) && ((trial != 0U) || (attempts == 0U));
        for (size_t i = 5U; (i < 60U) && valid; i++) {
            if ((i < 8U) || ((i >= 12U) && (i < 16U)) || (i >= 52U)) {
                valid = in[i] == 0U;
            }
        }
        if (valid) {
            state->generation = (uint32_t)update_read_le(&in[8U], 4U);
            state->accepted   = update_read_le(&in[16U], 8U);
            state->confirmed  = update_read_le(&in[24U], 8U);
            state->trial      = update_read_le(&in[32U], 8U);
            state->failed     = update_read_le(&in[40U], 8U);
            state->attempts   = (uint32_t)update_read_le(&in[48U], 4U);
        }
    }
    return valid;
}
