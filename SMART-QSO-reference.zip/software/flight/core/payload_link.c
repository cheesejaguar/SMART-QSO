#include "payload_link.h"

#include <string.h>
static uint64_t payload_read_le(const uint8_t *data, size_t size)
{
    uint64_t value = 0U;
    for (size_t i = 0U; i < size; i++) {
        value |= ((uint64_t)data[i] << (8U * (uint64_t)i));
    }
    return value;
}
static uint64_t payload_future(uint64_t now, uint64_t delay)
{
    return (now > (UINT64_MAX - delay)) ? UINT64_MAX : (now + delay);
}
static void battery(char out[32], uint16_t soc)
{
    const char digits[11] = "0123456789";
    (void)memcpy(out, "Battery at ", 11U);
    size_t index   = 11U;
    unsigned whole = (unsigned)soc / 10U;
    if (whole >= 100U) {
        out[index] = digits[(whole / 100U) % 10U];
        index++;
    }
    if (whole >= 10U) {
        out[index] = digits[(whole / 10U) % 10U];
        index++;
    }
    out[index] = digits[whole % 10U];
    index++;
    if ((soc % 10U) != 0U) {
        out[index] = '.';
        index++;
        out[index] = digits[(unsigned)soc % 10U];
        index++;
    }
    out[index] = '%';
    index++;
    out[index] = '\0';
}
static const char *payload_mode(SqMode value)
{
    return (value == SQ_SAFE) ? "Safe mode" : ((value == SQ_IDLE) ? "Idle mode" : "Relay mode");
}
static void fallback(SqPayload *payload, const SqMission *mission)
{
    char text[32];
    if (mission->eps_valid) {
        battery(text, mission->soc_permille);
    } else {
        (void)memcpy(text, "Battery telemetry unavailable", 30U);
    }
    size_t index         = 0U;
    const char *parts[3] = {payload_mode(mission->mode),
                            text,
                            sq_tx_allowed(mission) ? "Radio enabled" : "Radio inhibited"};
    for (unsigned i = 0U; i < 3U; i++) {
        size_t length = strlen(parts[i]);
        (void)memcpy(&payload->description[index], parts[i], length);
        index += length;
        payload->description[index] = '.';
        index++;
        if (i < 2U) {
            payload->description[index] = ' ';
            index++;
        }
    }
    payload->description[index] = '\0';
    payload->accepted           = false;
}
void sq_payload_init(SqPayload *payload)
{
    (void)memset(payload, 0, sizeof(*payload));
}
void sq_payload_disconnect(SqPayload *payload, const SqMission *mission)
{
    if (payload->timeouts < UINT32_MAX) {
        payload->timeouts++;
    }
    payload->shutdown_at   = 0U;
    payload->pending       = false;
    payload->powered       = false;
    payload->backoff_until = payload_future(mission->time_s, 600U);
    fallback(payload, mission);
}
static bool current(const SqPayload *payload, const SqMission *mission)
{
    return mission->eps_valid && (mission->time_s >= payload->observed)
           && ((mission->time_s - payload->observed) <= 30U)
           && (mission->soc_permille == payload->soc) && (mission->mode == payload->mode)
           && (sq_tx_allowed(mission) == payload->tx);
}
static size_t request_snapshot(SqPayload *payload,
                               const SqMission *mission,
                               uint8_t *out,
                               size_t cap)
{
    size_t length = 0U;
    if ((payload->sequence == UINT64_MAX) || (mission->time_s > (UINT64_MAX - 60U))) {
        payload->faulted = true;
        payload->powered = false;
        fallback(payload, mission);
    } else {
        length = sq_health_frame(mission, payload->sequence + 1U, out, cap);
        if (length != 0U) {
            payload->sequence++;
            payload->observed     = mission->time_s;
            payload->soc          = mission->soc_permille;
            payload->mode         = mission->mode;
            payload->tx           = sq_tx_allowed(mission);
            payload->pending      = true;
            payload->deadline     = mission->time_s + 20U;
            payload->next_request = mission->time_s + 60U;
            fallback(payload, mission);
        }
    }
    return length;
}
size_t sq_payload_poll(SqPayload *payload, const SqMission *mission, uint8_t *out, size_t cap)
{
    size_t length = 0U;
    if (mission->time_s < payload->last_time) {
        payload->faulted = true;
        payload->powered = false;
        payload->pending = false;
    }
    payload->last_time = mission->time_s;
    if (payload->pending && (mission->time_s > payload->deadline)) {
        sq_payload_disconnect(payload, mission);
    }
    if ((payload->shutdown_at != 0U) && (mission->time_s >= payload->shutdown_at)) {
        payload->powered       = false;
        payload->shutdown_at   = 0U;
        payload->backoff_until = payload_future(mission->time_s, 600U);
    }
    if (!mission->payload_on || !mission->storage_healthy || payload->faulted
        || (mission->time_s < payload->backoff_until)) {
        payload->powered = false;
        payload->pending = false;
        if (!payload->accepted || !current(payload, mission) || !mission->payload_requested) {
            fallback(payload, mission);
        }
    } else {
        if (!payload->powered) {
            if (mission->time_s > (UINT64_MAX - 30U)) {
                payload->faulted = true;
            } else {
                payload->powered      = true;
                payload->powered_at   = mission->time_s;
                payload->next_request = mission->time_s + 30U;
            }
        }
        if (payload->accepted && !current(payload, mission)) {
            fallback(payload, mission);
        }
        if (!payload->faulted && !payload->pending && (mission->time_s >= payload->next_request)) {
            length = request_snapshot(payload, mission, out, cap);
        }
    }
    return length;
}
static bool phrase_matches(const uint8_t *text, const char *phrase, size_t length)
{
    bool match = true;
    for (size_t i = 0U; (i < length) && match; i++) {
        match = text[i] == (uint8_t)phrase[i];
    }
    return match;
}
static bool grammar(const uint8_t *text, size_t size, const SqPayload *payload)
{
    char status[32];
    battery(status, payload->soc);
    const char *phrases[4] = {status,
                              payload_mode(payload->mode),
                              payload->tx ? "Radio enabled" : "Radio inhibited",
                              "73!"};
    unsigned used          = 0U;
    size_t offset          = 0U;
    bool valid             = size != 0U;
    while ((offset < size) && valid) {
        bool found = false;
        for (unsigned i = 0U; (i < 4U) && !found; i++) {
            size_t length = strlen(phrases[i]);
            if (((used & (1U << i)) == 0U) && ((size - offset) >= length)
                && phrase_matches(&text[offset], phrases[i], length)) {
                offset += length;
                used |= (1U << i);
                found = true;
            }
        }
        valid = found;
        if (valid && (offset < size)) {
            valid = text[offset] == 0x2EU;
            offset++;
            if (valid && (offset < size)) {
                valid = text[offset] == 0x20U;
                offset++;
                valid = valid && (offset < size);
            }
        }
    }
    return valid && (used != 0U);
}
SqResult sq_payload_receive(SqPayload *payload,
                            const SqMission *mission,
                            const uint8_t *frame,
                            size_t size)
{
    SqResult result = SQ_INVALID;
    if ((size >= 28U) && sq_frame_valid(frame, size) && (frame[3U] == SQ_KIND_PAYLOAD_RESULT)
        && (payload_read_le(&frame[12U], 2U) == (size - 18U)) && (frame[22U] != 0U)
        && (frame[22U] <= SQ_DESCRIPTION_MAX) && (size == (27U + frame[22U]))) {
        result = SQ_NOT_ALLOWED;
        if (mission->payload_on && payload->powered && payload->pending
            && (payload_read_le(&frame[4U], 8U) == payload->sequence)
            && (payload_read_le(&frame[14U], 8U) == payload->observed) && current(payload, mission)
            && (mission->time_s <= payload->deadline)) {
            result = SQ_INVALID;
            if (grammar(&frame[23U], frame[22U], payload)) {
                (void)memcpy(payload->description, &frame[23U], frame[22U]);
                payload->description[frame[22U]] = '\0';
                payload->accepted                = true;
                payload->pending                 = false;
                payload->shutdown_at             = payload_future(mission->time_s, 5U);
                result                           = SQ_OK;
            }
        }
        if (result != SQ_OK) {
            fallback(payload, mission);
        }
    }
    if ((result != SQ_OK) && (payload->rejected < UINT32_MAX)) {
        payload->rejected++;
    }
    return result;
}
const char *sq_payload_description(SqPayload *payload, const SqMission *mission)
{
    if (!payload->accepted || !current(payload, mission) || !mission->payload_requested) {
        fallback(payload, mission);
    }
    return payload->description;
}
size_t sq_payload_beacon(SqPayload *payload,
                         const SqMission *mission,
                         uint64_t sequence,
                         uint8_t *out,
                         size_t cap)
{
    const char *text = sq_payload_description(payload, mission);
    size_t size      = strlen(text);
    size_t length    = 0U;
    if ((out != NULL) && (cap >= (28U + size)) && (size <= SQ_DESCRIPTION_MAX)) {
        (void)memset(out, 0, 24U);
        out[0U] = 0x53U;
        out[1U] = 0x51U;
        out[2U] = SQ_PROTOCOL_VERSION;
        out[3U] = SQ_KIND_DESCRIPTION;
        for (size_t i = 0U; i < 8U; i++) {
            out[4U + i]  = (uint8_t)(sequence >> (8U * (uint64_t)i));
            out[14U + i] = (uint8_t)(mission->time_s >> (8U * (uint64_t)i));
        }
        out[12U] = (uint8_t)(10U + size);
        out[22U] = payload->accepted ? 1U : 0U;
        out[23U] = (uint8_t)size;
        (void)memcpy(&out[24U], text, size);
        length = sq_frame_finish(out, 24U + size, cap);
    }
    return length;
}
