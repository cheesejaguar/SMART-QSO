#ifndef SQ_UPDATE_STREAM_H
#define SQ_UPDATE_STREAM_H
#include "mission_core.h"
#include "monocypher.h"
#include "update.h"
#define SQ_UPDATE_CHUNK   128U
#define SQ_SLOT_BYTES     (384U * 1024U)
#define SQ_MANIFEST_BYTES 112U
/* Offsets are relative to app slot 0/1. Backends must enforce the same boundaries. */
typedef bool (*SqFlashErase)(void *context, unsigned slot, uint32_t offset);
typedef bool (
    *SqFlashWrite)(void *context, unsigned slot, uint32_t offset, const uint8_t *data, size_t size);
typedef bool (
    *SqFlashRead)(void *context, unsigned slot, uint32_t offset, uint8_t *data, size_t size);
typedef bool (*SqBootSave)(void *context, SqBootState *state);
struct SqUpdater
{
    SqMission *mission;
    SqBootState boot;
    uint8_t key[32];
    uint8_t manifest[SQ_MANIFEST_BYTES];
    crypto_blake2b_ctx hash;
    uint64_t version;
    uint64_t started_s;
    uint64_t last_s;
    uint32_t length;
    uint32_t written;
    unsigned active_slot;
    unsigned confirmed_slot;
    unsigned target;
    unsigned record_index;
    bool active;
    bool complete;
    bool faulted;
    bool recovering;
    SqFlashErase erase;
    SqFlashWrite write;
    SqFlashRead read;
    SqBootSave save_boot;
    void *context;
};
void sq_update_init(SqUpdater *u,
                    SqMission *m,
                    const SqBootState *boot,
                    const uint8_t key[32],
                    unsigned active_slot,
                    unsigned confirmed_slot,
                    SqFlashErase erase,
                    SqFlashWrite write,
                    SqFlashRead read,
                    SqBootSave save_boot,
                    void *context);
/* Attached to signed-command dispatch: validation before replay commit, execution afterward. */
SqResult sq_update_command(SqUpdater *context, const uint8_t *p, size_t n, bool execute);
void sq_update_poll(SqUpdater *u);
bool sq_image_vectors(const uint8_t first[8], uint32_t address, uint32_t length);
size_t sq_update_status_frame(const SqUpdater *u, uint64_t sequence, uint8_t *out, size_t cap);
#endif
