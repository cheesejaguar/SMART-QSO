#include "host_api.h"

#include <string.h>
size_t sq_mission_size(void)
{
    return sizeof(SqMission);
}
size_t sq_updater_size(void)
{
    return sizeof(SqUpdater);
}
size_t sq_payload_size(void)
{
    return sizeof(SqPayload);
}
void sq_attach_updater(SqMission *m, SqUpdater *u)
{
    m->extended_command = sq_update_command;
    m->command_context  = u;
}
uint32_t sq_update_written(const SqUpdater *u)
{
    return u->written;
}
bool sq_update_active(const SqUpdater *u)
{
    return u->active;
}
bool sq_update_complete(const SqUpdater *u)
{
    return u->complete;
}
bool sq_update_faulted(const SqUpdater *u)
{
    return u->faulted;
}
bool sq_update_recovering(const SqUpdater *u)
{
    return u->recovering;
}
uint32_t sq_update_length(const SqUpdater *u)
{
    return u->length;
}
void sq_update_boot_state(const SqUpdater *u, uint8_t out[64])
{
    sq_boot_encode(&u->boot, out);
}
bool sq_payload_power(const SqPayload *p)
{
    return p->powered;
}
bool sq_payload_accepted(const SqPayload *p)
{
    return p->accepted;
}
bool sq_payload_pending(const SqPayload *p)
{
    return p->pending;
}
void sq_payload_sync_power(const SqPayload *p, SqMission *m)
{
    m->payload_on = p->powered;
}

/* Host formatting is bounded and independent of printf's varargs/type conversions. */
typedef struct
{
    char *data;
    size_t capacity;
    size_t length;
    bool valid;
} SqJson;
static void json_text(SqJson *json, const char *text)
{
    size_t size = strlen(text);
    if (json->valid && (size < (json->capacity - json->length))) {
        (void)memcpy(&json->data[json->length], text, size);
        json->length += size;
        json->data[json->length] = '\0';
    } else {
        json->valid = false;
    }
}
static void json_number(SqJson *json, uint64_t value)
{
    uint64_t remaining    = value;
    const char digits[11] = "0123456789";
    char reversed[20];
    size_t size = 0U;
    do {
        reversed[size] = digits[remaining % 10U];
        size++;
        remaining /= 10U;
    } while (remaining != 0U);
    for (size_t i = 0U; (i < size) && json->valid; i++) {
        if (json->length < (json->capacity - 1U)) {
            json->data[json->length] = reversed[(size - 1U) - i];
            json->length++;
        } else {
            json->valid = false;
        }
    }
    if (json->valid) {
        json->data[json->length] = '\0';
    }
}
size_t sq_status_json(const SqMission *mission, char *out, size_t cap)
{
    size_t length = 0U;
    if ((mission != NULL) && (out != NULL) && (cap != 0U)) {
        SqJson json = {out, cap, 0U, true};
        json_text(&json, "{\"mode\":");
        json_number(&json, (uint64_t)mission->mode);
        json_text(&json, ",\"soc_permille\":");
        json_number(&json, mission->soc_permille);
        json_text(&json, ",\"temperature_centi_c\":");
        int32_t temperature = mission->temperature_centi_c;
        if (temperature < 0) {
            json_text(&json, "-");
            temperature = -temperature;
        }
        json_number(&json, (uint64_t)temperature);
        json_text(&json, ",\"uptime_s\":");
        json_number(&json, mission->time_s);
        json_text(&json, ",\"sequence\":");
        json_number(&json, mission->command_sequence);
        json_text(&json, ",\"tx_inhibited\":");
        json_text(&json, mission->tx_inhibited ? "true" : "false");
        json_text(&json, ",\"tx_allowed\":");
        json_text(&json, sq_tx_allowed(mission) ? "true" : "false");
        json_text(&json, ",\"payload_on\":");
        json_text(&json, mission->payload_on ? "true" : "false");
        json_text(&json, ",\"storage_healthy\":");
        json_text(&json, mission->storage_healthy ? "true" : "false");
        json_text(&json, ",\"key_provisioned\":");
        json_text(&json, mission->key_provisioned ? "true" : "false");
        json_text(&json, ",\"eps_valid\":");
        json_text(&json, mission->eps_valid ? "true" : "false");
        json_text(&json, ",\"retired\":");
        json_text(&json, mission->retired ? "true" : "false");
        json_text(&json, ",\"queue_count\":");
        json_number(&json, sq_queue_count(mission));
        json_text(&json, "}");
        if (json.valid) {
            length = json.length;
        } else {
            out[0U] = '\0';
        }
    }
    return length;
}
