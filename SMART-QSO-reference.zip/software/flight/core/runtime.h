#ifndef SQ_RUNTIME_H
#define SQ_RUNTIME_H
#include <stdbool.h>
#include <stdint.h>
typedef struct
{
    uint32_t start_ms;
    uint32_t deadline_ms;
    uint32_t votes;
    uint32_t faults;
    uint32_t max_elapsed_ms;
} SqRuntime;
void sq_runtime_begin(SqRuntime *r, uint32_t now, uint32_t deadline);
void sq_runtime_vote(SqRuntime *r, unsigned task, bool completed);
bool sq_runtime_healthy(SqRuntime *r, uint32_t now);
typedef struct
{
    uint64_t next_s;
    uint64_t observed_s;
    uint32_t period_s;
    bool faulted;
    bool exhausted;
} SqPeriodic;
bool sq_periodic_init(SqPeriodic *schedule, uint32_t period_s);
bool sq_periodic_due(SqPeriodic *schedule, uint64_t now_s, bool force);
#endif
