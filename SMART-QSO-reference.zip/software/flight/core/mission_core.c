/* Bounded portable mission logic, shared by reference firmware and the host service. */
#include "mission_core.h"

#include "monocypher-ed25519.h"

#include <string.h>
#define HEADER    14U
#define SIGNATURE 64U
#define RECORD    184U
static const uint8_t STATE_MAGIC[4] = {0x53U, 0x51U, 0x53U, 0x54U};
static uint64_t mission_core_read_le(const uint8_t *data, size_t size)
{
    uint64_t value = 0U;
    for (size_t i = 0U; i < size; i++) {
        value |= ((uint64_t)data[i] << (8U * (uint64_t)i));
    }
    return value;
}
static void mission_core_write_le(uint8_t *data, uint64_t value, size_t size)
{
    for (size_t i = 0U; i < size; i++) {
        data[i] = (uint8_t)(value >> (8U * (uint64_t)i));
    }
}
uint32_t sq_crc32(const uint8_t *data, size_t size)
{
    uint32_t crc = UINT32_MAX;
    for (size_t i = 0U; i < size; i++) {
        crc ^= data[i];
        for (unsigned bit = 0U; bit < 8U; bit++) {
            crc = (crc >> 1U) ^ (((crc & 1U) != 0U) ? 0xEDB88320U : 0U);
        }
    }
    return ~crc;
}
size_t sq_frame_finish(uint8_t *out, size_t length, size_t cap)
{
    size_t finished = 0U;
    if ((out != NULL) && (length >= HEADER) && (length <= cap) && ((cap - length) >= 4U)) {
        mission_core_write_le(&out[length], sq_crc32(out, length), 4U);
        finished = length + 4U;
    }
    return finished;
}
bool sq_frame_valid(const uint8_t *frame, size_t size)
{
    bool valid = false;
    if ((frame != NULL) && (size >= 18U) && (size <= SQ_FRAME_MAX) && (frame[0U] == 0x53U)
        && (frame[1U] == 0x51U) && (frame[2U] == SQ_PROTOCOL_VERSION)) {
        size_t signature = (frame[3U] == SQ_KIND_COMMAND) ? 64U : 0U;
        size_t payload   = (size_t)mission_core_read_le(&frame[12U], 2U);
        if ((payload <= ((SQ_FRAME_MAX - 18U) - signature))
            && (size == ((18U + payload) + signature))) {
            valid =
                mission_core_read_le(&frame[14U + payload], 4U) == sq_crc32(frame, 14U + payload);
        }
    }
    return valid;
}
static uint32_t state_crc(const uint8_t *data, size_t size)
{
    uint32_t crc = UINT32_MAX;
    for (size_t i = 0U; i < size; i++) {
        if ((i < 60U) || (i >= 64U)) {
            crc ^= data[i];
            for (unsigned bit = 0U; bit < 8U; bit++) {
                crc = (crc >> 1U) ^ (((crc & 1U) != 0U) ? 0xEDB88320U : 0U);
            }
        }
    }
    return ~crc;
}
static bool call_valid(const char *station)
{
    bool valid      = station != NULL;
    bool terminated = false;
    bool digit      = false;
    bool suffix     = false;
    size_t root     = 0U;
    size_t count    = 0U;
    unsigned ssid   = 0U;
    for (size_t i = 0U; (i < 10U) && valid && !terminated; i++) {
        char letter = station[i];
        if (letter == '\0') {
            terminated = true;
            valid      = (root >= 3U) && (root <= 6U) && digit
                    && (!suffix || ((count >= 1U) && (count <= 2U) && (ssid <= 15U)));
        } else if ((letter == '-') && !suffix && (root >= 3U)) {
            suffix = true;
        } else if (suffix) {
            valid = (letter >= '0') && (letter <= '9');
            if (valid) {
                count++;
                ssid  = (ssid * 10U) + ((unsigned)letter - (unsigned)'0');
                digit = true;
            }
        } else {
            valid = ((letter >= 'A') && (letter <= 'Z')) || ((letter >= '0') && (letter <= '9'));
            if (valid) {
                root++;
                digit = digit || ((letter >= '0') && (letter <= '9'));
            }
        }
    }
    return valid && terminated;
}
static bool call_field_valid(const char field[10])
{
    bool valid = call_valid(field);
    bool padding = false;
    for (size_t i = 0U; (i < 10U) && valid; i++) {
        if (padding) {
            valid = field[i] == '\0';
        } else {
            padding = field[i] == '\0';
        }
    }
    return valid;
}
static bool text_valid(const char *data, size_t size)
{
    bool valid = (data != NULL) && (size != 0U) && (size <= SQ_TEXT_MAX);
    for (size_t i = 0U; (i < size) && valid; i++) {
        valid = ((uint8_t)data[i] >= 32U) && ((uint8_t)data[i] <= 126U);
    }
    return valid;
}
static void fail_closed(SqMission *mission)
{
    mission->storage_healthy = false;
    mission->tx_inhibited    = true;
    mission->payload_on      = false;
    mission->mode            = SQ_SAFE;
}
void sq_init(SqMission *mission, const uint8_t key[32], SqPersist persist, void *context)
{
    (void)memset(mission, 0, sizeof(*mission));
    mission->mode            = SQ_SAFE;
    mission->tx_inhibited    = true;
    mission->storage_healthy = true;
    mission->persist         = persist;
    mission->persist_context = context;
    if (key != NULL) {
        (void)memcpy(mission->public_key, key, 32U);
        for (size_t i = 0U; i < 32U; i++) {
            mission->key_provisioned = mission->key_provisioned || (key[i] != 0U);
        }
    }
}
size_t sq_snapshot(const SqMission *mission, uint8_t *out, size_t cap)
{
    size_t length = 0U;
    if ((mission != NULL) && (out != NULL) && (cap >= SQ_SNAPSHOT_BYTES)) {
        (void)memset(out, 0, SQ_SNAPSHOT_BYTES);
        (void)memcpy(out, STATE_MAGIC, 4U);
        out[4U] = 3U;
        out[5U] = (uint8_t)mission->mode;
        out[6U] = mission->tx_inhibited ? 1U : 0U;
        out[7U] = mission->separated ? 1U : 0U;
        mission_core_write_le(&out[8U], mission->command_sequence, 8U);
        mission_core_write_le(&out[16U], mission->time_s, 8U);
        mission_core_write_le(&out[24U], mission->separated_at_s, 8U);
        (void)memcpy(&out[32U], mission->last_sender, 10U);
        out[42U] = mission->payload_requested ? 1U : 0U;
        out[43U] = mission->retired ? 1U : 0U;
        for (size_t i = 0U; i < SQ_QUEUE_CAPACITY; i++) {
            const SqMessage *message = &mission->queue[i];
            uint8_t *record          = &out[64U + (i * RECORD)];
            mission_core_write_le(record, message->id, 8U);
            mission_core_write_le(&record[8U], message->expires_s, 8U);
            mission_core_write_le(&record[16U], message->next_attempt_s, 8U);
            (void)memcpy(&record[24U], message->sender, 10U);
            (void)memcpy(&record[34U], message->destination, 10U);
            record[44U] = message->text_len;
            record[45U] = message->attempts;
            record[46U] = message->status;
            (void)memcpy(&record[47U], message->text, SQ_TEXT_MAX);
        }
        mission_core_write_le(&out[60U], state_crc(out, SQ_SNAPSHOT_BYTES), 4U);
        length = SQ_SNAPSHOT_BYTES;
    }
    return length;
}
static SqResult commit(SqMission *mission)
{
    uint8_t image[SQ_SNAPSHOT_BYTES];
    SqResult result = SQ_OK;
    if ((mission->persist == NULL) || (sq_snapshot(mission, image, sizeof(image)) == 0U)
        || !mission->persist(image, sizeof(image), mission->persist_context)) {
        fail_closed(mission);
        result = SQ_IO;
    }
    return result;
}
static bool load_record(SqMessage *message, const uint8_t *record)
{
    message->id             = mission_core_read_le(record, 8U);
    message->expires_s      = mission_core_read_le(&record[8U], 8U);
    message->next_attempt_s = mission_core_read_le(&record[16U], 8U);
    (void)memcpy(message->sender, &record[24U], 10U);
    (void)memcpy(message->destination, &record[34U], 10U);
    message->text_len = record[44U];
    message->attempts = record[45U];
    message->status   = record[46U];
    (void)memcpy(message->text, &record[47U], SQ_TEXT_MAX);
    message->text[SQ_TEXT_MAX] = '\0';
    return (message->status <= 3U) && (message->attempts <= 3U)
           && (message->text_len <= SQ_TEXT_MAX)
           && ((message->status == 0U)
               || (call_field_valid(message->sender) && call_field_valid(message->destination)
                   && text_valid(message->text, message->text_len)));
}
SqResult sq_load(SqMission *mission, const uint8_t *image, size_t length)
{
    SqResult result = SQ_IO;
    bool valid      = (image != NULL) && (length == SQ_SNAPSHOT_BYTES);
    if (valid) {
        uint32_t crc = (image[4U] == 1U)
                           ? (sq_crc32(&image[64U], length - 64U) ^ sq_crc32(image, 60U))
                           : state_crc(image, length);
        valid        = (memcmp(image, STATE_MAGIC, 4U) == 0)
                && ((image[4U] == 1U) || (image[4U] == 2U) || (image[4U] == 3U))
                && (image[5U] <= 2U) && (image[6U] <= 1U) && (image[7U] <= 1U) && (image[42U] <= 1U)
                && ((image[4U] != 3U) || (image[43U] <= 1U))
                && (mission_core_read_le(&image[60U], 4U) == crc)
                && ((image[7U] == 0U)
                    || (mission_core_read_le(&image[24U], 8U)
                        <= mission_core_read_le(&image[16U], 8U)));
    }
    if (valid) {
        mission->retired          = (image[4U] == 3U) && (image[43U] != 0U);
        mission->command_sequence = mission_core_read_le(&image[8U], 8U);
        mission->time_s           = mission_core_read_le(&image[16U], 8U);
        mission->separated_at_s   = mission_core_read_le(&image[24U], 8U);
        mission->mode             = SQ_SAFE;
        mission->tx_inhibited     = mission->retired || (image[6U] != 0U);
        mission->separated        = image[7U] != 0U;
        (void)memcpy(mission->last_sender, &image[32U], 10U);
        mission->last_sender[9U]   = '\0';
        mission->payload_requested = false;
        mission->payload_on        = false;
        for (size_t i = 0U; (i < SQ_QUEUE_CAPACITY) && valid; i++) {
            valid = load_record(&mission->queue[i], &image[64U + (i * RECORD)]);
        }
    }
    if (valid) {
        mission->storage_healthy = true;
        result                   = (image[4U] == 1U) ? commit(mission) : SQ_OK;
    } else {
        fail_closed(mission);
    }
    return result;
}
static SqResult message(SqMission *mission, const uint8_t *data, size_t size)
{
    SqResult result = SQ_INVALID;
    if (size >= 33U) {
        uint8_t text_length = data[32U];
        uint32_t ttl        = (uint32_t)mission_core_read_le(&data[28U], 4U);
        if ((size == (33U + text_length)) && (ttl != 0U) && (ttl <= 86400U)
            && (mission->time_s <= (UINT64_MAX - ttl))) {
            SqMessage candidate;
            (void)memset(&candidate, 0, sizeof(candidate));
            candidate.id = mission_core_read_le(data, 8U);
            (void)memcpy(candidate.sender, &data[8U], 10U);
            (void)memcpy(candidate.destination, &data[18U], 10U);
            if (call_field_valid(candidate.sender) && call_field_valid(candidate.destination)
                && text_valid((const char *)&data[33U], text_length)) {
                (void)memcpy(candidate.text, &data[33U], text_length);
                candidate.text_len       = text_length;
                candidate.expires_s      = mission->time_s + ttl;
                candidate.next_attempt_s = mission->time_s;
                candidate.status         = 1U;
                size_t free_slot         = SQ_QUEUE_CAPACITY;
                size_t count             = 0U;
                bool duplicate           = false;
                for (size_t i = 0U; (i < SQ_QUEUE_CAPACITY) && !duplicate; i++) {
                    SqMessage *entry = &mission->queue[i];
                    if ((entry->status != 0U) && (entry->expires_s <= mission->time_s)) {
                        (void)memset(entry, 0, sizeof(*entry));
                    }
                    if ((entry->status != 0U) && (entry->id == candidate.id)) {
                        duplicate = true;
                        result    = (strcmp(entry->sender, candidate.sender) == 0) ? SQ_DUPLICATE
                                                                                   : SQ_INVALID;
                    }
                    if ((entry->status == 1U) && (strcmp(entry->sender, candidate.sender) == 0)) {
                        count++;
                    }
                    if ((entry->status == 0U) && (free_slot == SQ_QUEUE_CAPACITY)) {
                        free_slot = i;
                    }
                }
                if (!duplicate) {
                    result = SQ_FULL;
                    if ((count < SQ_SENDER_QUOTA) && (free_slot < SQ_QUEUE_CAPACITY)) {
                        mission->queue[free_slot] = candidate;
                        result                    = commit(mission);
                    }
                }
            }
        }
    }
    return result;
}
static SqResult standard_command(SqMission *mission, const uint8_t *payload, size_t length)
{
    uint8_t id      = payload[0U];
    SqResult result = SQ_INVALID;
    if (((id == SQ_CMD_SET_MODE) && (length == 2U) && (payload[1U] <= 2U))
        || ((id != SQ_CMD_SET_MODE) && (length == 1U))) {
        result = SQ_OK;
        switch (id) {
            case SQ_CMD_NOP:
            case SQ_CMD_GET_STATUS:
                break;
            case SQ_CMD_END_MISSION:
                mission->retired           = true;
                mission->mode              = SQ_SAFE;
                mission->tx_inhibited      = true;
                mission->payload_requested = false;
                mission->payload_on        = false;
                break;
            case SQ_CMD_RESET:
                mission->mode              = SQ_SAFE;
                mission->payload_requested = false;
                mission->payload_on        = false;
                break;
            case SQ_CMD_SET_MODE:
                if ((payload[1U] != 0U)
                    && (mission->retired || !mission->eps_valid || (mission->soc_permille < 400U)
                        || (mission->temperature_centi_c >= 5500))) {
                    result = SQ_NOT_ALLOWED;
                } else {
                    mission->mode = (SqMode)payload[1U];
                    if (mission->mode == SQ_SAFE) {
                        mission->payload_on = false;
                    }
                }
                break;
            case SQ_CMD_TX_DISABLE:
                mission->tx_inhibited = true;
                break;
            case SQ_CMD_TX_ENABLE:
                if (mission->retired || !mission->eps_valid || !mission->separated
                    || (mission->time_s < mission->separated_at_s)
                    || ((mission->time_s - mission->separated_at_s) < 1800U)
                    || (mission->soc_permille < 400U)) {
                    result = SQ_NOT_ALLOWED;
                } else {
                    mission->tx_inhibited = false;
                }
                break;
            case SQ_CMD_PAYLOAD_ENABLE:
                if (mission->retired) {
                    result = SQ_NOT_ALLOWED;
                } else {
                    mission->payload_requested = true;
                }
                break;
            case SQ_CMD_PAYLOAD_DISABLE:
                mission->payload_requested = false;
                mission->payload_on        = false;
                break;
            default:
                result = SQ_INVALID;
                break;
        }
    }
    return result;
}
static SqResult command(SqMission *mission,
                        const uint8_t *frame,
                        size_t size,
                        size_t payload_length,
                        uint64_t sequence)
{
    SqResult result = SQ_AUTH;
    if (mission->key_provisioned
        && (crypto_ed25519_check(&frame[size - SIGNATURE],
                                 mission->public_key,
                                 frame,
                                 size - SIGNATURE)
            == 0)) {
        result = SQ_REPLAY;
        if (sequence > mission->command_sequence) {
            result = SQ_INVALID;
            if (payload_length != 0U) {
                const uint8_t *payload = &frame[HEADER];
                uint8_t id             = payload[0U];
                bool extended = (id >= SQ_CMD_UPDATE_BEGIN) && (id <= SQ_CMD_UPDATE_STATUS);
                if ((sequence == UINT64_MAX) && (id != SQ_CMD_END_MISSION)) {
                    /* Reserve the terminal nonce for irreversible shutdown. */
                    result = SQ_NOT_ALLOWED;
                } else if (extended) {
                    result = SQ_NOT_ALLOWED;
                    if (mission->extended_command != NULL) {
                        result = mission->extended_command(mission->command_context,
                                                           payload,
                                                           payload_length,
                                                           false);
                    }
                } else {
                    result = standard_command(mission, payload, payload_length);
                }
                if (result == SQ_OK) {
                    mission->command_sequence = sequence;
                    result                    = commit(mission);
                    if ((result == SQ_OK) && extended) {
                        result = mission->extended_command(mission->command_context,
                                                           payload,
                                                           payload_length,
                                                           true);
                    }
                    if ((result == SQ_OK) && (id == SQ_CMD_RESET)) {
                        mission->reset_requested = true;
                    }
                }
            }
        }
    }
    return result;
}
SqResult sq_receive(SqMission *mission, const uint8_t *frame, size_t size)
{
    SqResult result = SQ_INVALID;
    if (sq_frame_valid(frame, size)) {
        result = SQ_IO;
        if (mission->storage_healthy) {
            size_t length = (size_t)mission_core_read_le(&frame[12U], 2U);
            uint8_t kind  = frame[3U];
            result        = SQ_INVALID;
            if (kind == SQ_KIND_COMMAND) {
                result =
                    command(mission, frame, size, length, mission_core_read_le(&frame[4U], 8U));
            } else if (kind == SQ_KIND_MESSAGE) {
                result =
                    mission->retired ? SQ_NOT_ALLOWED : message(mission, &frame[HEADER], length);
            } else if ((kind == SQ_KIND_ACK) && (length == 18U)) {
                char recipient[10];
                (void)memcpy(recipient, &frame[HEADER + 8U], 10U);
                if (call_field_valid(recipient)) {
                    result = sq_acknowledge(mission,
                                            mission_core_read_le(&frame[HEADER], 8U),
                                            recipient);
                }
            } else {
                /* Unsupported frame kind. */
            }
        }
    }
    return result;
}
bool sq_tx_allowed(const SqMission *mission)
{
    return !mission->retired && mission->eps_valid && mission->storage_healthy && mission->separated
           && (mission->time_s >= mission->separated_at_s)
           && ((mission->time_s - mission->separated_at_s) >= 1800U) && !mission->tx_inhibited
           && (mission->mode != SQ_SAFE) && (mission->soc_permille >= 250U);
}
size_t sq_queue_count(const SqMission *mission)
{
    size_t count = 0U;
    for (size_t i = 0U; i < SQ_QUEUE_CAPACITY; i++) {
        if ((mission->queue[i].status == 1U) && (mission->queue[i].expires_s > mission->time_s)) {
            count++;
        }
    }
    return count;
}
SqResult sq_acknowledge(SqMission *mission, uint64_t id, const char *recipient)
{
    SqResult result = SQ_NOT_FOUND;
    bool found      = false;
    for (size_t i = 0U; (i < SQ_QUEUE_CAPACITY) && !found; i++) {
        SqMessage *entry = &mission->queue[i];
        if ((entry->status != 0U) && (entry->id == id)
            && (strcmp(entry->destination, recipient) == 0)) {
            found  = true;
            result = SQ_NOT_ALLOWED;
            if (entry->attempts != 0U) {
                entry->status = 2U;
                result        = commit(mission);
            }
        }
    }
    return result;
}
static bool eligible(const SqMission *mission, const SqMessage *entry, const char *recipient)
{
    return (entry->status == 1U) && (entry->expires_s > mission->time_s)
           && (entry->next_attempt_s <= mission->time_s) && (entry->attempts < 3U)
           && ((recipient == NULL) || (strcmp(entry->destination, recipient) == 0));
}
SqResult sq_next_for(SqMission *mission, const char *recipient, SqMessage *out)
{
    SqResult result = SQ_NOT_ALLOWED;
    if (sq_tx_allowed(mission)) {
        result = SQ_INVALID;
        if (((recipient == NULL) || call_valid(recipient)) && (out != NULL)) {
            const char *next  = NULL;
            const char *first = NULL;
            for (size_t i = 0U; i < SQ_QUEUE_CAPACITY; i++) {
                const SqMessage *entry = &mission->queue[i];
                if (eligible(mission, entry, recipient)) {
                    if ((first == NULL) || (strcmp(entry->sender, first) < 0)) {
                        first = entry->sender;
                    }
                    if ((strcmp(entry->sender, mission->last_sender) > 0)
                        && ((next == NULL) || (strcmp(entry->sender, next) < 0))) {
                        next = entry->sender;
                    }
                }
            }
            if (next == NULL) {
                next = first;
            }
            result     = SQ_NOT_FOUND;
            bool found = false;
            for (size_t i = 0U; (i < SQ_QUEUE_CAPACITY) && (next != NULL) && !found; i++) {
                SqMessage *entry = &mission->queue[i];
                if (eligible(mission, entry, recipient) && (strcmp(entry->sender, next) == 0)) {
                    found = true;
                    (void)memcpy(mission->last_sender, entry->sender, 10U);
                    entry->attempts++;
                    if (entry->attempts == 3U) {
                        entry->status = 3U;
                    }
                    entry->next_attempt_s = (mission->time_s > (UINT64_MAX - 60U))
                                                ? UINT64_MAX
                                                : (mission->time_s + 60U);
                    *out                  = *entry;
                    result                = commit(mission);
                }
            }
        }
    }
    return result;
}
SqResult sq_next(SqMission *mission, SqMessage *out)
{
    return sq_next_for(mission, NULL, out);
}
SqResult sq_relay_request(SqMission *mission,
                          const uint8_t *frame,
                          size_t size,
                          uint8_t *out,
                          size_t cap,
                          size_t *length)
{
    SqResult result = SQ_INVALID;
    if (length != NULL) {
        *length = 0U;
    }
    if ((out != NULL) && (length != NULL) && (size == 28U) && (cap >= 179U)
        && sq_frame_valid(frame, size) && (frame[3U] == SQ_KIND_RELAY_REQUEST)
        && (mission_core_read_le(&frame[12U], 2U) == 10U)) {
        char recipient[10];
        (void)memcpy(recipient, &frame[14U], 10U);
        if (call_field_valid(recipient)) {
            SqMessage relayed;
            result = sq_next_for(mission, recipient, &relayed);
            if (result == SQ_OK) {
                (void)memset(out, 0, 47U);
                out[0U] = 0x53U;
                out[1U] = 0x51U;
                out[2U] = SQ_PROTOCOL_VERSION;
                out[3U] = SQ_KIND_MESSAGE;
                mission_core_write_le(&out[4U], relayed.id, 8U);
                mission_core_write_le(&out[12U], (uint64_t)33U + relayed.text_len, 2U);
                mission_core_write_le(&out[14U], relayed.id, 8U);
                (void)memcpy(&out[22U], relayed.sender, 10U);
                (void)memcpy(&out[32U], relayed.destination, 10U);
                mission_core_write_le(&out[42U], relayed.expires_s - mission->time_s, 4U);
                out[46U] = relayed.text_len;
                (void)memcpy(&out[47U], relayed.text, relayed.text_len);
                *length = sq_frame_finish(out, 47U + relayed.text_len, cap);
            }
        }
    }
    return result;
}
void sq_tick(SqMission *mission, uint64_t seconds, uint16_t soc, int16_t temp)
{
    if ((seconds < mission->time_s) || (soc > 1000U) || (temp < -5000) || (temp > 10000)) {
        mission->eps_valid  = false;
        mission->mode       = SQ_SAFE;
        mission->payload_on = false;
    } else {
        mission->eps_valid           = true;
        mission->time_s              = seconds;
        mission->soc_permille        = soc;
        mission->temperature_centi_c = temp;
        if (mission->retired || (soc < 250U) || (temp >= 5500) || !mission->storage_healthy) {
            mission->mode = SQ_SAFE;
        }
        mission->payload_on = !mission->retired && mission->payload_requested
                              && (mission->mode != SQ_SAFE) && (soc >= 650U) && (temp >= 0)
                              && (temp < 5500) && mission->storage_healthy;
        for (size_t i = 0U; i < SQ_QUEUE_CAPACITY; i++) {
            SqMessage *entry = &mission->queue[i];
            if ((entry->status != 0U) && (entry->expires_s <= seconds)) {
                (void)memset(entry, 0, sizeof(*entry));
            }
        }
    }
}
void sq_tick_unavailable(SqMission *mission, uint64_t seconds)
{
    sq_tick(mission, seconds, 0U, 0);
    mission->eps_valid  = false;
    mission->payload_on = false;
    mission->mode       = SQ_SAFE;
}
void sq_separation(SqMission *mission)
{
    if (!mission->separated) {
        mission->separated      = true;
        mission->separated_at_s = mission->time_s;
        (void)commit(mission);
    }
}
size_t sq_health_frame(const SqMission *mission,
                       uint64_t transaction,
                       uint8_t *out,
                       size_t capacity)
{
    size_t length = 0U;
    if ((out != NULL) && (capacity >= 33U)) {
        out[0U] = 0x53U;
        out[1U] = 0x51U;
        out[2U] = SQ_PROTOCOL_VERSION;
        out[3U] = SQ_KIND_HEALTH;
        mission_core_write_le(&out[4U], transaction, 8U);
        mission_core_write_le(&out[12U], 15U, 2U);
        mission_core_write_le(&out[14U], mission->time_s, 8U);
        mission_core_write_le(&out[22U], mission->soc_permille, 2U);
        mission_core_write_le(&out[24U], (uint16_t)mission->temperature_centi_c, 2U);
        out[26U] = (uint8_t)mission->mode;
        out[27U] =
            (uint8_t)((mission->tx_inhibited ? 1U : 0U) | (sq_tx_allowed(mission) ? 2U : 0U)
                      | (mission->payload_on ? 4U : 0U) | (mission->storage_healthy ? 8U : 0U)
                      | (mission->eps_valid ? 16U : 0U) | (mission->retired ? 32U : 0U));
        out[28U] = (uint8_t)sq_queue_count(mission);
        length   = sq_frame_finish(out, 29U, capacity);
    }
    return length;
}

size_t sq_command_result_frame(uint64_t sequence,
                               uint8_t id,
                               SqResult result,
                               uint8_t *out,
                               size_t cap)
{
    size_t length = 0U;
    if ((out != NULL) && (cap >= 20U) && ((unsigned)result <= (unsigned)SQ_NOT_FOUND)) {
        (void)memset(out, 0, 16U);
        out[0U] = 0x53U;
        out[1U] = 0x51U;
        out[2U] = SQ_PROTOCOL_VERSION;
        out[3U] = SQ_KIND_COMMAND_RESULT;
        mission_core_write_le(&out[4U], sequence, 8U);
        mission_core_write_le(&out[12U], 2U, 2U);
        out[14U] = id;
        out[15U] = (uint8_t)result;
        length   = sq_frame_finish(out, 16U, cap);
    }
    return length;
}
