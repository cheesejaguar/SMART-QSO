#ifndef SQ_PAYLOAD_LINK_H
#define SQ_PAYLOAD_LINK_H
#include "mission_core.h"
#define SQ_DESCRIPTION_MAX 120U
typedef struct
{
    uint64_t sequence;
    uint64_t last_time;
    uint64_t powered_at;
    uint64_t deadline;
    uint64_t next_request;
    uint64_t backoff_until;
    uint64_t observed;
    uint64_t shutdown_at;
    uint16_t soc;
    SqMode mode;
    bool tx;
    bool powered;
    bool pending;
    bool accepted;
    bool faulted;
    char description[SQ_DESCRIPTION_MAX + 1U];
    uint32_t rejected;
    uint32_t timeouts;
} SqPayload;
void sq_payload_init(SqPayload *p);
void sq_payload_disconnect(SqPayload *p, const SqMission *m);
/* Returns HEALTH request bytes; power permit is owned by this supervisor. */
size_t sq_payload_poll(SqPayload *p, const SqMission *m, uint8_t *out, size_t cap);
SqResult sq_payload_receive(SqPayload *p, const SqMission *m, const uint8_t *f, size_t n);
const char *sq_payload_description(SqPayload *p, const SqMission *m);
size_t sq_payload_beacon(SqPayload *p,
                         const SqMission *m,
                         uint64_t sequence,
                         uint8_t *out,
                         size_t cap);
#endif
