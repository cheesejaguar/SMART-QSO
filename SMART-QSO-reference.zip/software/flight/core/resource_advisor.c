#include "resource_advisor.h"
bool sq_resource_admit(const SqMission *mission, const SqResourceAdvice *advice, bool approved,
                       uint32_t available, uint32_t worst)
{
    bool admitted = false;
    if ((mission != NULL) && mission->eps_valid && sq_tx_allowed(mission)
        && (worst != 0U) && (worst <= 1000000U) && (available >= worst)) {
        /* Missing/unaccepted/stale advice never changes the deterministic baseline. */
        admitted = true;
        if (approved && (advice != NULL) && (advice->contact_permille <= 1000U)
            && (advice->energy_mj != 0U) && (advice->energy_mj <= 1000000U)
            && (mission->time_s >= advice->observed_s)
            && ((mission->time_s - advice->observed_s) <= 60U)) {
            admitted = (advice->contact_permille >= 250U) && (advice->energy_mj <= available);
        }
    }
    return admitted;
}
