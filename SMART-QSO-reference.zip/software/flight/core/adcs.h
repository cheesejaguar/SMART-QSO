#ifndef SQ_ADCS_H
#define SQ_ADCS_H
#include <stdbool.h>
#include <stdint.h>
/* Reference units: nT, milliseconds, and micro-ampere square metres (uA m^2).
 * No sensor, actuator, orbit or calibration acceptance is implied by this algorithm. */
typedef struct
{
    int32_t bias_nt[3];
    int32_t scale_ppm[3];
    bool reviewed;
} SqMagCalibration;
typedef struct
{
    int32_t previous_nt[3];
    uint64_t observed_ms;
    uint32_t gain_uam2_per_ntps;
    uint32_t limit_uam2;
    bool history;
} SqBdot;
void sq_bdot_init(SqBdot *controller, uint32_t gain, uint32_t limit);
bool sq_mag_calibrate(const SqMagCalibration *calibration, const int32_t raw[3], int32_t out[3]);
/* Invalid/disabled/stale/non-monotonic input clears history and commands zero.
 * The caller must separately enforce EPS, inhibit and interference constraints. */
bool sq_bdot_step(SqBdot *controller,
                  const SqMagCalibration *calibration,
                  const int32_t raw[3],
                  uint64_t now_ms,
                  bool sensor_valid,
                  bool permitted,
                  int32_t moment_uam2[3]);
#endif
