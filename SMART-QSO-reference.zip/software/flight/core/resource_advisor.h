#ifndef SQ_RESOURCE_ADVISOR_H
#define SQ_RESOURCE_ADVISOR_H
#include "mission_core.h"
typedef struct
{
    uint64_t observed_s;
    uint32_t energy_mj;
    uint16_t contact_permille;
} SqResourceAdvice;
/* Deterministic owner provides available energy and verified worst-cycle bound. Models cannot
 * enable RF, change fairness, suppress telecommand reception or alter the energy bound. */
bool sq_resource_admit(const SqMission *m,
                       const SqResourceAdvice *advice,
                       bool approved,
                       uint32_t available,
                       uint32_t worst);
#endif
