#include "runtime.h"

#include <string.h>
void sq_runtime_begin(SqRuntime *runtime, uint32_t now, uint32_t deadline)
{
    runtime->start_ms    = now;
    runtime->deadline_ms = deadline;
    runtime->votes       = 0U;
}
void sq_runtime_vote(SqRuntime *runtime, unsigned task, bool completed)
{
    if ((task < 4U) && completed) {
        runtime->votes |= (UINT32_C(1) << task);
    }
}
bool sq_runtime_healthy(SqRuntime *runtime, uint32_t now)
{
    uint32_t elapsed = now - runtime->start_ms;
    bool healthy     = (elapsed < 0x80000000U) && (runtime->deadline_ms < 0x80000000U)
                   && (elapsed <= runtime->deadline_ms) && (runtime->votes == 15U);
    if ((elapsed < 0x80000000U) && (elapsed > runtime->max_elapsed_ms)) {
        runtime->max_elapsed_ms = elapsed;
    }
    if (!healthy && (runtime->faults < UINT32_MAX)) {
        runtime->faults++;
    }
    return healthy;
}
bool sq_periodic_init(SqPeriodic *schedule, uint32_t period_s)
{
    bool valid = (schedule != NULL) && (period_s >= 1U) && (period_s <= 86400U);
    if (schedule != NULL) {
        (void)memset(schedule, 0, sizeof(*schedule));
        schedule->period_s = period_s;
        schedule->faulted  = !valid;
    }
    return valid;
}
bool sq_periodic_due(SqPeriodic *schedule, uint64_t now_s, bool force)
{
    bool due = false;
    if ((schedule->period_s < 1U) || (schedule->period_s > 86400U)) {
        schedule->faulted = true;
    }
    if (now_s < schedule->observed_s) {
        schedule->faulted = true;
    }
    schedule->observed_s = now_s;
    if (!schedule->faulted && !schedule->exhausted && (force || (now_s >= schedule->next_s))) {
        due = true;
        if (now_s > (UINT64_MAX - schedule->period_s)) {
            schedule->exhausted = true;
        } else {
            schedule->next_s = now_s + schedule->period_s;
        }
    }
    return due;
}
