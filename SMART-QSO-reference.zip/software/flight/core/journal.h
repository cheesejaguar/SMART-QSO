#ifndef SQ_JOURNAL_H
#define SQ_JOURNAL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
void sq_journal_header(uint32_t generation, const uint8_t *p, size_t n, uint8_t out[16]);
bool sq_journal_valid(const uint8_t head[16], const uint8_t *p, size_t n, uint32_t *generation);
#endif
