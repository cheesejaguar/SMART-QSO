#ifndef SQ_MISSION_CORE_H
#define SQ_MISSION_CORE_H
#include "protocol_generated.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define SQ_QUEUE_CAPACITY 32U
#define SQ_TEXT_MAX       128U
#define SQ_SENDER_QUOTA   4U
#define SQ_FRAME_MAX      240U
#define SQ_SNAPSHOT_BYTES (64U + (SQ_QUEUE_CAPACITY * 184U))
typedef enum
{
    SQ_OK          = 0,
    SQ_INVALID     = 1,
    SQ_AUTH        = 2,
    SQ_REPLAY      = 3,
    SQ_FULL        = 4,
    SQ_DUPLICATE   = 5,
    SQ_IO          = 6,
    SQ_NOT_ALLOWED = 7,
    SQ_NOT_FOUND   = 8
} SqResult;
typedef enum
{
    SQ_SAFE  = 0,
    SQ_IDLE  = 1,
    SQ_RELAY = 2
} SqMode;
typedef struct
{
    uint64_t id;
    uint64_t expires_s;
    uint64_t next_attempt_s;
    char sender[10];
    char destination[10];
    char text[129];
    uint8_t text_len;
    uint8_t attempts;
    uint8_t status; /* 0 empty, 1 queued, 2 acknowledged, 3 exhausted */
} SqMessage;
typedef bool (*SqPersist)(const uint8_t *data, size_t size, void *context);
typedef struct SqUpdater SqUpdater;
typedef SqResult (*SqExtendedCommand)(SqUpdater *context,
                                      const uint8_t *payload,
                                      size_t length,
                                      bool execute);
typedef struct
{
    SqMessage queue[SQ_QUEUE_CAPACITY];
    uint64_t command_sequence;
    uint64_t time_s;
    uint64_t separated_at_s;
    uint16_t soc_permille;
    int16_t temperature_centi_c;
    SqMode mode;
    bool tx_inhibited;
    bool payload_requested;
    bool payload_on;
    bool separated;
    bool storage_healthy;
    char last_sender[10];
    uint8_t public_key[32];
    bool key_provisioned;
    bool reset_requested;
    bool eps_valid;
    bool retired;
    SqPersist persist;
    void *persist_context;
    SqExtendedCommand extended_command;
    SqUpdater *command_context;
} SqMission;
void sq_init(SqMission *m, const uint8_t key[32], SqPersist persist, void *context);
SqResult sq_load(SqMission *m, const uint8_t *image, size_t len);
size_t sq_snapshot(const SqMission *m, uint8_t *out, size_t cap);
SqResult sq_receive(SqMission *m, const uint8_t *f, size_t n);
SqResult sq_acknowledge(SqMission *m, uint64_t id, const char *recipient);
SqResult sq_next(SqMission *m, SqMessage *out);
SqResult sq_next_for(SqMission *m, const char *recipient, SqMessage *out);
SqResult sq_relay_request(SqMission *m,
                          const uint8_t *f,
                          size_t n,
                          uint8_t *out,
                          size_t cap,
                          size_t *length);
void sq_tick(SqMission *m, uint64_t seconds, uint16_t soc, int16_t temp);
void sq_tick_unavailable(SqMission *m, uint64_t seconds);
void sq_separation(SqMission *m);
bool sq_tx_allowed(const SqMission *m);
size_t sq_queue_count(const SqMission *m);
size_t sq_health_frame(const SqMission *m, uint64_t transaction, uint8_t *out, size_t capacity);
size_t sq_command_result_frame(uint64_t sequence,
                               uint8_t id,
                               SqResult result,
                               uint8_t *out,
                               size_t cap);
uint32_t sq_crc32(const uint8_t *p, size_t n);
size_t sq_frame_finish(uint8_t *out, size_t length, size_t cap);
bool sq_frame_valid(const uint8_t *f, size_t n);
#endif
