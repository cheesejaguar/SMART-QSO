#ifndef SQ_HOST_API_H
#define SQ_HOST_API_H
/* Host-only opaque ABI. This formatting/harness layer is never linked into ARM images. */
#include "mission_core.h"
#include "payload_link.h"
#include "update_stream.h"
size_t sq_mission_size(void);
size_t sq_updater_size(void);
size_t sq_payload_size(void);
void sq_attach_updater(SqMission *m, SqUpdater *u);
uint32_t sq_update_written(const SqUpdater *u);
bool sq_update_active(const SqUpdater *u);
bool sq_update_complete(const SqUpdater *u);
bool sq_update_faulted(const SqUpdater *u);
void sq_update_boot_state(const SqUpdater *u, uint8_t out[64]);
bool sq_payload_power(const SqPayload *p);
bool sq_payload_accepted(const SqPayload *p);
bool sq_payload_pending(const SqPayload *p);
void sq_payload_sync_power(const SqPayload *p, SqMission *m);
size_t sq_status_json(const SqMission *m, char *out, size_t cap);
bool sq_update_recovering(const SqUpdater *u);
uint32_t sq_update_length(const SqUpdater *u);
#endif
