#ifndef SQ_TRANSPORT_H
#define SQ_TRANSPORT_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
typedef struct
{
    uint8_t data[512];
    size_t length;
    bool active;
    bool escape;
} SqKiss;
void sq_kiss_init(SqKiss *k);
/* Returns a bounded protocol information field only for AX.25 UI/F0 KISS data. */
size_t sq_kiss_feed(SqKiss *k, uint8_t value, uint8_t *out, size_t cap);
size_t sq_raw_kiss_feed(SqKiss *k, uint8_t value, uint8_t *out, size_t cap);
size_t sq_kiss_encode(const uint8_t *p, size_t n, uint8_t *out, size_t cap);
#endif
