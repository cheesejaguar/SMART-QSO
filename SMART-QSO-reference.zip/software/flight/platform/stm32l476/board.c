/* NUCLEO-L476RG development BSP. Register map: ST RM0351. Hardware acceptance pending. */
#include "board.h"

#include "journal.h"

#include <string.h>
#define REG(address) (*(volatile uint32_t *)(address))
#define RCC          0x40021000UL
#define GPIOA        0x48000000UL
#define USART2       0x40004400UL
#define USART1       0x40013800UL
#define TIM2         0x40000000UL
#define DMA1         0x40020000UL
#define PWR          0x40007000UL
#define FLASH        0x40022000UL
#define IWDG         0x40003000UL
#define BANK_A       0x080F0000UL
#define BANK_B       0x080F4000UL
static uint32_t generation;
static uint32_t active_bank = BANK_B;
static volatile uint8_t command_rx[8192], payload_rx[512];
static uint32_t command_tail, payload_tail, last_timer, milliseconds, timer_fraction;
static bool wait_bit(uint32_t address, uint32_t mask, uint32_t value)
{
    uint32_t bound = 800000U;
    while ((REG(address) & mask) != value && bound > 0U) {
        bound--;
    }
    return bound != 0U;
}
static bool clock_80mhz(void)
{
    /* ST NUCLEO-L476 reference: MSI 4 MHz / M1 * N40 / R2, VOS range1, four wait states. */
    if ((REG(RCC + 8) & 12U) == 12U && (REG(RCC + 0x0CUL) & 0x07007F73U) == 0x01002801U
        && (REG(RCC + 8) & 0x3FF0U) == 0U && (REG(FLASH) & 7U) == 4U) {
        return true;
    }
    REG(RCC + 0x58UL) |= 1UL << 28U;
    REG(PWR) = (REG(PWR) & ~(3UL << 9U)) | (1UL << 9U);
    if (!wait_bit(PWR + 0x14UL, 1UL << 10U, 0)) {
        return false;
    }
    REG(FLASH) = (REG(FLASH) & ~7UL) | 4UL | (1UL << 8U) | (1UL << 9U) | (1UL << 10U);
    if (!wait_bit(FLASH, 7U, 4U)) {
        return false;
    }
    REG(RCC) |= 1U;
    if (!wait_bit(RCC, 2U, 2U)) {
        return false;
    }
    REG(RCC + 8) &= ~3UL;
    if (!wait_bit(RCC + 8, 12U, 0)) {
        return false;
    }
    REG(RCC) &= ~(1UL << 24U);
    if (!wait_bit(RCC, 1UL << 25U, 0)) {
        return false;
    }
    REG(RCC)          = (REG(RCC) & ~(15UL << 4U)) | (6UL << 4U) | (1UL << 3U) | 1U;
    REG(RCC + 0x0CUL) = 1UL | (40UL << 8U) | (1UL << 24U);
    REG(RCC) |= 1UL << 24U;
    if (!wait_bit(RCC, 1UL << 25U, 1UL << 25U)) {
        return false;
    }
    REG(RCC + 8) = (REG(RCC + 8) & ~0x7FF3UL) | 3UL;
    return wait_bit(RCC + 8, 12U, 12U);
}
static void receive_dma(unsigned channel, uint32_t uart, volatile uint8_t *buffer, uint32_t size)
{
    uint32_t base = DMA1 + 8U + 20U * (channel - 1U);
    REG(base)     = 0;
    REG(DMA1 + 0xA8UL) =
        (REG(DMA1 + 0xA8UL) & ~(15UL << (4U * (channel - 1U)))) | (2UL << (4U * (channel - 1U)));
    REG(base + 4)  = size;
    REG(base + 8)  = uart + 0x24UL;
    REG(base + 12) = (uint32_t)buffer;
    REG(base) =
        1UL | (1UL << 5U) | (1UL << 7U) | (2UL << 12U); /* Circular byte RX, high priority. */
    REG(uart + 8) |= 1UL << 6U;
}
static bool dma_read(unsigned channel,
                     uint32_t uart,
                     volatile uint8_t *buffer,
                     uint32_t size,
                     uint32_t *tail,
                     uint8_t *v)
{
    uint32_t base  = DMA1 + 8U + 20U * (channel - 1U);
    uint32_t head  = (size - REG(base + 4)) % size;
    uint32_t shift = 4U * (channel - 1U), flags = (REG(DMA1) >> shift) & 15U;
    if ((REG(uart + 0x1CUL) & 15U) || (flags & 8U) || ((flags & 6U) == 6U)) {
        /* Conservatively discard after UART/DMA error or a complete unserviced ring traversal. */
        REG(uart + 0x20UL) = 15U;
        REG(DMA1 + 4)      = 15UL << shift;
        *tail              = head;
        return false;
    }
    if (flags) {
        REG(DMA1 + 4) = 15UL << shift;
    }
    if (*tail == head) {
        return false;
    }
    *v    = buffer[*tail];
    *tail = (*tail + 1U) % size;
    return true;
}
void sq_board_init(void)
{
    extern uint32_t g_vector_table[];
    REG(0xE000ED08UL) = (uint32_t)g_vector_table;
    REG(0xE000ED88UL) |= 0xFUL << 20U; /* FreeRTOS CM4F port saves FP context. */
    REG(RCC + 0x4CUL) |= 1UL;
    REG(GPIOA) = (REG(GPIOA) & ~((3UL << 12U) | (3UL << 14U))) | (1UL << 12U) | (1UL << 14U);
    sq_outputs(false, false);
    if (!clock_80mhz()) {
        sq_panic();
    }
    REG(RCC + 0x58UL) |= (1UL << 17U) | 1UL;
    REG(RCC + 0x48UL) |= 1UL;
    REG(TIM2) = 0;
    REG(TIM2 + 0x28UL) =
        39999; /* 80 MHz / 40000 -> continuous 2 kHz, accumulated to milliseconds. */
    REG(TIM2 + 0x2CUL) = UINT32_MAX;
    REG(TIM2 + 0x14UL) = 1;
    REG(TIM2 + 0x24UL) = 0;
    REG(TIM2)          = 1;
    REG(GPIOA) &= ~((3UL << 4U) | (3UL << 6U) | (3UL << 10U) | (3UL << 12U) | (3UL << 14U));
    REG(GPIOA) |= (2UL << 4U) | (2UL << 6U) | (1UL << 10U) | (1UL << 12U) | (1UL << 14U);
    REG(GPIOA + 0x20UL) =
        (REG(GPIOA + 0x20UL) & ~((15UL << 8U) | (15UL << 12U))) | (7UL << 8U) | (7UL << 12U);
    REG(USART2)          = 0;
    REG(USART2 + 0x0CUL) = 694; /* 80 MHz / 694 ~= 115273 baud. */
    REG(USART2)          = 1UL | (1UL << 2U) | (1UL << 3U);
    REG(RCC + 0x60UL) |= 1UL << 14U;
    REG(GPIOA) = (REG(GPIOA) & ~((3UL << 18U) | (3UL << 20U))) | (2UL << 18U) | (2UL << 20U);
    REG(GPIOA + 0x24UL) =
        (REG(GPIOA + 0x24UL) & ~((15UL << 4U) | (15UL << 8U))) | (7UL << 4U) | (7UL << 8U);
    REG(USART1)          = 0;
    REG(USART1 + 0x0CUL) = 694;
    REG(USART1)          = 1UL | (1UL << 2U) | (1UL << 3U);
    receive_dma(6, USART2, command_rx, sizeof(command_rx));
    receive_dma(5, USART1, payload_rx, sizeof(payload_rx));
    sq_outputs(false, false);
}
void sq_outputs(bool tx, bool payload)
{
    REG(GPIOA + 0x18UL) =
        (tx ? (1UL << 6U) : (1UL << 22U)) | (payload ? (1UL << 7U) : (1UL << 23U));
}
void sq_panic(void)
{
    sq_outputs(false, false);
    __asm volatile("cpsid i");
    for (;;) {
        __asm volatile("wfi");
    }
}
void sq_watchdog_start(void)
{
    REG(RCC + 0x94UL) |= 1UL;
    REG(IWDG)     = 0x5555;
    REG(IWDG + 4) = 6;
    REG(IWDG + 8) = 625;
    REG(IWDG)     = 0xCCCC;
}
void sq_watchdog_feed(void)
{
    REG(IWDG) = 0xAAAA;
}
uint32_t sq_board_milliseconds(void)
{
    uint32_t now = REG(TIM2 + 0x24UL), delta = now - last_timer;
    last_timer = now;
    milliseconds += delta / 2U;
    timer_fraction += delta % 2U;
    milliseconds += timer_fraction / 2U;
    timer_fraction %= 2U;
    return milliseconds;
}
bool sq_uart_read(uint8_t *v)
{
    return dma_read(6, USART2, command_rx, sizeof(command_rx), &command_tail, v);
}
bool sq_payload_uart_read(uint8_t *v)
{
    return dma_read(5, USART1, payload_rx, sizeof(payload_rx), &payload_tail, v);
}
bool sq_payload_uart_write(const uint8_t *p, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        uint32_t bound = 20000;
        while (!(REG(USART1 + 0x1CUL) & (1UL << 7U)) && bound > 0U) {
            bound--;
        }
        if (!bound) {
            return false;
        }
        REG(USART1 + 0x28UL) = p[i];
    }
    return true;
}
bool sq_uart_write(const uint8_t *data, size_t size)
{
    for (size_t i = 0; i < size; i++) {
        uint32_t bound = 20000;
        while ((REG(USART2 + 0x1CUL) & (1UL << 7U)) == 0 && bound > 0) {
            bound--;
        }
        if (bound == 0) {
            return false;
        }
        REG(USART2 + 0x28UL) = data[i];
    }
    return true;
}
static bool flash_wait(void)
{
    uint32_t bound = 400000;
    while ((REG(FLASH + 0x10UL) & (1UL << 16U)) && bound > 0) {
        bound--;
    }
    return bound > 0;
}
static bool unlock(void)
{
    if (!flash_wait()) {
        return false;
    }
    if (REG(FLASH + 0x14UL) & (1UL << 31U)) {
        REG(FLASH + 8) = 0x45670123;
        REG(FLASH + 8) = 0xCDEF89AB;
    }
    REG(FLASH + 0x10UL) = 0xC3FA;
    return (REG(FLASH + 0x14UL) & (1UL << 31U)) == 0;
}
static bool erase(uint32_t address)
{
    if (address < 0x08000000UL || address >= 0x08100000UL || address % 2048UL) {
        return false;
    }
    uint32_t page       = (address - 0x08000000UL) / 2048UL;
    REG(FLASH + 0x14UL) = (1UL << 1U) | ((page & 255UL) << 3U) | (page >= 256U ? (1UL << 11U) : 0U);
    REG(FLASH + 0x14UL) |= 1UL << 16U;
    bool ok             = flash_wait() && (REG(FLASH + 0x10UL) & 0xC3FA) == 0;
    REG(FLASH + 0x14UL) = 0;
    return ok;
}
static bool program(uint32_t address, const uint8_t *data, size_t size)
{
    if (address % 8U || size % 8U) {
        return false;
    }
    for (size_t i = 0; i < size; i += 8) {
        uint32_t lo, hi;
        memcpy(&lo, data + i, 4);
        memcpy(&hi, data + i + 4, 4);
        REG(FLASH + 0x14UL)            = 1;
        REG(address + (uint32_t)i)     = lo;
        REG(address + (uint32_t)i + 4) = hi;
        if (!flash_wait() || (REG(FLASH + 0x10UL) & 0xC3FA)) {
            REG(FLASH + 0x14UL) = 0;
            return false;
        }
        REG(FLASH + 0x14UL) = 0;
    }
    return true;
}
static bool valid_bank(uint32_t address)
{
    const uint8_t *p = (const uint8_t *)address;
    uint32_t gen;
    return sq_journal_valid(p, p + 16, SQ_SNAPSHOT_BYTES, &gen);
}
bool sq_board_persist(const uint8_t *data, size_t size, void *context)
{
    (void)context;
    if (size != SQ_SNAPSHOT_BYTES || generation == UINT32_MAX || !unlock()) {
        return false;
    }
    uint32_t target = active_bank == BANK_A ? BANK_B : BANK_A;
    for (uint32_t i = 0; i < 4; i++) {
        if (!erase(target + i * 2048UL)) {
            REG(FLASH + 0x14UL) = 1UL << 31U;
            return false;
        }
    }
    if (!program(target + 16, data, size)) {
        REG(FLASH + 0x14UL) = 1UL << 31U;
        return false;
    }
    uint8_t head[16];
    sq_journal_header(generation + 1, data, size, head);
    bool ok             = program(target, (const uint8_t *)head, 16);
    REG(FLASH + 0x14UL) = 1UL << 31U;
    if (ok && valid_bank(target)) {
        active_bank = target;
        generation++;
        return true;
    }
    return false;
}
SqResult sq_board_load(SqMission *m)
{
    bool a = valid_bank(BANK_A), b = valid_bank(BANK_B);
    if (a || b) {
        active_bank = a && (!b || REG(BANK_A + 4) > REG(BANK_B + 4)) ? BANK_A : BANK_B;
        generation  = REG(active_bank + 4);
        return sq_load(m, (const uint8_t *)(active_bank + 16), SQ_SNAPSHOT_BYTES);
    }
    if (REG(BANK_A) == UINT32_MAX && REG(BANK_B) == UINT32_MAX) {
        uint8_t image[SQ_SNAPSHOT_BYTES];
        sq_snapshot(m, image, sizeof(image));
        return sq_board_persist(image, sizeof(image), NULL) ? SQ_OK : SQ_IO;
    }
    m->storage_healthy = false;
    m->tx_inhibited    = true;
    return SQ_IO;
}
void sq_jump(uint32_t address)
{
    uint32_t stack = REG(address), reset = REG(address + 4);
    if (stack < 0x20000000UL || stack > 0x20018000UL || (reset & 1UL) == 0) {
        sq_panic();
    }
    __asm volatile("cpsid i");
    REG(USART1 + 8) &= ~(1UL << 6U);
    REG(USART2 + 8) &= ~(1UL << 6U);
    REG(DMA1 + 0x58UL) &= ~1UL;
    REG(DMA1 + 0x6CUL) &= ~1UL;
    REG(0xE000E010UL) = 0;
    REG(0xE000ED08UL) = address;
    __asm volatile("msr msp, %0\n bx %1" ::"r"(stack), "r"(reset) : "memory");
    __builtin_unreachable();
}

#define BOOT_A 0x080F8000UL
#define BOOT_B 0x080FA000UL
static uint32_t boot_bank = BOOT_B;
bool sq_board_boot_load(SqBootState *state)
{
    SqBootState a, b;
    bool va = sq_boot_decode(&a, (const uint8_t *)BOOT_A),
         vb = sq_boot_decode(&b, (const uint8_t *)BOOT_B);
    if (va || vb) {
        if (va && (!vb || a.generation > b.generation)) {
            *state    = a;
            boot_bank = BOOT_A;
        } else {
            *state    = b;
            boot_bank = BOOT_B;
        }
        return true;
    }
    memset(state, 0, sizeof(*state));
    return REG(BOOT_A) == UINT32_MAX && REG(BOOT_B) == UINT32_MAX;
}
bool sq_board_boot_save(SqBootState *state)
{
    if (state->generation == UINT32_MAX || !unlock()) {
        return false;
    }
    uint32_t bank = boot_bank == BOOT_A ? BOOT_B : BOOT_A;
    if (!erase(bank)) {
        REG(FLASH + 0x14UL) = 1UL << 31U;
        return false;
    }
    state->generation++;
    uint8_t data[64];
    sq_boot_encode(state, data);
    bool ok             = program(bank, data, 64);
    REG(FLASH + 0x14UL) = 1UL << 31U;
    SqBootState check;
    if (ok && sq_boot_decode(&check, (const uint8_t *)bank)) {
        boot_bank = bank;
        return true;
    }
    return false;
}

void sq_board_reset(void)
{
    sq_outputs(false, false);
    REG(0xE000ED0CUL) = 0x05FA0004UL;
    for (;;) {
        __asm volatile("wfi");
    }
}
static bool update_range(unsigned slot, uint32_t offset, size_t n, uint32_t *address)
{
    if (slot > 1U || offset >= SQ_SLOT_BYTES || n > SQ_SLOT_BYTES - offset) {
        return false;
    }
    uint32_t base = slot == 0U ? 0x08010000UL : 0x08070000UL;
    uint32_t vtor = REG(0xE000ED08UL);
    if (vtor >= base && vtor < base + SQ_SLOT_BYTES) {
        return false;
    }
    /* Exact reference geometry: 1 MiB, dual 512 KiB banks, no BFB2 boot remap. */
    if (*(volatile uint16_t *)0x1FFF75E0UL != 1024U || !(REG(FLASH + 0x20UL) & (1UL << 21U))
        || (REG(FLASH + 0x20UL) & (1UL << 20U))) {
        return false;
    }
    *address = base + offset;
    return true;
}
bool sq_board_update_erase(void *context, unsigned slot, uint32_t offset)
{
    (void)context;
    sq_outputs(false, false);
    uint32_t address;
    if (offset % 2048U || !update_range(slot, offset, 2048, &address) || !unlock()) {
        return false;
    }
    bool ok             = erase(address);
    REG(FLASH + 0x14UL) = 1UL << 31U;
    return ok;
}
bool sq_board_update_write(void *context,
                           unsigned slot,
                           uint32_t offset,
                           const uint8_t *p,
                           size_t n)
{
    (void)context;
    uint32_t address;
    if (!update_range(slot, offset, n, &address) || !unlock()) {
        return false;
    }
    bool ok             = program(address, p, n);
    REG(FLASH + 0x14UL) = 1UL << 31U;
    return ok;
}
bool sq_board_update_read(void *context, unsigned slot, uint32_t offset, uint8_t *p, size_t n)
{
    (void)context;
    uint32_t address;
    if (!update_range(slot, offset, n, &address)) {
        return false;
    }
    memcpy(p, (const void *)address, n);
    return true;
}
bool sq_board_update_boot_save(void *context, SqBootState *state)
{
    (void)context;
    return sq_board_boot_save(state);
}
