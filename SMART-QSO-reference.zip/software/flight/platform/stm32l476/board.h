#ifndef SQ_BOARD_H
#define SQ_BOARD_H
#include "mission_core.h"
#include "update.h"
#include "update_stream.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
void sq_board_init(void);
void sq_panic(void);
void sq_watchdog_start(void);
void sq_watchdog_feed(void);
uint32_t sq_board_milliseconds(void);
bool sq_uart_read(uint8_t *value);
bool sq_uart_write(const uint8_t *, size_t);
bool sq_payload_uart_read(uint8_t *);
bool sq_payload_uart_write(const uint8_t *, size_t);
bool sq_board_update_erase(void *, unsigned, uint32_t);
bool sq_board_update_write(void *, unsigned, uint32_t, const uint8_t *, size_t);
bool sq_board_update_read(void *, unsigned, uint32_t, uint8_t *, size_t);
bool sq_board_update_boot_save(void *, SqBootState *);
void sq_outputs(bool tx, bool payload);
bool sq_board_persist(const uint8_t *, size_t, void *);
SqResult sq_board_load(SqMission *);
bool sq_board_boot_load(SqBootState *);
bool sq_board_boot_save(SqBootState *);
void sq_board_reset(void);
void sq_jump(uint32_t address);
#endif
