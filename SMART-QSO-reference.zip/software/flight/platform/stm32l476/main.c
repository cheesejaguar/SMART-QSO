/* Reference firmware: signed command ingress, persistent mission state and static supervisor.
 * EPS/ADCS/RF flight drivers are not selected. Unavailable EPS keeps SAFE and RF OFF.
 */
#include "FreeRTOS.h"
#include "board.h"
#include "keys.h"
#include "payload_link.h"
#include "runtime.h"
#include "task.h"
#include "transport.h"
#include "update_stream.h"

#include <string.h>
static SqMission mission;
static SqRuntime runtime;
static SqPayload payload;
static SqUpdater updater;
static StaticTask_t supervisor_tcb, idle_tcb;
static StackType_t supervisor_stack[4096], idle_stack[configMINIMAL_STACK_SIZE];
void vApplicationGetIdleTaskMemory(StaticTask_t **tcb, StackType_t **stack, uint32_t *size)
{
    *tcb   = &idle_tcb;
    *stack = idle_stack;
    *size  = configMINIMAL_STACK_SIZE;
}
void vApplicationStackOverflowHook(TaskHandle_t task, char *name)
{
    (void)task;
    (void)name;
    sq_panic();
}
/* Wired development/modem-interface UART. Physical RF requires the separate TX permit. */
static bool send_protocol(const uint8_t *p, size_t n)
{
    uint8_t packet[SQ_FRAME_MAX + 16U], wire[2U * SQ_FRAME_MAX + 40U];
    if (n > SQ_FRAME_MAX) {
        return false;
    }
    const uint8_t addresses[16] =
        {156, 96, 134, 130, 152, 152, 96, 156, 96, 134, 130, 152, 152, 97, 3, 240};
    memcpy(packet, addresses, 16);
    memcpy(packet + 16, p, n);
    size_t encoded = sq_kiss_encode(packet, n + 16U, wire, sizeof(wire));
    return encoded && sq_uart_write(wire, encoded);
}
static void supervisor(void *unused)
{
    (void)unused;
    TickType_t last       = xTaskGetTickCount();
    uint64_t uptime       = mission.time_s;
    uint32_t previous     = sq_board_milliseconds();
    uint32_t remainder    = 0;
    uint32_t boot_started = previous;
    uint8_t frame[SQ_FRAME_MAX];
    uint64_t telemetry_sequence = 0;
    SqPeriodic beacon_schedule;
    bool force_beacon = false;
    if (!sq_periodic_init(&beacon_schedule, 60U)) {
        sq_panic();
    }
    SqKiss decoder, payload_decoder;
    sq_kiss_init(&decoder);
    sq_kiss_init(&payload_decoder);
    for (;;) {
        sq_runtime_begin(&runtime, sq_board_milliseconds(), 500);
        uint8_t value;
        for (unsigned count = 0; count < 256U && sq_uart_read(&value); count++) {
            size_t length = sq_kiss_feed(&decoder, value, frame, sizeof(frame));
            if (length != 0U) {
                if (length >= 14U && frame[3] == SQ_KIND_RELAY_REQUEST) {
                    size_t reply_length = 0;
                    uint8_t reply[SQ_FRAME_MAX];
                    if (sq_relay_request(&mission,
                                         frame,
                                         length,
                                         reply,
                                         sizeof(reply),
                                         &reply_length)
                            == SQ_OK
                        && !send_protocol(reply, reply_length)) {
                        mission.tx_inhibited = true;
                    }
                    break;
                }
                SqResult code = sq_receive(&mission, frame, length);
                sq_outputs(sq_tx_allowed(&mission), mission.payload_on && payload.powered);
                if (length >= 15U && frame[3] == SQ_KIND_COMMAND) {
                    uint8_t response[48] = {0};
                    uint64_t sequence    = 0;
                    for (unsigned i = 0; i < 8U; i++) {
                        sequence |= (uint64_t)frame[4U + i] << (8U * i);
                    }
                    size_t response_length = sq_command_result_frame(sequence,
                                                                     frame[14],
                                                                     code,
                                                                     response,
                                                                     sizeof(response));
                    if (!send_protocol(response, response_length)) {
                        mission.tx_inhibited = true;
                    }
                    if (code == SQ_OK && frame[14] == SQ_CMD_UPDATE_STATUS) {
                        size_t status_length = sq_update_status_frame(&updater,
                                                                      mission.command_sequence,
                                                                      response,
                                                                      sizeof(response));
                        if (status_length) {
                            (void)send_protocol(response, status_length);
                        }
                    }
                    if (code == SQ_OK && frame[14] == SQ_CMD_GET_STATUS) {
                        force_beacon = true;
                    }
                }
                break; /* One complete frame per cycle; DMA retains subsequent bytes. */
            }
        }
        sq_runtime_vote(&runtime, 0, true);
        if (mission.reset_requested) {
            sq_board_reset();
        }
        uint32_t now = sq_board_milliseconds();
        remainder += (uint32_t)(now - previous);
        previous = now;
        uptime += remainder / 1000U;
        remainder %= 1000U;
        sq_tick_unavailable(&mission,
                            uptime); /* EPS driver unselected: no fictitious SOC or temperature. */
        sq_runtime_vote(&runtime, 1, true);
        sq_update_poll(&updater);
        size_t request     = sq_payload_poll(&payload, &mission, frame, sizeof(frame));
        mission.payload_on = payload.powered;
        sq_outputs(sq_tx_allowed(&mission), payload.powered);
        if (request) {
            uint8_t wire[2U * SQ_FRAME_MAX + 3U];
            size_t encoded = sq_kiss_encode(frame, request, wire, sizeof(wire));
            if (!encoded || !sq_payload_uart_write(wire, encoded)) {
                sq_payload_disconnect(&payload, &mission);
                mission.payload_on = false;
                sq_outputs(sq_tx_allowed(&mission), false);
            }
        }
        for (unsigned count = 0; count < 256U && sq_payload_uart_read(&value); count++) {
            size_t received = sq_raw_kiss_feed(&payload_decoder, value, frame, sizeof(frame));
            if (received && payload.powered) {
                (void)sq_payload_receive(&payload, &mission, frame, received);
            }
        }
        mission.payload_on = payload.powered;
        sq_outputs(sq_tx_allowed(&mission), payload.powered);
        if (!payload.powered) {
            sq_kiss_init(&payload_decoder);
        }
        (void)sq_payload_description(&payload, &mission);
        if (sq_periodic_due(&beacon_schedule, mission.time_s, force_beacon)
            && telemetry_sequence < UINT64_MAX - 2U) {
            size_t n = sq_health_frame(&mission, ++telemetry_sequence, frame, sizeof(frame));
            if (n) {
                (void)send_protocol(frame, n);
            }
            n = sq_payload_beacon(&payload, &mission, ++telemetry_sequence, frame, sizeof(frame));
            if (n) {
                (void)send_protocol(frame, n);
            }
            force_beacon = false;
        }
        sq_runtime_vote(&runtime, 2, true);
        sq_runtime_vote(&runtime, 3, mission.storage_healthy);
        /* Voting: only feed after completed bounded UART, mission and output phases. */
        bool healthy = sq_runtime_healthy(&runtime, sq_board_milliseconds());
        if (healthy && !updater.active
            && (uint32_t)(sq_board_milliseconds() - boot_started) >= 60000U
            && mission.storage_healthy) {
            SqBootState boot;
            uint64_t running        = 0;
            uint32_t vtor           = *(volatile uint32_t *)0xE000ED08UL;
            const uint8_t *manifest = (const uint8_t *)(vtor - 2048UL);
            for (unsigned i = 0; i < 8U; i++) {
                running |= (uint64_t)manifest[4U + i] << (8U * i);
            }
            if (!sq_board_boot_load(&boot)) {
                mission.storage_healthy = false;
                healthy = false;
            } else if (sq_boot_confirm(&boot, running)) {
                if (sq_board_boot_save(&boot)) {
                    updater.boot = boot;
                } else {
                    mission.storage_healthy = false;
                    healthy = false;
                }
            }
        }
        /* Boot confirmation is a flash phase too: include it in the deadline
         * before feeding the watchdog, rather than using the earlier vote. */
        healthy = healthy && sq_runtime_healthy(&runtime, sq_board_milliseconds());
        if (healthy) {
            sq_watchdog_feed();
        } else {
            mission.mode       = SQ_SAFE;
            mission.payload_on = false;
            payload.faulted    = true;
            payload.powered    = false;
            sq_outputs(false, false);
            last         = xTaskGetTickCount();
            boot_started = sq_board_milliseconds();
        }
        vTaskDelayUntil(&last, pdMS_TO_TICKS(10));
    }
}
int main(void)
{
    sq_board_init();
    sq_init(&mission, SQ_COMMAND_KEY, sq_board_persist, NULL);
    (void)sq_board_load(&mission);
    sq_payload_init(&payload);
    SqBootState boot;
    bool boot_ok            = sq_board_boot_load(&boot);
    uint32_t vtor           = *(volatile uint32_t *)0xE000ED08UL;
    unsigned active         = vtor < 0x08070000UL ? 0U : vtor < 0x080D0000UL ? 1U : 2U;
    unsigned confirmed      = 2;
    const uint32_t bases[2] = {0x08010000UL, 0x08070000UL};
    for (unsigned i = 0; i < 2U; i++) {
        const uint8_t *header = (const uint8_t *)bases[i];
        uint64_t version      = 0;
        for (unsigned b = 0; b < 8U; b++) {
            version |= (uint64_t)header[4U + b] << (8U * b);
        }
        if (boot.confirmed && !memcmp(header, "SQFW", 4) && version == boot.confirmed) {
            confirmed = i;
        }
    }
    sq_update_init(&updater,
                   &mission,
                   &boot,
                   SQ_UPDATE_KEY,
                   active,
                   confirmed,
                   sq_board_update_erase,
                   sq_board_update_write,
                   sq_board_update_read,
                   sq_board_update_boot_save,
                   NULL);
    if (boot_ok) {
        mission.extended_command = sq_update_command;
        mission.command_context  = &updater;
    }
    sq_watchdog_start();
    if (xTaskCreateStatic(supervisor, "mission", 4096, NULL, 3, supervisor_stack, &supervisor_tcb)
        == NULL) {
        sq_panic();
    }
    vTaskStartScheduler();
    sq_panic();
    return 0;
}
