# STM32L476RG reference firmware

Development reference, not flight-qualified. The target produces genuine ARM ELF, binary and map artifacts. FreeRTOS V11.1.0 and Monocypher 4.0.3 are pinned; the RTOS uses static allocation only.

## Build

Put GNU Arm Embedded GCC 14.2.1 on PATH, then:

```
cmake -S software/flight -B build/arm-reference \
  -DCMAKE_TOOLCHAIN_FILE=cmake/arm-none-eabi.cmake \
  -DSQ_TARGET=stm32l476-reference -DFLIGHT_BUILD=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build/arm-reference
```

No host compiler or simulation HAL is accepted. Application vectors start at 0x08010800; slot A occupies 384KB including a 2KB signed manifest. Boot starts at 0x08000000. Memory: boot 64KB; application A/B each 384KB; recovery 128KB; state 64KB; total 1MB. SRAM1 is 96KB, with an 8KB minimum startup/exception-stack reserve. The reference does not silently select a 512KB MCU.

## Board wiring and behavior

NUCLEO-L476RG: USART2 PA2/PA3 AF7 for development commands/TNC and USART1 PA9/PA10 AF7 for payload, 3.3V UART (BRR694 at 80MHz, approximately 115273 baud); PA6 transmit-permit output, PA7 payload-permit output, PA5 available LED. Outputs reset OFF. Do not connect an actual PA, deployment actuator or payload until the interface/hazard review is complete. The ingress uses bounded KISS frames containing AX.25 UI/F0 frames carrying protocol information bytes; the development UART is not an RF modem.

The reference configures 80MHz from MSI4MHz/M1/N40/R2, VOS range1 and four flash wait states. Circular DMA receives USART2 into an 8192-byte ring (DMA1 channel6 request2) and USART1 into a 512-byte ring (channel5 request2); detected overrun/error discards ambiguous input. TIM2 runs independently at 2kHz and provides monotonic milliseconds, including flash stalls. DMA is disabled before boot handoff.

The application restores the two-bank flash journal, processes signed commands, runs the bounded mission transaction in a statically allocated RTOS supervisor and uses four completion votes and a provisional 500ms transaction deadline, feeding the independent watchdog only after a healthy transaction. Deadline failures count, force SAFE and remove output permits. No verified EPS board exists: reported availability remains zero and SAFE/RF OFF is enforced. There is no simulated healthy EPS embedded in firmware. EPS/ADCS/RF/deployment/RTC drivers require selected hardware and HIL verification.

Use `-DSQ_COMMAND_PUBLIC_KEY=<64 hex characters>` and separately `-DSQ_UPDATE_PUBLIC_KEY=<64 hex characters>` after reviewed provisioning. Empty keys disable command/update acceptance. A signed image is constructed with `tools/build_update.py`. Slot manifests authenticate version, image length and BLAKE2b-256 content. The reference loader chooses separately linked A/B or recovery images. Persisted trial selection rolls back after three unsuccessful boots and retains the accepted-version high-water mark. The application confirms after a stable 60-second supervisor interval. The production bounded streaming writer and authenticated page-checkpoint resume are implemented; see `docs/resurrection/FIRMWARE_UPDATES.md` and `PAYLOAD_INTEGRATION.md`. Selected EPS, option-byte protection, interrupted-write HIL and physical execution remain launch-blocking. The loader/writer are development references.

## Persistent storage limitations

The SQJ2 journal writes the inactive bank and validates data CRC and a separate header CRC protecting the generation before switching. Earlier SQJ1 board journals are not automatically migrated; no board was programmed in this work. Mission snapshots migrate v1/v2 to v3, which retains the retirement latch. Invalid state fails closed. Flash endurance, power-cut behavior, ECC, RTC continuity through outage, radiation and key custody require measured evidence; an external FRAM design may replace the development flash journal. Queue TTL pauses through unmeasured powered-off intervals; a selected RTC/mission-time source must close that gap for flight.

## Acceptance gate

No board has been programmed or run in this repository task. Verify 80MHz clocks, TIM2 continuity during flash stalls, DMA wrap/overflow and boot handoff, UART baud, brownout, memory bounds, interrupts, watchdog, GPIO safe states, journal power interruption, public-key provisioning and option-byte write protection on an actual board before claiming hardware-tested status.

Primary reference: [ST datasheet](https://www.st.com/resource/en/datasheet/DM00108832.pdf), [RM0351](https://www.st.com/resource/en/reference_manual/rm0351-stm32l47xxx-stm32l48xxx-stm32l49xxx-and-stm32l4axxx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf), and [ST 80MHz DMA UART example](https://github.com/STMicroelectronics/STM32CubeL4/blob/master/Projects/NUCLEO-L476RG/Examples/UART/UART_TwoBoards_ComDMA/Src/main.c). These support register/pin choices, not execution evidence.
