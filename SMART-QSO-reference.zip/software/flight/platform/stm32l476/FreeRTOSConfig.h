#ifndef SQ_FREERTOS_CONFIG_H
#define SQ_FREERTOS_CONFIG_H
#include <stdint.h>
extern void sq_panic(void);
#define configUSE_PREEMPTION                    1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 0
#define configCPU_CLOCK_HZ                      80000000UL
#define configTICK_RATE_HZ                      1000U
#define configMAX_PRIORITIES                    5U
#define configMINIMAL_STACK_SIZE                192U
#define configMAX_TASK_NAME_LEN                 16U
#define configUSE_16_BIT_TICKS                  0
#define configIDLE_SHOULD_YIELD                 1
#define configUSE_MUTEXES                       0
#define configUSE_TIMERS                        0
#define configSUPPORT_STATIC_ALLOCATION         1
#define configSUPPORT_DYNAMIC_ALLOCATION        0
#define configUSE_MALLOC_FAILED_HOOK            0
#define configCHECK_FOR_STACK_OVERFLOW          2
#define configUSE_IDLE_HOOK                     0
#define configUSE_TICK_HOOK                     0
#define configPRIO_BITS                         4
#define configKERNEL_INTERRUPT_PRIORITY         (15U << 4U)
#define configMAX_SYSCALL_INTERRUPT_PRIORITY    (5U << 4U)
#define INCLUDE_vTaskDelay                      1
#define INCLUDE_vTaskDelayUntil                 1
#define INCLUDE_vTaskSuspend                    0
#define configASSERT(condition) \
    do {                        \
        if (!(condition)) {     \
            sq_panic();         \
        }                       \
    } while (0)
#endif
