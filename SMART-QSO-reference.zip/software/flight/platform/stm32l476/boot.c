/* Signed application/recovery selection with persisted trial attempts and rollback. */
#include "board.h"
#include "keys.h"
static void progress(void *context)
{
    (void)context;
    sq_watchdog_feed();
}
int main(void)
{
    sq_board_init();
    sq_outputs(false, false);
    sq_watchdog_start();
    const uint32_t addresses[3] = {0x08010000UL, 0x08070000UL, 0x080D0000UL};
    const size_t sizes[3]       = {384U * 1024U, 384U * 1024U, 128U * 1024U};
    bool valid[3];
    uint64_t versions[3] = {0};
    for (unsigned i = 0; i < 3U; i++) {
        valid[i] = sq_image_validate_progress((const uint8_t *)addresses[i],
                                              sizes[i],
                                              SQ_UPDATE_KEY,
                                              &versions[i],
                                              progress,
                                              NULL);
        if (valid[i]) {
            const uint8_t *manifest = (const uint8_t *)addresses[i];
            uint32_t length         = 0;
            for (unsigned b = 0; b < 4U; b++)
                length |= (uint32_t)manifest[12U + b] << (8U * b);
            valid[i] = sq_image_vectors(manifest + 2048, addresses[i], length);
        }
    }
    SqBootState state;
    bool healthy = sq_board_boot_load(&state);
    int selected = healthy ? sq_boot_select(&state, valid, versions) : (valid[2] ? 2 : -1);
    if (selected >= 0) {
        if (selected < 2 && !sq_board_boot_save(&state)) {
            selected = valid[2] ? 2 : -1;
        }
        if (selected >= 0) {
            sq_jump(addresses[selected] + 2048UL);
        }
    }
    sq_panic();
    return 0;
}
