/* Historical host/test support only. Not linked into current ARM firmware.
 * Legacy NASA/classification/heritage claims below are unverified; no compliance
 * or flight qualification is established. Current authority: mission/current/. */
#ifndef SQ_CRC32_H
#define SQ_CRC32_H
#include "smart_qso.h"
#endif
