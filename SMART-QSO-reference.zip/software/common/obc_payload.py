"""Host harness for the actual MCU payload supervisor (not a second acceptance implementation)."""

import ctypes

from .core import MissionCore


class ObcPayload:
    def __init__(self, core: MissionCore):
        self.core, self.lib = core, core.lib
        self.lib.sq_payload_size.restype = ctypes.c_size_t
        self.memory = ctypes.create_string_buffer(self.lib.sq_payload_size())
        self.pointer = ctypes.cast(self.memory, ctypes.c_void_p)
        self.lib.sq_payload_init.argtypes = [ctypes.c_void_p]
        self.lib.sq_payload_poll.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_size_t,
        ]
        self.lib.sq_payload_poll.restype = ctypes.c_size_t
        self.lib.sq_payload_receive.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_size_t,
        ]
        self.lib.sq_payload_receive.restype = ctypes.c_int
        self.lib.sq_payload_description.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.lib.sq_payload_description.restype = ctypes.c_char_p
        for name in ("sq_payload_power", "sq_payload_accepted", "sq_payload_pending"):
            getattr(self.lib, name).argtypes = [ctypes.c_void_p]
            getattr(self.lib, name).restype = ctypes.c_bool
        self.lib.sq_payload_sync_power.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.lib.sq_payload_init(self.pointer)

    def poll(self) -> bytes:
        out = ctypes.create_string_buffer(240)
        n = self.lib.sq_payload_poll(self.pointer, self.core.pointer, out, len(out))
        self.lib.sq_payload_sync_power(self.pointer, self.core.pointer)
        return out.raw[:n]

    def receive(self, response: bytes) -> int:
        return self.lib.sq_payload_receive(self.pointer, self.core.pointer, response, len(response))

    def status(self) -> dict:
        text = self.lib.sq_payload_description(self.pointer, self.core.pointer).decode("ascii")
        return {
            "powered": bool(self.lib.sq_payload_power(self.pointer)),
            "accepted": bool(self.lib.sq_payload_accepted(self.pointer)),
            "pending": bool(self.lib.sq_payload_pending(self.pointer)),
            "text": text,
        }
