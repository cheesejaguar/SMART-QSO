"""Host adapter for the bounded production B-dot component; no hardware actuation."""

import ctypes
from collections.abc import Sequence

from .core import MissionCore


class Calibration(ctypes.Structure):
    _fields_ = [
        ("bias", ctypes.c_int32 * 3),
        ("scale", ctypes.c_int32 * 3),
        ("reviewed", ctypes.c_bool),
    ]


class Controller(ctypes.Structure):
    _fields_ = [
        ("previous", ctypes.c_int32 * 3),
        ("observed", ctypes.c_uint64),
        ("gain", ctypes.c_uint32),
        ("limit", ctypes.c_uint32),
        ("history", ctypes.c_bool),
    ]


def vector(values: Sequence[int]) -> ctypes.Array:
    if len(values) != 3 or any(type(v) is not int or not -(2**31) <= v < 2**31 for v in values):
        raise ValueError("Expected three signed 32-bit integers")
    return (ctypes.c_int32 * 3)(*values)


class Bdot:
    def __init__(self, core: MissionCore, gain: int, limit: int):
        if (
            type(gain) is not int
            or type(limit) is not int
            or not 1 <= gain <= 1000
            or not 1 <= limit <= 200000
        ):
            raise ValueError("B-dot gain/total moment limit outside controlled bounds")
        self.lib, self.controller = core.lib, Controller()
        self.lib.sq_bdot_init.argtypes = [
            ctypes.POINTER(Controller),
            ctypes.c_uint32,
            ctypes.c_uint32,
        ]
        self.lib.sq_bdot_step.argtypes = [
            ctypes.POINTER(Controller),
            ctypes.POINTER(Calibration),
            ctypes.c_void_p,
            ctypes.c_uint64,
            ctypes.c_bool,
            ctypes.c_bool,
            ctypes.c_void_p,
        ]
        self.lib.sq_bdot_step.restype = ctypes.c_bool
        self.lib.sq_bdot_init(ctypes.byref(self.controller), gain, limit)

    def step(
        self,
        raw: Sequence[int],
        now_ms: int,
        *,
        bias: Sequence[int] = (0, 0, 0),
        scale: Sequence[int] = (1000000, 1000000, 1000000),
        reviewed: bool = False,
        sensor_valid: bool = False,
        permitted: bool = False,
    ) -> dict:
        if type(now_ms) is not int or not 0 <= now_ms < 2**64:
            raise ValueError("Invalid monotonic milliseconds")
        if any(type(flag) is not bool for flag in (reviewed, sensor_valid, permitted)):
            raise ValueError("ADCS permission and validity flags must be booleans")
        calibration = Calibration(vector(bias), vector(scale), reviewed)
        output = (ctypes.c_int32 * 3)()
        active = self.lib.sq_bdot_step(
            ctypes.byref(self.controller),
            ctypes.byref(calibration),
            vector(raw),
            now_ms,
            sensor_valid,
            permitted,
            output,
        )
        return {
            "active": bool(active),
            "moment_uam2": list(output),
            "history": bool(self.controller.history),
            "provenance": "host algorithm; no actuators",
        }
