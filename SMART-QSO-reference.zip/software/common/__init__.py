"""Shared versioned SMART-QSO interfaces."""
