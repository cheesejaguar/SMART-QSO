"""Authenticated update transport and persistent file-backed flash fault harness.

The C updater owns acceptance and boot policy. Files emulate flash and are never an RF adapter.
"""

from __future__ import annotations

import ctypes
import hashlib
import os
import struct
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .core import MissionCore
from .protocol_generated import COMMANDS

SLOT_BYTES = 384 * 1024


def inspect_image(image: bytes, public_key: bytes) -> dict:
    if len(public_key) != 32 or not 2056 <= len(image) <= SLOT_BYTES or image[:4] != b"SQFW":
        raise ValueError("Invalid signed image/key size")
    version, length = struct.unpack_from("<QI", image, 4)
    if version == 0 or len(image) != 2048 + length or image[112:2048] != b"\xff" * 1936:
        raise ValueError("Invalid canonical image manifest/length")
    try:
        Ed25519PublicKey.from_public_bytes(public_key).verify(image[48:112], image[:48])
    except Exception as exc:
        raise ValueError("Firmware manifest signature failed") from exc
    if hashlib.blake2b(image[2048:], digest_size=32).digest() != image[16:48]:
        raise ValueError("Firmware content hash failed")
    stack, reset = struct.unpack_from("<II", image, 2048)
    if not 0x20000000 < stack <= 0x20018000 or stack % 8 or not reset & 1:
        raise ValueError("Invalid application vectors")
    targets = [
        slot
        for slot, base in enumerate((0x08010000, 0x08070000))
        if base + 2048 <= (reset & ~1) < base + 2048 + length
    ]
    if len(targets) != 1:
        raise ValueError("Image must be linked for one application slot, never boot/recovery")
    return {
        "version": str(version),
        "length": length,
        "target_slot": targets[0],
        "sha256": hashlib.sha256(image).hexdigest(),
    }


def transactions(
    image: bytes, target: int, offset: int = 0, resume: bool = False
) -> list[tuple[int, bytes]]:
    if target not in (0, 1) or len(image) < 2056:
        raise ValueError("Invalid target/image")
    if offset < 0 or offset > len(image) - 2048 or (offset % 2048 and offset != len(image) - 2048):
        raise ValueError("Resume offset must be a durable page boundary")
    if offset and not resume:
        raise ValueError("Only resume may start at a nonzero offset")
    operations = [
        (COMMANDS["UPDATE_RESUME" if resume else "UPDATE_BEGIN"], bytes([target]) + image[:112])
    ]
    body = image[2048:]
    operations.extend(
        (COMMANDS["UPDATE_CHUNK"], struct.pack("<I", offset) + body[offset : offset + 128])
        for offset in range(offset, len(body), 128)
    )
    return operations + [(COMMANDS["UPDATE_COMMIT"], b"")]


class BootState(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_uint64) for name in ("accepted", "confirmed", "trial", "failed")
    ] + [("attempts", ctypes.c_uint32), ("generation", ctypes.c_uint32)]


class FlashStore:
    def __init__(self, directory: Path):
        self.directory = directory
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if directory.is_symlink():
            raise ValueError("Flash harness directory must not be a symlink")
        self.fail_after: int | None = None
        self.corrupt_read = False
        self.mutations = 0
        for slot in (0, 1):
            path = directory / f"slot-{slot}.bin"
            if path.is_symlink():
                raise ValueError("Flash file must not be a symlink")
            if not path.exists():
                with path.open("xb") as f:
                    f.write(b"\xff" * SLOT_BYTES)
                    f.flush()
                    os.fsync(f.fileno())
            if path.stat().st_size != SLOT_BYTES:
                raise ValueError("Flash harness slot size mismatch")

    def mutate(self):
        if self.fail_after is not None and self.mutations >= self.fail_after:
            raise OSError("Injected power cut/write failure")
        self.mutations += 1

    def read(self, slot: int, offset: int, length: int) -> bytes:
        if slot not in (0, 1) or offset < 0 or length < 0 or offset + length > SLOT_BYTES:
            raise ValueError("Out-of-slot flash access")
        with (self.directory / f"slot-{slot}.bin").open("rb") as f:
            f.seek(offset)
            value = f.read(length)
        if len(value) != length:
            raise OSError("Short flash read; slot storage is incomplete")
        return bytes([value[0] ^ 1]) + value[1:] if self.corrupt_read and value else value

    def write(self, slot: int, offset: int, value: bytes, erase: bool = False):
        if erase:
            if offset % 2048 or len(value) != 2048:
                raise ValueError("Invalid flash erase geometry")
        elif offset % 8 or len(value) % 8:
            raise ValueError("Invalid doubleword write geometry")
        previous = self.read(slot, offset, len(value))
        if not erase and any((a & b) != b for a, b in zip(previous, value, strict=True)):
            raise ValueError("Programming requires erase")
        self.mutate()
        with (self.directory / f"slot-{slot}.bin").open("r+b") as f:
            f.seek(offset)
            f.write(value)
            f.flush()
            os.fsync(f.fileno())

    def save_boot(self, data: bytes):
        self.mutate()
        temp = self.directory / "boot.pending"
        with temp.open("wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, self.directory / "boot.bin")
        fd = os.open(self.directory, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


class FirmwareUpdater:
    def __init__(
        self,
        core: MissionCore,
        flash: FlashStore,
        key: bytes,
        active_slot: int = 0,
        confirmed_slot: int = 2,
    ):
        if len(key) != 32 or active_slot not in (0, 1, 2) or confirmed_slot not in (0, 1, 2):
            raise ValueError("Invalid updater provisioning")
        self.core, self.flash, self.lib = core, flash, core.lib
        self.key = key
        lib = self.lib
        lib.sq_updater_size.restype = ctypes.c_size_t
        self.memory = ctypes.create_string_buffer(lib.sq_updater_size())
        self.pointer = ctypes.cast(self.memory, ctypes.c_void_p)
        boot = BootState()
        lib.sq_boot_decode.argtypes = [ctypes.POINTER(BootState), ctypes.c_void_p]
        lib.sq_boot_decode.restype = ctypes.c_bool
        lib.sq_boot_encode.argtypes = [ctypes.POINTER(BootState), ctypes.c_void_p]
        boot_path = flash.directory / "boot.bin"
        if boot_path.exists():
            saved = boot_path.read_bytes()
            if len(saved) != 64 or not lib.sq_boot_decode(ctypes.byref(boot), saved):
                raise ValueError("Corrupt boot state; update acceptance disabled")
        erase_type = ctypes.CFUNCTYPE(
            ctypes.c_bool, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint32
        )
        io_type = ctypes.CFUNCTYPE(
            ctypes.c_bool,
            ctypes.c_void_p,
            ctypes.c_uint,
            ctypes.c_uint32,
            ctypes.c_void_p,
            ctypes.c_size_t,
        )
        boot_type = ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.POINTER(BootState))

        def erase(_, slot, offset):
            try:
                flash.write(slot, offset, b"\xff" * 2048, erase=True)
                return True
            except (OSError, ValueError):
                return False

        def write(_, slot, offset, data, n):
            try:
                flash.write(slot, offset, ctypes.string_at(data, n))
                return True
            except (OSError, ValueError):
                return False

        def read(_, slot, offset, out, n):
            try:
                value = flash.read(slot, offset, n)
                if len(value) != n:
                    raise OSError("Short backend read")
                ctypes.memmove(out, value, n)
                return True
            except (OSError, ValueError):
                return False

        def save(_, state):
            try:
                if state.contents.generation == 2**32 - 1:
                    return False
                state.contents.generation += 1
                data = ctypes.create_string_buffer(64)
                lib.sq_boot_encode(state, data)
                flash.save_boot(data.raw)
                return True
            except (OSError, ValueError):
                return False

        self.callbacks = (erase_type(erase), io_type(write), io_type(read), boot_type(save))
        lib.sq_update_init.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.POINTER(BootState),
            ctypes.c_void_p,
            ctypes.c_uint,
            ctypes.c_uint,
            erase_type,
            io_type,
            io_type,
            boot_type,
            ctypes.c_void_p,
        ]
        lib.sq_update_init(
            self.pointer,
            core.pointer,
            ctypes.byref(boot),
            key,
            active_slot,
            confirmed_slot,
            *self.callbacks,
            None,
        )
        lib.sq_attach_updater.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        lib.sq_attach_updater(core.pointer, self.pointer)
        lib.sq_update_poll.argtypes = [ctypes.c_void_p]
        for name, result in [
            ("sq_update_active", ctypes.c_bool),
            ("sq_update_complete", ctypes.c_bool),
            ("sq_update_faulted", ctypes.c_bool),
            ("sq_update_recovering", ctypes.c_bool),
            ("sq_update_length", ctypes.c_uint32),
            ("sq_update_written", ctypes.c_uint32),
        ]:
            getattr(lib, name).argtypes = [ctypes.c_void_p]
            getattr(lib, name).restype = result
        lib.sq_update_boot_state.argtypes = [ctypes.c_void_p, ctypes.c_void_p]

    def status(self) -> dict:
        self.lib.sq_update_poll(self.pointer)
        encoded = ctypes.create_string_buffer(64)
        self.lib.sq_update_boot_state(self.pointer, encoded)
        accepted, confirmed, trial, failed = struct.unpack_from("<QQQQ", encoded.raw, 16)
        return {
            "active": bool(self.lib.sq_update_active(self.pointer)),
            "complete": bool(self.lib.sq_update_complete(self.pointer)),
            "faulted": bool(self.lib.sq_update_faulted(self.pointer)),
            "recovering": bool(self.lib.sq_update_recovering(self.pointer)),
            "length": self.lib.sq_update_length(self.pointer),
            "written": self.lib.sq_update_written(self.pointer),
            "accepted_version": str(accepted),
            "confirmed_version": str(confirmed),
            "trial_version": str(trial),
            "failed_version": str(failed),
            "provenance": "file-backed simulation",
            "hardware_written": False,
        }

    def boot_cycle(self, confirm: bool = False) -> dict:
        """Exercise real C boot policy against persisted slots; no instruction execution."""
        lib = self.lib
        boot = BootState()
        saved = self.flash.directory / "boot.bin"
        if saved.exists():
            data = saved.read_bytes()
            if len(data) != 64 or not lib.sq_boot_decode(ctypes.byref(boot), data):
                raise ValueError("Corrupt boot state")
        lib.sq_image_validate.argtypes = [
            ctypes.c_void_p,
            ctypes.c_size_t,
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_uint64),
        ]
        lib.sq_image_validate.restype = ctypes.c_bool
        valid, versions = (ctypes.c_bool * 3)(), (ctypes.c_uint64 * 3)()
        for slot in (0, 1):
            image = self.flash.read(slot, 0, SLOT_BYTES)
            v = ctypes.c_uint64()
            try:
                length = struct.unpack_from("<I", image, 12)[0]
                info = inspect_image(image[: 2048 + length], self.key)
                valid[slot] = info["target_slot"] == slot and lib.sq_image_validate(
                    image, len(image), self.key, ctypes.byref(v)
                )
            except ValueError:
                valid[slot] = False
            versions[slot] = v.value
        lib.sq_boot_select.argtypes = [ctypes.POINTER(BootState), ctypes.c_void_p, ctypes.c_void_p]
        lib.sq_boot_select.restype = ctypes.c_int
        selected = lib.sq_boot_select(ctypes.byref(boot), valid, versions)
        if confirm and selected >= 0:
            lib.sq_boot_confirm.argtypes = [ctypes.POINTER(BootState), ctypes.c_uint64]
            lib.sq_boot_confirm.restype = ctypes.c_bool
            if not lib.sq_boot_confirm(ctypes.byref(boot), versions[selected]):
                raise ValueError("No matching trial to confirm")
        if boot.generation == 2**32 - 1:
            raise ValueError("Boot generation exhausted")
        boot.generation += 1
        encoded = ctypes.create_string_buffer(64)
        lib.sq_boot_encode(ctypes.byref(boot), encoded)
        self.flash.save_boot(encoded.raw)
        confirmed_slot = next((i for i in (0, 1) if valid[i] and versions[i] == boot.confirmed), 2)
        FirmwareUpdater.__init__(
            self, self.core, self.flash, self.key, selected if selected >= 0 else 2, confirmed_slot
        )
        return {
            "selected_slot": selected,
            "confirmed": confirm,
            **self.status(),
            "instruction_execution": False,
            "recovery_image": "Not provisioned in host harness",
        }
