"""ctypes adapter to the same C core linked into reference firmware."""

from __future__ import annotations

import ctypes
import json
import os
import struct
from collections.abc import Callable
from pathlib import Path

from .protocol import callsign

ROOT = Path(__file__).resolve().parents[2]


class MissionCore:
    def __init__(
        self, public_key: bytes, persist: Callable[[bytes], bool], saved: bytes | None = None
    ):
        if len(public_key) != 32:
            raise ValueError("Public key must be exactly 32 bytes")
        path = Path(os.environ.get("SQ_CORE_LIBRARY", ROOT / "build/libsq_mission.dylib"))
        if not path.exists():
            path = ROOT / "build/libsq_mission.so"
        if not path.exists():
            raise RuntimeError(
                "Build the C core first: cmake -S software/flight -B build && cmake --build build"
            )
        self.lib = ctypes.CDLL(str(path))
        self.lib.sq_mission_size.restype = ctypes.c_size_t
        self.memory = ctypes.create_string_buffer(self.lib.sq_mission_size())
        self.pointer = ctypes.cast(self.memory, ctypes.c_void_p)
        persist_type = ctypes.CFUNCTYPE(
            ctypes.c_bool, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p
        )

        def save(ptr, size, _):
            try:
                return persist(ctypes.string_at(ptr, size))
            except Exception:
                return False

        self.callback = persist_type(save)
        self.lib.sq_init.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            persist_type,
            ctypes.c_void_p,
        ]
        self.lib.sq_init(self.pointer, ctypes.create_string_buffer(public_key), self.callback, None)
        for name in ["sq_load", "sq_receive"]:
            getattr(self.lib, name).argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
            getattr(self.lib, name).restype = ctypes.c_int
        self.lib.sq_tick.argtypes = [
            ctypes.c_void_p,
            ctypes.c_uint64,
            ctypes.c_uint16,
            ctypes.c_int16,
        ]
        self.lib.sq_separation.argtypes = [ctypes.c_void_p]
        self.lib.sq_snapshot.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
        self.lib.sq_snapshot.restype = ctypes.c_size_t
        self.lib.sq_status_json.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
        self.lib.sq_status_json.restype = ctypes.c_size_t
        self.lib.sq_next.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        self.lib.sq_next.restype = ctypes.c_int
        if saved is not None and self.lib.sq_load(self.pointer, saved, len(saved)) != 0:
            raise RuntimeError(
                "Corrupt persistent mission state: RF remains inhibited; recover under review"
            )

    def health_frame(self, transaction: int) -> bytes:
        if not 0 <= transaction < 2**64:
            raise ValueError("Invalid transaction sequence")
        self.lib.sq_health_frame.argtypes = [
            ctypes.c_void_p,
            ctypes.c_uint64,
            ctypes.c_void_p,
            ctypes.c_size_t,
        ]
        self.lib.sq_health_frame.restype = ctypes.c_size_t
        out = ctypes.create_string_buffer(240)
        length = self.lib.sq_health_frame(self.pointer, transaction, out, len(out))
        return out.raw[:length]

    def receive(self, frame: bytes) -> int:
        return self.lib.sq_receive(self.pointer, frame, len(frame))

    def tick(self, seconds: int, soc: int = 760, temp: int = 2200):
        if not 0 <= seconds < 2**64 or not 0 <= soc <= 1000 or not -5000 <= temp <= 10000:
            raise ValueError("Telemetry out of range")
        self.lib.sq_tick(self.pointer, seconds, soc, temp)

    def separation(self):
        self.lib.sq_separation(self.pointer)

    def status(self) -> dict:
        buf = ctypes.create_string_buffer(1024)
        if not self.lib.sq_status_json(self.pointer, buf, len(buf)):
            raise RuntimeError("Status overflow")
        return json.loads(buf.value)

    def snapshot(self) -> bytes:
        buf = ctypes.create_string_buffer(5952)
        size = self.lib.sq_snapshot(self.pointer, buf, len(buf))
        return buf.raw[:size]

    def messages(self) -> list[dict]:
        image = self.snapshot()
        records = []
        for i in range(32):
            q = image[64 + i * 184 : 64 + (i + 1) * 184]
            mid, expiry, retry = struct.unpack_from("<QQQ", q)
            if q[46]:
                records.append(
                    {
                        "id": str(mid),
                        "sender": q[24:34].split(b"\0")[0].decode(),
                        "destination": q[34:44].split(b"\0")[0].decode(),
                        "text": q[47 : 47 + q[44]].decode(),
                        "attempts": q[45],
                        "state": ["empty", "queued", "acknowledged", "exhausted"][q[46]],
                        "expires_s": expiry,
                        "retry_s": retry,
                    }
                )
        return records

    def next(self, recipient: str | None = None) -> tuple[int, dict | None]:
        # Struct ABI stays within C. Buffer exceeds sizeof(SqMessage); read canonical snapshot afterward.
        buf = ctypes.create_string_buffer(256)
        if recipient is not None:
            self.lib.sq_next_for.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p]
            self.lib.sq_next_for.restype = ctypes.c_int
            result = self.lib.sq_next_for(self.pointer, callsign(recipient).encode(), buf)
        else:
            result = self.lib.sq_next(self.pointer, buf)
        if result:
            return result, None
        mid = struct.unpack_from("<Q", buf.raw)[0]
        sender = buf.raw[24:34].split(b"\0")[0].decode()
        return result, next(
            m for m in self.messages() if m["id"] == str(mid) and m["sender"] == sender
        )
