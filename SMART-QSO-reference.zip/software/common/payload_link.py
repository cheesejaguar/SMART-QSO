"""Exact OBC/payload wire adapter; the MCU independently validates every response."""

import struct

from .protocol import KINDS, frame, unpack
from .protocol_generated import SPEC

RESPONSE = struct.Struct(SPEC["payload_link"]["response_prefix"])


def payload_result(sequence: int, observed_s: int, text: str) -> bytes:
    encoded = text.encode("ascii")
    if not 1 <= len(encoded) <= 120 or any(c < 32 or c > 126 for c in encoded):
        raise ValueError("Payload description must be bounded printable ASCII")
    if not 0 <= observed_s < 2**64:
        raise ValueError("Invalid snapshot time")
    return frame(
        KINDS["PAYLOAD_RESULT"], sequence, RESPONSE.pack(observed_s, len(encoded)) + encoded
    )


def decode_payload_result(data: bytes) -> tuple[int, int, str]:
    kind, sequence, payload, _ = unpack(data)
    if kind != KINDS["PAYLOAD_RESULT"] or len(payload) < RESPONSE.size:
        raise ValueError("Not a payload result")
    observed, length = RESPONSE.unpack_from(payload)
    if len(payload) != RESPONSE.size + length:
        raise ValueError("Payload response length mismatch")
    text = payload[RESPONSE.size :].decode("ascii")
    payload_result(sequence, observed, text)
    return sequence, observed, text
