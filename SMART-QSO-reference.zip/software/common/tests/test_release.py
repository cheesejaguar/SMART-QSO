"""Publishing must reject stale source, altered artifacts and unsupported acceptance."""

import hashlib
import json
import zipfile

import pytest

from tools.check_release import check


def fixture(tmp_path, monkeypatch):
    source = tmp_path / "source.py"
    source.write_text('print("development only")\n')
    release = tmp_path / "output/release"
    release.mkdir(parents=True)
    sources = [{"path": "source.py", "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}]
    manifest = {"source_tree_included": True, "flight_accepted": False,
                "hardware_execution_verified": False, "misra_compliance_verified": False,
                "source_files": sources, "artifacts": [],
                "source_tree_sha256": hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest()}
    (release / "manifest.json").write_text(json.dumps(manifest))
    with zipfile.ZipFile(release / "SMART-QSO-reference.zip", "w") as archive:
        archive.write(source, "source.py")
        archive.write(release / "manifest.json", "output/release/manifest.json")
    (release / "checksums.sha256").write_text(''.join(
        f'{hashlib.sha256((release / name).read_bytes()).hexdigest()}  {name}\n'
        for name in ("manifest.json", "SMART-QSO-reference.zip")))
    monkeypatch.setattr("tools.check_release.subprocess.check_output", lambda *a, **k: "source.py\n")
    return release, manifest


def test_release_round_trip_and_source_tamper(tmp_path, monkeypatch):
    fixture(tmp_path, monkeypatch)
    assert check(tmp_path)["integrity_verified"]
    (tmp_path / "source.py").write_text("changed after verification")
    with pytest.raises(ValueError, match="Stale"):
        check(tmp_path)


def test_release_missing_current_source_fails(tmp_path, monkeypatch):
    fixture(tmp_path, monkeypatch)
    (tmp_path / "new.py").write_text("new source")
    monkeypatch.setattr("tools.check_release.subprocess.check_output",
                        lambda *a, **k: "source.py\nnew.py\n")
    with pytest.raises(ValueError, match="inventory"):
        check(tmp_path)


def test_release_cannot_award_flight_acceptance(tmp_path, monkeypatch):
    release, manifest = fixture(tmp_path, monkeypatch)
    manifest["flight_accepted"] = True
    (release / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="acceptance"):
        check(tmp_path)


def test_release_cannot_include_operational_key(tmp_path, monkeypatch):
    release, _ = fixture(tmp_path, monkeypatch)
    with zipfile.ZipFile(release / "SMART-QSO-reference.zip", "a") as archive:
        archive.writestr(".state/command.pem", "test-only unsafe path")
    with pytest.raises(ValueError, match="Unsafe"):
        check(tmp_path)
