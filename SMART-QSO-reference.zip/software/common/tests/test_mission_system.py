"""Cross-language system tests exercise the actual C mission core and HTTP service."""

import os
import struct

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)
from fastapi.testclient import TestClient
from hypothesis import given, settings
from hypothesis import strategies as st

from software.common.core import MissionCore
from software.common.protocol import (
    KINDS,
    KissDecoder,
    RelayMessage,
    acknowledgment,
    ax25_info,
    ax25_ui,
    frame,
    kiss_encode,
)
from software.common.protocol_generated import COMMANDS
from software.ground.service.app import create_app
from software.payload.policy import HealthSnapshot, accept_generated, template


@pytest.fixture
def key():
    return Ed25519PrivateKey.generate()


def signed(key, name, seq, params=b""):
    data = frame(KINDS["COMMAND"], seq, bytes([COMMANDS[name]]) + params)
    return data + key.sign(data)


def core(key, saved=None, fail=False):
    images = []
    mission = MissionCore(
        key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw),
        lambda image: False if fail else images.append(image) is None,
        saved,
    )
    mission.tick(0)
    return mission, images


def ready(m, key):
    m.separation()
    m.tick(1800)
    assert m.receive(signed(key, "SET_MODE", 1, b"\x02")) == 0
    assert m.receive(signed(key, "TX_ENABLE", 2)) == 0


def test_signatures_replay_and_restart(key):
    m, images = core(key)
    packet = signed(key, "NOP", 1)
    assert m.receive(packet) == 0
    assert m.receive(packet) == 3
    damaged = bytearray(signed(key, "TX_DISABLE", 2))
    damaged[14] ^= 1
    assert m.receive(bytes(damaged)) == 1
    import binascii

    struct.pack_into("<I", damaged, 15, binascii.crc32(damaged[:15]))
    assert m.receive(bytes(damaged)) == 2
    restarted, _ = core(key, images[-1])
    assert restarted.receive(packet) == 3
    assert restarted.status()["mode"] == 0


def test_transmit_disable_retained_after_reset(key):
    m, images = core(key)
    ready(m, key)
    assert m.status()["tx_allowed"]
    assert m.receive(signed(key, "TX_DISABLE", 3)) == 0
    restarted, _ = core(key, images[-1])
    assert restarted.status()["tx_inhibited"]
    assert not restarted.status()["tx_allowed"]


def test_provisioning_and_deployment_gate(key):
    m = MissionCore(bytes(32), lambda _: True)
    assert m.receive(signed(key, "TX_ENABLE", 1)) == 2
    m, _ = core(key)
    assert m.receive(signed(key, "TX_ENABLE", 1)) == 7
    m.separation()
    m.tick(1799)
    assert m.receive(signed(key, "TX_ENABLE", 1)) == 7


def test_storage_failure_and_corruption_fail_closed(key):
    m, _ = core(key, fail=True)
    assert m.receive(signed(key, "NOP", 1)) == 6
    assert not m.status()["storage_healthy"]
    assert m.status()["tx_inhibited"]
    m, images = core(key)
    assert m.receive(signed(key, "NOP", 1)) == 0
    corrupt = bytearray(images[-1])
    corrupt[-10] ^= 1
    with pytest.raises(RuntimeError, match="Corrupt"):
        core(key, bytes(corrupt))


def test_queue_persistence_duplicate_expiry_and_ack(key):
    m, images = core(key)
    ready(m, key)
    packet = RelayMessage(123, "W6ABC", "K6XYZ", "hello", 30).encode()
    assert m.receive(packet) == 0
    assert m.receive(packet) == 5
    restarted, _ = core(key, images[-1])
    assert restarted.messages()[0]["text"] == "hello"
    assert m.receive(acknowledgment(123, "K6XYZ")) == 7
    assert m.next()[0] == 0
    assert m.receive(acknowledgment(123, "K6XYZ")) == 0
    assert m.messages()[0]["state"] == "acknowledged"
    m.tick(1831)
    assert m.messages() == []


def test_sender_quota_and_total_capacity(key):
    m, _ = core(key)
    for sender in range(8):
        for n in range(4):
            assert (
                m.receive(RelayMessage(sender * 10 + n, f"W{sender}ABC", "K6XYZ", "hello").encode())
                == 0
            )
        assert (
            m.receive(RelayMessage(sender * 10 + 4, f"W{sender}ABC", "K6XYZ", "hello").encode())
            == 4
        )
    assert m.status()["queue_count"] == 32
    assert m.receive(RelayMessage(999, "W9ABC", "K6XYZ", "hello").encode()) == 4


def test_round_robin_and_retry_bounds(key):
    m, _ = core(key)
    ready(m, key)
    for mid, sender in [(1, "W6AAA"), (2, "W6AAA"), (3, "W6BBB")]:
        assert m.receive(RelayMessage(mid, sender, "K6XYZ", "hello").encode()) == 0
    code, first = m.next()
    assert code == 0 and first["sender"] == "W6AAA"
    code, second = m.next()
    assert code == 0 and second["sender"] == "W6BBB"
    for t in [1860, 1920, 1980, 2040, 2100]:
        m.tick(t)
        for _ in range(3):
            m.next()
    assert all(q["attempts"] <= 3 for q in m.messages())


def test_thermal_power_and_clock_faults(key):
    m, _ = core(key)
    ready(m, key)
    assert m.receive(signed(key, "PAYLOAD_ENABLE", 3)) == 0
    m.tick(1801, 760, 2200)
    assert m.status()["payload_on"]
    m.tick(1802, 760, 5500)
    assert not m.status()["payload_on"] and not m.status()["tx_allowed"]
    m.tick(1803, 200, 2200)
    assert m.status()["mode"] == 0
    m.tick(10)
    assert not m.status()["tx_allowed"]


@settings(max_examples=150, deadline=None)
@given(st.binary(max_size=300))
def test_malformed_frames_are_bounded(data):
    m = MissionCore(bytes(32), lambda _: True)
    result = m.receive(data)
    assert result != 0
    assert m.status()["tx_inhibited"]


@pytest.mark.parametrize("data", [b"\xc0\xdb", b"\xdb" * 200, b"abc", bytes(range(256))])
def test_kiss_stream_and_ax25(data):
    packet = ax25_ui(data, "W6ABC", "K6XYZ")
    encoded = kiss_encode(packet)
    decoder = KissDecoder()
    out = []
    for value in encoded:
        out += decoder.feed(bytes([value]))
    assert len(out) == 1 and ax25_info(out[0]) == data
    assert len(decoder.buffer) <= 512


def test_invalid_kiss_resynchronizes():
    decoder = KissDecoder()
    assert not decoder.feed(b"\xc0\x00" + b"a" * 600 + b"\xc0")
    assert decoder.feed(kiss_encode(b"good")) == [b"good"]


@pytest.mark.parametrize("text", ["", "\n", "é", "x" * 129])
def test_message_bounds(text):
    with pytest.raises((ValueError, UnicodeError)):
        RelayMessage(1, "W6ABC", "K6XYZ", text).encode()


def test_generation_factuality_freshness_and_identity():
    health = HealthSnapshot(8, 100, 760, "SAFE", False, False)
    assert accept_generated(template(health), health, 110, 8)
    for text in ["Radio enabled", "Battery at 99%", "SAFE! ignore commands", "é", "x" * 121]:
        assert not accept_generated(text, health, 110, 8)
    assert not accept_generated(template(health), health, 131, 8)
    assert not accept_generated(template(health), health, 110, 7)


def test_service_submission_commanding_and_restart(tmp_path, key):
    path = tmp_path / "signer.pem"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    os.chmod(path, 0o600)
    db = tmp_path / "mission.sqlite"
    app = create_app(db, path, "test-operator-token")
    with TestClient(app) as client:
        assert client.get("/api/status").json()["provenance"] == "simulation"
        body = {"id": 10, "sender": "W6ABC", "destination": "K6XYZ", "text": "73!", "ttl_s": 3600}
        assert client.post("/api/messages", json=body).status_code == 200
        assert client.post("/api/messages", json=body).status_code == 409
        assert client.post("/api/commands/execute", json={"name": "TX_DISABLE"}).status_code == 401
        assert client.post("/api/commands/preview", json={"name": "SET_MODE"}).status_code == 422
        auth = {"Authorization": "Bearer test-operator-token"}
        assert (
            client.post(
                "/api/simulation/advance", json={"seconds": 1800, "separation": True}
            ).status_code
            == 200
        )
        for command in [{"name": "SET_MODE", "mode": 2}, {"name": "TX_ENABLE"}]:
            assert (
                client.post("/api/commands/execute", json=command, headers=auth).status_code == 200
            )
        assert client.post("/api/relay/next").json()["rf_transmitted"] is False
        assert client.post("/api/ack", json={"id": 10, "recipient": "K6XYZ"}).status_code == 200
        assert (
            client.post(
                "/api/commands/execute", json={"name": "TX_DISABLE"}, headers=auth
            ).status_code
            == 200
        )
        assert client.get("/api/replay").json()["commanding_enabled"] is False
        assert (
            client.post(
                "/api/messages", json={**body, "id": 11}, headers={"Origin": "https://evil.example"}
            ).status_code
            == 403
        )
    restarted = TestClient(create_app(db, path, "test-operator-token"))
    assert restarted.get("/api/status").json()["tx_inhibited"]
    assert restarted.get("/api/messages").json()["messages"][0]["state"] == "acknowledged"


def test_signed_update_content_length_and_key(key):
    import ctypes
    import hashlib

    m, _ = core(key)
    lib = m.lib
    lib.sq_image_validate.argtypes = [
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
    ]
    lib.sq_image_validate.restype = ctypes.c_bool
    payload = bytes(128)
    manifest = (
        b"SQFW"
        + struct.pack("<QI", 2, len(payload))
        + hashlib.blake2b(payload, digest_size=32).digest()
    )
    signed_manifest = manifest + key.sign(manifest)
    image = signed_manifest + b"\xff" * (2048 - len(signed_manifest)) + payload
    public = key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    version = ctypes.c_uint64()
    assert (
        lib.sq_image_validate(image, len(image), public, ctypes.byref(version))
        and version.value == 2
    )
    assert not lib.sq_image_validate(
        image[:-1] + b"\x01", len(image), public, ctypes.byref(version)
    )
    assert not lib.sq_image_validate(image, len(image) - 1, public, ctypes.byref(version))
    assert not lib.sq_image_validate(image, len(image), bytes(32), ctypes.byref(version))


def test_confirmed_boot_trial_rollback_and_update_floor(key):
    import ctypes

    class Boot(ctypes.Structure):
        _fields_ = [
            ("accepted", ctypes.c_uint64),
            ("confirmed", ctypes.c_uint64),
            ("trial", ctypes.c_uint64),
            ("failed", ctypes.c_uint64),
            ("attempts", ctypes.c_uint32),
            ("generation", ctypes.c_uint32),
        ]

    m, _ = core(key)
    lib = m.lib
    lib.sq_boot_select.argtypes = [ctypes.POINTER(Boot), ctypes.c_void_p, ctypes.c_void_p]
    lib.sq_boot_select.restype = ctypes.c_int
    lib.sq_boot_confirm.argtypes = [ctypes.POINTER(Boot), ctypes.c_uint64]
    lib.sq_boot_confirm.restype = ctypes.c_bool
    state = Boot()
    valid = (ctypes.c_bool * 3)(True, False, True)
    versions = (ctypes.c_uint64 * 3)(1, 0, 1)
    assert lib.sq_boot_select(ctypes.byref(state), valid, versions) == 0
    assert lib.sq_boot_confirm(ctypes.byref(state), 1)
    valid[1] = True
    versions[1] = 2
    for _ in range(3):
        assert lib.sq_boot_select(ctypes.byref(state), valid, versions) == 1
    assert lib.sq_boot_select(ctypes.byref(state), valid, versions) == 0
    assert state.accepted == 2 and state.failed == 2 and state.confirmed == 1
    assert lib.sq_boot_select(ctypes.byref(state), valid, versions) == 0


def test_c_kiss_ax25_parser_matches_station_client(key):
    import ctypes

    m, _ = core(key)

    class Decoder(ctypes.Structure):
        _fields_ = [
            ("data", ctypes.c_uint8 * 512),
            ("length", ctypes.c_size_t),
            ("active", ctypes.c_bool),
            ("escape", ctypes.c_bool),
        ]

    decoder = Decoder()
    out = ctypes.create_string_buffer(240)
    m.lib.sq_kiss_init.argtypes = [ctypes.c_void_p]
    m.lib.sq_kiss_feed.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint8,
        ctypes.c_void_p,
        ctypes.c_size_t,
    ]
    m.lib.sq_kiss_feed.restype = ctypes.c_size_t
    m.lib.sq_kiss_init(ctypes.byref(decoder))
    message = RelayMessage(12, "W6ABC", "K6XYZ", "73!").encode()
    packet = kiss_encode(ax25_ui(message, "W6ABC", "SQSO-1"))
    decoded = []
    for value in packet:
        size = m.lib.sq_kiss_feed(ctypes.byref(decoder), value, out, 240)
        if size:
            decoded.append(out.raw[:size])
    assert decoded == [message] and m.receive(decoded[0]) == 0


def test_runtime_deadline_voting_clock_fault_and_wrap(key):
    import ctypes

    class Runtime(ctypes.Structure):
        _fields_ = [
            ("start_ms", ctypes.c_uint32),
            ("deadline_ms", ctypes.c_uint32),
            ("votes", ctypes.c_uint32),
            ("faults", ctypes.c_uint32),
            ("max_elapsed_ms", ctypes.c_uint32),
        ]

    m, _ = core(key)
    r = Runtime()
    lib = m.lib
    lib.sq_runtime_begin.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    lib.sq_runtime_vote.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_bool]
    lib.sq_runtime_healthy.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    lib.sq_runtime_healthy.restype = ctypes.c_bool
    lib.sq_runtime_begin(ctypes.byref(r), 100, 500)
    for task in range(4):
        lib.sq_runtime_vote(ctypes.byref(r), task, True)
    assert lib.sq_runtime_healthy(ctypes.byref(r), 600)
    assert not lib.sq_runtime_healthy(ctypes.byref(r), 601)
    lib.sq_runtime_begin(ctypes.byref(r), 100, 500)
    for task in range(3):
        lib.sq_runtime_vote(ctypes.byref(r), task, True)
    assert not lib.sq_runtime_healthy(ctypes.byref(r), 200)
    assert not lib.sq_runtime_healthy(ctypes.byref(r), 50)
    lib.sq_runtime_begin(ctypes.byref(r), 2**32 - 5, 500)
    for task in range(4):
        lib.sq_runtime_vote(ctypes.byref(r), task, True)
    assert lib.sq_runtime_healthy(ctypes.byref(r), 5)


def test_c_python_health_wire_conformance(key):
    from software.common.protocol import decode_health, health_frame

    mission, _ = core(key)
    mission.tick(123, 750, -1250)
    packet = mission.health_frame(42)
    assert packet == health_frame(42, 123, 750, -1250, 0, 25, 0)
    assert decode_health(packet)["temperature_centi_c"] == -1250
    with pytest.raises(ValueError):
        decode_health(packet[:-1])
    with pytest.raises(ValueError):
        health_frame(42, 123, 1001, 0, 0, 0, 0)


def test_isolated_worker_missing_model_uses_factual_fallback(tmp_path):
    from software.payload.bounded_worker import generate

    health = HealthSnapshot(7, 100, 760, "SAFE", False, False)
    result = generate(str(tmp_path / "missing.gguf"), health, 100, deadline_s=2)
    assert result["source"] == "deterministic-template"
    assert result["energy_j"] is None
    assert "Safe mode" in result["text"]
    assert "Radio inhibited" in result["text"]
    with pytest.raises(ValueError):
        generate("", health, 100, deadline_s=121)


def test_service_restart_does_not_present_default_health_as_fresh(tmp_path):
    db = tmp_path / "mission.sqlite"
    first = TestClient(create_app(db))
    first.post("/api/simulation/advance", json={"seconds": 60, "soc_permille": 810})
    restored = TestClient(create_app(db))
    status = restored.get("/api/status").json()
    assert status["soc_permille"] is None and status["temperature_centi_c"] is None
    assert status["observed_at"] is None and status["age_s"] is None and status["stale"]
    assert not status["health_available"] and "unavailable" in status["description"]
    assert restored.get("/api/telemetry").json()["samples"][-1]["soc_permille"] == 810
    assert restored.post("/api/simulation/advance", json={"seconds": 60}).json()["health_available"]


def test_generated_authority_fixtures_match_actual_c(key):
    import json

    from software.common.core import ROOT
    from software.common.protocol import RelayMessage
    from software.common.protocol_generated import PROTOCOL_HASH

    fixtures = json.loads((ROOT / "mission/current/protocol_fixtures.json").read_text())
    assert fixtures["protocol_hash"] == PROTOCOL_HASH
    mission, _ = core(key)
    health = fixtures["health"]
    values = health["values"]
    mission.tick(values["uptime_s"], values["soc_permille"], values["temperature_centi_c"])
    assert mission.health_frame(health["sequence"]) == bytes.fromhex(health["frame_hex"])
    packet = bytes.fromhex(fixtures["message"]["frame_hex"])
    assert RelayMessage.decode(packet).text == "73!"
    assert mission.receive(packet) == 0
    assert mission.messages()[0]["sender"] == fixtures["message"]["sender"]


def test_operator_receipt_preserves_full_uint64_message_id(tmp_path, key):
    path = tmp_path / "signer.pem"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    client = TestClient(create_app(tmp_path / "mission.sqlite", path, "test-operator"))
    client.post("/api/simulation/advance", json={"seconds": 1800, "separation": True})
    for command in ({"name": "SET_MODE", "mode": 2}, {"name": "TX_ENABLE"}):
        assert (
            client.post(
                "/api/commands/execute",
                json=command,
                headers={"Authorization": "Bearer test-operator"},
            ).status_code
            == 200
        )
    identifier = 2**64 - 1
    assert (
        client.post(
            "/api/messages",
            json={
                "id": str(identifier),
                "sender": "W6ABC",
                "destination": "K6XYZ",
                "text": "64-bit receipt",
            },
        ).status_code
        == 200
    )
    assert client.post("/api/relay/next").status_code == 200
    assert (
        client.post("/api/ack", json={"id": str(identifier), "recipient": "K6XYZ"}).status_code
        == 200
    )
    assert client.get("/api/messages").json()["messages"][0]["state"] == "acknowledged"


@pytest.mark.parametrize(
    "name,params",
    [("TX_ENABLE", b""), ("PAYLOAD_ENABLE", b""), ("SET_MODE", b"\x01"), ("SET_MODE", b"\x02")],
)
def test_retirement_is_persistent_and_blocks_reactivation(key, name, params):
    mission, images = core(key)
    ready(mission, key)
    assert mission.receive(signed(key, "PAYLOAD_ENABLE", 3)) == 0
    mission.tick(1801)
    assert mission.status()["payload_on"]
    assert mission.receive(signed(key, "END_MISSION", 4)) == 0
    assert mission.status()["retired"] and not mission.status()["tx_allowed"]
    assert not mission.status()["payload_on"] and mission.status()["mode"] == 0
    assert mission.receive(signed(key, "END_MISSION", 4)) == 3
    restored, _ = core(key, saved=images[-1])
    restored.tick(1900)
    assert restored.status()["retired"]
    assert restored.receive(signed(key, name, 5, params)) == 7
    assert restored.receive(RelayMessage(1, "W6ABC", "K6XYZ", "73").encode()) == 7
    assert restored.receive(signed(key, "GET_STATUS", 5)) == 0
    from software.common.protocol import decode_health

    assert decode_health(restored.health_frame(1))["flags"] & 32


def test_v2_state_migrates_without_a_retirement_claim(key):
    import binascii

    mission, _ = core(key)
    image = bytearray(mission.snapshot())
    image[4] = 2
    image[43] = 0
    image[60:64] = b"\0" * 4
    image[60:64] = struct.pack("<I", binascii.crc32(image[:60] + image[64:]))
    restored, _ = core(key, saved=bytes(image))
    assert not restored.status()["retired"] and restored.snapshot()[4] == 3


def test_terminal_sequence_preserves_shutdown_capability(key):
    mission, saved = core(key)
    ready(mission, key)
    assert mission.receive(signed(key, "GET_STATUS", 2**64 - 1)) == 7
    assert mission.status()["sequence"] == 2
    assert mission.receive(signed(key, "TX_DISABLE", 3)) == 0
    assert mission.receive(signed(key, "END_MISSION", 2**64 - 1)) == 0
    restored, _ = core(key, saved=saved[-1])
    assert restored.status()["retired"] and restored.status()["sequence"] == 2**64 - 1
    assert restored.receive(signed(key, "END_MISSION", 2**64 - 1)) == 3


def test_semantically_invalid_persistence_fails_closed_with_valid_crc(key):
    import binascii

    mission, _ = core(key)
    raw = bytearray(mission.snapshot())
    raw[7] = 1
    struct.pack_into("<Q", raw, 24, 10)
    struct.pack_into("<I", raw, 60, binascii.crc32(raw[:60] + raw[64:]))
    with pytest.raises(RuntimeError, match="Corrupt persistent"):
        core(key, saved=bytes(raw))



def test_legacy_v1_snapshot_crc_migrates_to_current_format(key):
    import binascii
    mission, _ = core(key)
    assert mission.receive(signed(key, "NOP", 5)) == 0
    raw = bytearray(mission.snapshot())
    raw[4] = 1
    struct.pack_into("<I", raw, 60, binascii.crc32(raw[:60]) ^ binascii.crc32(raw[64:]))
    restored, persisted = core(key, saved=bytes(raw))
    assert restored.status()["sequence"] == 5 and restored.snapshot()[4] == 3
    assert persisted[-1][4] == 3
