"""End-to-end production C supervision and authenticated flash fault scenarios."""

import base64
import ctypes
import hashlib
import struct

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)
from fastapi.testclient import TestClient

from software.common.core import MissionCore
from software.common.firmware_update import (
    SLOT_BYTES,
    BootState,
    FirmwareUpdater,
    FlashStore,
    inspect_image,
    transactions,
)
from software.common.obc_payload import ObcPayload
from software.common.payload_link import payload_result
from software.common.protocol import KINDS, KissDecoder, decode_health, frame, kiss_encode
from software.common.protocol_generated import COMMANDS
from software.ground.service.app import create_app
from software.payload.bridge import PayloadBridge, serve


def public(key):
    return key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)


def command(key, sequence, name, params=b""):
    raw = frame(KINDS["COMMAND"], sequence, bytes([COMMANDS[name]]) + params)
    return raw + key.sign(raw)


def image(key, slot=1, version=2, size=1025):
    reset = (0x08010000 if slot == 0 else 0x08070000) + 2048 + 9
    body = struct.pack("<II", 0x20018000, reset) + bytes((i % 251 for i in range(size - 8)))
    manifest = (
        b"SQFW" + struct.pack("<QI", version, size) + hashlib.blake2b(body, digest_size=32).digest()
    )
    signed = manifest + key.sign(manifest)
    return signed + b"\xff" * (2048 - len(signed)) + body


def rig(tmp_path, command_key=None):
    key = Ed25519PrivateKey.generate()
    saved = []
    core = MissionCore(public(command_key or key), lambda data: saved.append(data) or True)
    core.tick(0)
    flash = FlashStore(tmp_path / "flash")
    old = image(key, 0, 1)
    (flash.directory / "slot-0.bin").write_bytes(old + b"\xff" * (SLOT_BYTES - len(old)))
    boot = BootState(accepted=1, confirmed=1)
    core.lib.sq_boot_encode.argtypes = [ctypes.POINTER(BootState), ctypes.c_void_p]
    encoded = ctypes.create_string_buffer(64)
    core.lib.sq_boot_encode(ctypes.byref(boot), encoded)
    flash.save_boot(encoded.raw)
    flash.mutations = 0
    updater = FirmwareUpdater(core, flash, public(key), 0, 0)
    return key, core, flash, updater, saved


def test_operational_key_separation_in_http_service(tmp_path):
    key = Ed25519PrivateKey.generate()
    path = tmp_path / "command.pem"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    with pytest.raises(ValueError, match="must be separate"):
        create_app(tmp_path / "same-key.sqlite", path, "test-operator", public(key))


def test_serial_sender_rejects_shared_key_before_transport(tmp_path):
    from software.ground.client.firmware import send_update
    from software.ground.service.signing import Signer
    from software.ground.service.store import Store

    key = Ed25519PrivateKey.generate()
    path = tmp_path / "command.pem"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    # A transport without any write API proves rejection occurs before transmission.
    with pytest.raises(ValueError, match="must be separate"):
        send_update(object(), image(key), public(key), Signer(path),
                    Store(tmp_path / "seq.sqlite"), "W6ABC", "N0CALL")


@pytest.mark.parametrize("offset", [112, 1024, 2047])
def test_noncanonical_manifest_padding_rejected_by_c_and_python(tmp_path, offset):
    key, core, _, _, _ = rig(tmp_path)
    signed = bytearray(image(key))
    signed[offset] = 0
    with pytest.raises(ValueError, match="canonical"):
        inspect_image(bytes(signed), public(key))
    core.lib.sq_image_validate.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                                         ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint64)]
    core.lib.sq_image_validate.restype = ctypes.c_bool
    version = ctypes.c_uint64()
    assert not core.lib.sq_image_validate(bytes(signed), len(signed), public(key),
                                        ctypes.byref(version))


def transfer(key, core, signed, sequence=1):
    results = []
    for number, (cid, params) in enumerate(transactions(signed, 1), sequence):
        raw = frame(KINDS["COMMAND"], number, bytes([cid]) + params)
        result = core.receive(raw + key.sign(raw))
        results.append(result)
        if result:
            break
    return results


def test_full_update_real_writer_boot_trial_and_rollback(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    signed = image(key)
    assert inspect_image(signed, public(key))["target_slot"] == 1
    assert set(transfer(key, core, signed)) == {0}
    assert updater.status()["complete"]
    assert flash.read(1, 0, len(signed)) == signed
    for _ in range(3):
        assert updater.boot_cycle()["selected_slot"] == 1
    result = updater.boot_cycle()
    assert result["selected_slot"] == 0 and result["accepted_version"] == "2"
    assert result["failed_version"] == "2" and result["confirmed_version"] == "1"


def test_successful_trial_confirmation_protects_new_slot(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    assert set(transfer(key, core, image(key))) == {0}
    assert updater.boot_cycle(confirm=True)["confirmed_version"] == "2"
    raw = command(key, 99, "UPDATE_BEGIN", b"\x01" + image(key, version=3)[:112])
    before = flash.mutations
    assert core.receive(raw) == 7 and flash.mutations == before


@pytest.mark.parametrize("cut", range(16))
def test_power_cut_at_each_flash_mutation_never_publishes_partial_image(tmp_path, cut):
    key, core, flash, updater, saved = rig(tmp_path)
    old = flash.read(0, 0, SLOT_BYTES)
    flash.fail_after = cut
    results = transfer(key, core, image(key))
    assert results[-1] != 0
    assert flash.read(0, 0, SLOT_BYTES) == old
    assert flash.read(1, 0, 4) != b"SQFW"
    # Reset drops volatile transfer state; persistent command floor is retained.
    flash.fail_after = None
    restarted = MissionCore(public(key), lambda data: True, saved[-1])
    recovery = FirmwareUpdater(restarted, flash, public(key), 0, 0)
    assert not recovery.status()["active"]
    assert restarted.receive(command(key, 1, "UPDATE_ABORT")) == 3
    assert recovery.boot_cycle()["selected_slot"] == 0


def test_wrong_key_digest_readback_and_vector_target(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    other = Ed25519PrivateKey.generate()
    before = flash.mutations
    assert core.receive(command(key, 1, "UPDATE_BEGIN", b"\x01" + image(other)[:112])) == 2
    assert flash.mutations == before
    assert core.receive(command(key, 1, "UPDATE_BEGIN", b"\x01" + image(key)[:112])) == 0
    flash.corrupt_read = True
    chunk = transactions(image(key), 1)[1][1]
    assert core.receive(command(key, 2, "UPDATE_CHUNK", chunk)) == 6
    assert not updater.status()["active"]
    flash.corrupt_read = False
    assert updater.status()["faulted"]
    updater = FirmwareUpdater(core, flash, public(key), 0, 0)
    wrong_target = image(key, 0, version=3)
    assert transfer(key, core, wrong_target, 3)[-1] == 1
    assert flash.read(1, 0, 4) != b"SQFW"


@pytest.mark.parametrize("condition", ["cold", "hot", "low-power", "payload", "rf", "mode"])
def test_update_safety_gate_blocks_all_flash_writes(tmp_path, condition):
    key, core, flash, _, _ = rig(tmp_path)
    if condition == "cold":
        core.tick(0, 760, -1)
    if condition == "hot":
        core.tick(0, 760, 4500)
    if condition == "low-power":
        core.tick(0, 649, 2200)
    if condition == "payload":
        assert core.receive(command(key, 1, "PAYLOAD_ENABLE")) == 0
    if condition in ("rf", "mode"):
        core.separation()
        core.tick(1800)
        assert (
            core.receive(
                command(
                    key,
                    1,
                    "TX_ENABLE" if condition == "rf" else "SET_MODE",
                    b"\x01" if condition == "mode" else b"",
                )
            )
            == 0
        )
    before = flash.mutations
    assert core.receive(command(key, 2, "UPDATE_BEGIN", b"\x01" + image(key)[:112])) == 7
    assert flash.mutations == before


def test_chunk_offsets_expiry_and_unsigned_commands(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    manifest = b"\x01" + image(key)[:112]
    assert core.receive(command(key, 1, "UPDATE_BEGIN", manifest)) == 0
    wrong = struct.pack("<I", 128) + bytes(128)
    before = flash.mutations
    assert core.receive(command(key, 2, "UPDATE_CHUNK", wrong)) == 1
    assert core.receive(command(key, 2, "UPDATE_COMMIT")) == 1
    assert flash.mutations == before
    core.tick(121)
    assert not updater.status()["active"]
    assert core.receive(command(key, 2, "UPDATE_CHUNK", struct.pack("<I", 0) + bytes(128))) == 7


def test_persistent_boot_corruption_disables_update_acceptance(tmp_path):
    key, core, flash, _, _ = rig(tmp_path)
    (flash.directory / "boot.bin").write_bytes(bytes(64))
    with pytest.raises(ValueError, match="Corrupt boot state"):
        FirmwareUpdater(core, flash, public(key))


def payload_rig():
    key = Ed25519PrivateKey.generate()
    core = MissionCore(public(key), lambda data: True)
    core.tick(0, 761)
    core.receive(command(key, 1, "SET_MODE", b"\x01"))
    core.receive(command(key, 2, "PAYLOAD_ENABLE"))
    core.tick(0, 761)
    obc = ObcPayload(core)
    assert obc.poll() == b""
    core.tick(30, 761)
    request = obc.poll()
    assert request
    return core, obc, request


def test_obc_payload_bridge_raw_kiss_round_trip_independent_acceptance():
    core, obc, request = payload_rig()
    bridge = PayloadBridge()
    decoded = KissDecoder().feed(kiss_encode(request))[0]
    response = bridge.respond(decoded)
    assert obc.receive(KissDecoder().feed(kiss_encode(response))[0]) == 0
    assert obc.status() == {
        "powered": True,
        "accepted": True,
        "pending": False,
        "text": "Idle mode. Battery at 76.1%. Radio inhibited.",
    }
    with pytest.raises(ValueError, match="out-of-order"):
        bridge.respond(request)


@pytest.mark.parametrize(
    "text",
    [
        "Battery at 99%",
        "Radio enabled",
        "Relay mode",
        "In eclipse",
        "Idle mode. Idle mode",
        "RESET",
        "73!..",
        "Idle mode. ",
    ],
)
def test_mcu_rejects_wrong_facts_commands_and_grammar(text):
    core, obc, request = payload_rig()
    h = decode_health(request)
    assert obc.receive(payload_result(h["sequence"], h["uptime_s"], text)) == 1
    assert not obc.status()["accepted"] and "Battery at 76.1%" in obc.status()["text"]


def test_payload_stale_sequence_timeout_resource_loss_and_recovery():
    core, obc, request = payload_rig()
    h = decode_health(request)
    response = payload_result(h["sequence"], h["uptime_s"], "73!")
    assert obc.receive(payload_result(h["sequence"] + 1, h["uptime_s"], "73!")) == 7
    core.tick(51, 761)
    obc.poll()
    assert not obc.status()["powered"] and not core.status()["payload_on"]
    assert obc.receive(response) == 7
    core.tick(651, 761)
    assert obc.poll() == b"" and obc.status()["powered"]
    core.tick(681, 761)
    assert obc.poll()
    core.tick(682, 249)
    obc.poll()
    assert not obc.status()["powered"]


def test_serial_bridge_real_loop_fragmentation_and_partial_write():
    _, obc, request = payload_rig()

    class Port:
        def __init__(self):
            self.input = bytearray(kiss_encode(request))
            self.output = b""

        def read(self, n):
            value = bytes(self.input[:3])
            del self.input[:3]
            return value

        def write(self, data):
            self.output += data
            return len(data)

        def flush(self):
            pass

    port = Port()
    serve(port, PayloadBridge(), lambda: bool(port.output))
    response = KissDecoder().feed(port.output)[0]
    assert obc.receive(response) == 0

    class Partial(Port):
        def write(self, data):
            return 1

    with pytest.raises(OSError, match="Partial"):
        serve(Partial(), PayloadBridge(), lambda: False)


def test_update_http_operator_preview_steps_restart_and_audit(tmp_path):
    key = Ed25519PrivateKey.generate()
    path = tmp_path / "command.pem"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    firmware_key = Ed25519PrivateKey.generate()
    db = tmp_path / "mission.sqlite"
    client = TestClient(create_app(db, path, "operator", public(firmware_key)))
    auth = {"Authorization": "Bearer operator"}
    body = {"image_base64": base64.b64encode(image(firmware_key)).decode()}
    assert client.post("/api/updates/prepare", json=body).status_code == 401
    assert (
        client.post(
            "/api/updates/prepare", json=body, headers={**auth, "Origin": "https://evil.example"}
        ).status_code
        == 403
    )
    preview = client.post("/api/updates/prepare", json=body, headers=auth)
    assert preview.status_code == 200
    prepare = {"preparation_id": preview.json()["preparation_id"]}
    assert client.post("/api/updates/begin", json=prepare, headers=auth).status_code == 200
    assert client.post("/api/updates/begin", json=prepare, headers=auth).status_code == 409
    while not client.get("/api/updates").json()["complete"]:
        assert client.post("/api/updates/step", headers=auth).status_code == 200
    assert client.get("/api/updates").json()["trial_version"] == "2"
    restarted = TestClient(create_app(db, path, "operator", public(firmware_key)))
    assert not restarted.get("/api/updates").json()["active"]
    assert restarted.get("/api/updates").json()["accepted_version"] == "2"
    assert restarted.post("/api/updates/prepare", json=body, headers=auth).status_code == 422
    assert any(
        e["kind"] == "update-command-result" for e in restarted.get("/api/events").json()["events"]
    )


def _stalled_worker(output, model, health, gpu_layers):
    import time

    time.sleep(60)


def _incorrect_worker(output, model, health, gpu_layers):
    output.put({"text": "Battery at 99%", "error": None})


@pytest.mark.parametrize("worker", [_stalled_worker, _incorrect_worker])
def test_spawned_worker_deadline_and_wrong_facts_use_template(monkeypatch, worker):
    from software.payload import bounded_worker
    from software.payload.policy import HealthSnapshot

    monkeypatch.setattr(bounded_worker, "_generate", worker)
    report = bounded_worker.generate(
        "/unused", HealthSnapshot(1, 0, 761, "IDLE", None, False), 0, deadline_s=0.2
    )
    assert report["source"] == "deterministic-template"
    assert report["text"] == "Idle mode. Battery at 76.1%. Radio inhibited."
    assert report["elapsed_s"] < 4 and report["error"] is not None


def test_custom_port_origin_and_host_rebinding_rejected(tmp_path):
    client = TestClient(create_app(tmp_path / "port.sqlite", service_port=8001))
    assert (
        client.post(
            "/api/simulation/advance",
            json={"seconds": 1},
            headers={"Origin": "http://127.0.0.1:8001"},
        ).status_code
        == 200
    )
    assert (
        client.post(
            "/api/simulation/advance",
            json={"seconds": 1},
            headers={"Origin": "https://evil.example"},
        ).status_code
        == 403
    )
    assert client.get("/api/status", headers={"Host": "evil.example"}).status_code == 400


def test_signing_sequences_reserved_across_connections(tmp_path):
    import concurrent.futures

    from software.ground.service.store import Store

    path = tmp_path / "sequences.sqlite"
    stores = [Store(path) for _ in range(4)]

    def reserve(store):
        return [store.sequence(0) for _ in range(30)]

    with concurrent.futures.ThreadPoolExecutor(4) as pool:
        sequences = [v for values in pool.map(reserve, stores) for v in values]
    assert sorted(sequences) == list(range(1, 121))


def test_serial_firmware_sender_round_trip_with_actual_c_dispatch(tmp_path):
    from software.common.protocol import ax25_info, ax25_ui, unpack
    from software.ground.client.firmware import send_update
    from software.ground.service.signing import Signer
    from software.ground.service.store import Store

    command_key = Ed25519PrivateKey.generate()
    key, core, flash, updater, _ = rig(tmp_path, command_key)
    key_path = tmp_path / "key.pem"
    key_path.write_bytes(command_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    key_path.chmod(0o600)

    class Port:
        def __init__(self, missing=False):
            self.reply = b""
            self.missing = missing

        def write(self, data):
            packet = ax25_info(KissDecoder().feed(data)[0])
            _, sequence, payload, _ = unpack(packet)
            code = core.receive(packet)
            if not self.missing:
                self.reply = kiss_encode(
                    ax25_ui(
                        frame(KINDS["COMMAND_RESULT"], sequence, bytes([payload[0], code])),
                        "N0CALL",
                        "W6ABC",
                    )
                )
            return len(data)

        def flush(self):
            pass

        def read(self, n):
            result = self.reply[:n]
            self.reply = self.reply[n:]
            return result

    result = send_update(
        Port(),
        image(key),
        public(key),
        Signer(key_path),
        Store(tmp_path / "seq.sqlite"),
        "W6ABC",
        "N0CALL",
    )
    assert updater.status()["complete"] and result["commands_sent"] == 11
    assert (
        result["receipt_authentication"] == "unsigned/unverified" and not result["boot_confirmed"]
    )
    with pytest.raises(TimeoutError, match="Receipt missing"):
        send_update(
            Port(True),
            image(key, version=3),
            public(key),
            Signer(key_path),
            Store(tmp_path / "lost.sqlite"),
            "W6ABC",
            "N0CALL",
            floor=100,
            timeout_s=0.01,
        )


def test_actual_pyserial_payload_bridge_over_pseudoterminal():
    import os
    import pty
    import threading
    import time

    import serial

    _, obc, request = payload_rig()
    master, slave = pty.openpty()
    name = os.ttyname(slave)
    stop = threading.Event()
    with serial.Serial(name, 115200, timeout=0.01, write_timeout=1) as port:
        thread = threading.Thread(target=serve, args=(port, PayloadBridge(), stop.is_set))
        thread.start()
        try:
            os.write(master, kiss_encode(request))
            os.set_blocking(master, False)
            decoder = KissDecoder()
            responses = []
            deadline = time.monotonic() + 2
            while not responses and time.monotonic() < deadline:
                try:
                    responses.extend(decoder.feed(os.read(master, 256)))
                except BlockingIOError:
                    time.sleep(0.005)
            assert responses and obc.receive(responses[0]) == 0
        finally:
            stop.set()
            thread.join(1)
            assert not thread.is_alive()
    os.close(master)
    os.close(slave)


def test_unavailable_eps_never_appears_as_battery_zero_measurement():
    core = MissionCore(bytes(32), lambda data: True)
    core.lib.sq_tick_unavailable.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
    core.lib.sq_tick_unavailable(core.pointer, 10)
    assert not decode_health(core.health_frame(1))["flags"] & 16
    obc = ObcPayload(core)
    assert obc.poll() == b"" and "Battery telemetry unavailable" in obc.status()["text"]
    assert not core.status()["eps_valid"]


def test_recipient_contact_request_preserves_other_queues_and_fairness(tmp_path):
    from software.common.protocol import RelayMessage, relay_request

    key = Ed25519PrivateKey.generate()
    core = MissionCore(public(key), lambda data: True)
    core.tick(0)
    core.separation()
    core.tick(1800)
    assert core.receive(command(key, 1, "SET_MODE", b"\x02")) == 0
    assert core.receive(command(key, 2, "TX_ENABLE")) == 0
    for mid, sender, destination in [
        (1, "W6ABC", "K6XYZ"),
        (2, "W6DEF", "K6XYZ"),
        (3, "W6ABC", "N0ABC"),
    ]:
        assert (
            core.receive(RelayMessage(mid, sender, destination, "Public packet", 3600).encode())
            == 0
        )
    lib = core.lib
    lib.sq_relay_request.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_size_t),
    ]
    lib.sq_relay_request.restype = ctypes.c_int
    out = ctypes.create_string_buffer(240)
    length = ctypes.c_size_t()
    request = relay_request("K6XYZ")
    assert (
        lib.sq_relay_request(core.pointer, request, len(request), out, 20, ctypes.byref(length))
        == 1
    )
    for expected in (1, 2):
        assert (
            lib.sq_relay_request(
                core.pointer, request, len(request), out, len(out), ctypes.byref(length)
            )
            == 0
        )
        assert RelayMessage.decode(out.raw[: length.value]).id == expected
    assert next(m for m in core.messages() if m["id"] == "3")["attempts"] == 0
    assert core.receive(command(key, 3, "TX_DISABLE")) == 0
    assert (
        lib.sq_relay_request(
            core.pointer, request, len(request), out, len(out), ctypes.byref(length)
        )
        == 7
    )


def test_beacon_numeric_health_and_advisory_description_are_distinct():
    from software.common.protocol import decode_description

    core, obc, request = payload_rig()
    lib = core.lib
    lib.sq_payload_beacon.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_uint64,
        ctypes.c_void_p,
        ctypes.c_size_t,
    ]
    lib.sq_payload_beacon.restype = ctypes.c_size_t
    out = ctypes.create_string_buffer(240)

    def beacon():
        n = lib.sq_payload_beacon(obc.pointer, core.pointer, 99, out, len(out))
        return decode_description(out.raw[:n])

    assert beacon()["source"] == "deterministic template"
    assert obc.receive(PayloadBridge().respond(request)) == 0
    assert beacon()["source"] == "MCU-accepted payload" and not beacon()["authoritative_telemetry"]
    assert decode_health(core.health_frame(100))["soc_permille"] == 761


def test_new_wire_kinds_match_generated_golden_fixtures():
    import json

    from software.common.core import ROOT
    from software.common.payload_link import decode_payload_result
    from software.common.protocol import decode_description, relay_request

    fixtures = json.loads((ROOT / "mission/current/protocol_fixtures.json").read_text())
    p = fixtures["payload_result"]
    assert (
        payload_result(p["sequence"], p["values"]["observed_s"], p["values"]["text"]).hex()
        == p["frame_hex"]
    )
    assert decode_payload_result(bytes.fromhex(p["frame_hex"])) == (42, 123, p["values"]["text"])
    description = decode_description(bytes.fromhex(fixtures["description"]["frame_hex"]))
    assert description["text"] == fixtures["description"]["values"]["text"]
    assert relay_request("K6XYZ", 42).hex() == fixtures["relay_request"]["frame_hex"]


def test_signed_resume_after_reset_keeps_only_verified_pages(tmp_path):
    key, core, flash, updater, saved = rig(tmp_path)
    signed = image(key, size=5001)
    ops = transactions(signed, 1)
    # Complete one page and part of the second; no publication.
    for sequence, (cid, params) in enumerate(ops[:20], 1):
        raw = frame(KINDS["COMMAND"], sequence, bytes([cid]) + params)
        assert core.receive(raw + key.sign(raw)) == 0
    assert updater.status()["written"] == 19 * 128
    restarted = MissionCore(public(key), lambda data: saved.append(data) or True, saved[-1])
    restarted.tick(restarted.status()["uptime_s"])
    resumed = FirmwareUpdater(restarted, flash, public(key), 0, 0)
    assert restarted.receive(command(key, 100, "UPDATE_RESUME", b"\x01" + signed[:112])) == 0
    for _ in range(226):
        if not resumed.status()["recovering"]:
            break
    assert resumed.status()["written"] == 2048 and not resumed.status()["faulted"]
    for seq, (cid, params) in enumerate(transactions(signed, 1, 2048, True)[1:], 101):
        raw = frame(KINDS["COMMAND"], seq, bytes([cid]) + params)
        assert restarted.receive(raw + key.sign(raw)) == 0
    assert resumed.status()["complete"] and flash.read(1, 0, len(signed)) == signed


def test_torn_checkpoint_is_skipped_and_never_reprogrammed(tmp_path):
    key, core, flash, updater, saved = rig(tmp_path)
    signed = image(key, size=4097)
    ops = transactions(signed, 1)
    # Begin+erase+16 chunk writes; cut the first checkpoint doubleword.
    flash.fail_after = 19
    results = []
    for seq, (cid, params) in enumerate(ops[:17], 1):
        raw = frame(KINDS["COMMAND"], seq, bytes([cid]) + params)
        results.append(core.receive(raw + key.sign(raw)))
        if results[-1]:
            break
    # Inject an explicitly torn record independently of emulator write atomicity.
    (flash.directory / "slot-1.bin").open("r+b").close()
    with (flash.directory / "slot-1.bin").open("r+b") as file:
        file.seek(256)
        file.write(struct.pack("<I", 2048) + b"\xff" * 4)
    flash.fail_after = None
    restarted = MissionCore(public(key), lambda data: True, saved[-1])
    restarted.tick(restarted.status()["uptime_s"])
    resumed = FirmwareUpdater(restarted, flash, public(key), 0, 0)
    assert restarted.receive(command(key, 100, "UPDATE_RESUME", b"\x01" + signed[:112])) == 0
    for _ in range(226):
        if not resumed.status()["recovering"]:
            break
    assert resumed.status()["written"] == 0
    for seq, (cid, params) in enumerate(transactions(signed, 1, 0, True)[1:], 101):
        raw = frame(KINDS["COMMAND"], seq, bytes([cid]) + params)
        assert restarted.receive(raw + key.sign(raw)) == 0
    assert resumed.status()["complete"]


def test_staging_corruption_wrong_image_and_abort_prevent_resume(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    signed = image(key, size=4097)
    assert core.receive(command(key, 1, "UPDATE_BEGIN", b"\x01" + signed[:112])) == 0
    assert core.receive(command(key, 2, "UPDATE_ABORT")) == 0
    assert core.receive(command(key, 3, "UPDATE_RESUME", b"\x01" + signed[:112])) == 2
    assert not updater.status()["active"]
    assert core.receive(command(key, 3, "UPDATE_BEGIN", b"\x01" + signed[:112])) == 0
    core.tick(121)
    updater.status()
    assert (
        core.receive(
            command(key, 4, "UPDATE_RESUME", b"\x01" + image(key, version=3, size=4097)[:112])
        )
        == 2
    )
    with (flash.directory / "slot-1.bin").open("r+b") as file:
        file.seek(133)
        file.write(b"\x00")
    assert core.receive(command(key, 4, "UPDATE_RESUME", b"\x01" + signed[:112])) == 2


def test_payload_power_cycle_and_fresh_description_survive_power_off():
    core, obc, request = payload_rig()
    assert obc.receive(PayloadBridge().respond(request)) == 0
    core.tick(34, 761)
    obc.poll()
    assert obc.status()["powered"]
    core.tick(35, 761)
    obc.poll()
    assert not obc.status()["powered"] and obc.status()["accepted"]
    core.tick(61, 761)
    obc.poll()
    assert not obc.status()["accepted"]
    core.tick(635, 761)
    assert not obc.poll() and obc.status()["powered"]
    core.tick(665, 761)
    assert obc.poll()


def test_every_single_bit_damage_in_unsigned_frame_is_detected():
    from software.common.protocol import RelayMessage, unpack

    core = MissionCore(bytes(32), lambda data: True)
    packet = RelayMessage(1, "W6ABC", "K6XYZ", "Public message").encode()
    for byte in range(len(packet)):
        for bit in range(8):
            damaged = bytearray(packet)
            damaged[byte] ^= 1 << bit
            with pytest.raises(ValueError):
                unpack(bytes(damaged))
            assert core.receive(bytes(damaged)) != 0
    assert not core.messages()


def test_nonzero_kiss_port_dropped_on_both_sides():
    from software.common.protocol import RelayMessage, ax25_ui

    core = MissionCore(bytes(32), lambda data: True)

    class Decoder(ctypes.Structure):
        _fields_ = [
            ("data", ctypes.c_uint8 * 512),
            ("length", ctypes.c_size_t),
            ("active", ctypes.c_bool),
            ("escape", ctypes.c_bool),
        ]

    d = Decoder()
    out = ctypes.create_string_buffer(240)
    core.lib.sq_kiss_init.argtypes = [ctypes.c_void_p]
    core.lib.sq_kiss_init(ctypes.byref(d))
    core.lib.sq_kiss_feed.argtypes = [
        ctypes.c_void_p,
        ctypes.c_uint8,
        ctypes.c_void_p,
        ctypes.c_size_t,
    ]
    core.lib.sq_kiss_feed.restype = ctypes.c_size_t
    wire = kiss_encode(
        ax25_ui(RelayMessage(1, "W6ABC", "K6XYZ", "73").encode(), "W6ABC", "N0CALL"), port=1
    )
    assert KissDecoder().feed(wire) == []
    assert all(core.lib.sq_kiss_feed(ctypes.byref(d), b, out, len(out)) == 0 for b in wire)


def test_uplink_only_update_never_claims_execution(tmp_path, monkeypatch):
    from software.ground.client.firmware import send_update
    from software.ground.service.signing import Signer
    from software.ground.service.store import Store

    command_key = Ed25519PrivateKey.generate()
    key, core, flash, updater, _ = rig(tmp_path, command_key)
    path = tmp_path / "key.pem"
    path.write_bytes(command_key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)

    class Port:
        def write(self, data):
            return len(data)

        def flush(self):
            pass

    sleeps = []
    monkeypatch.setattr(
        "software.ground.client.firmware.time.sleep", lambda value: sleeps.append(value)
    )
    result = send_update(
        Port(),
        image(key),
        public(key),
        Signer(path),
        Store(tmp_path / "seq.sqlite"),
        "W6ABC",
        "N0CALL",
        receipts=False,
    )
    assert result["commands_sent"] == 11 and result["command_receipts_received"] == 0
    assert not result["boot_confirmed"] and "unverified" in result["receipt_authentication"]
    assert sleeps == [2.5] * 11 and not updater.status()["complete"]


def test_http_resume_after_restart_recovers_page_checkpoint(tmp_path):
    key = Ed25519PrivateKey.generate()
    firmware_key = Ed25519PrivateKey.generate()
    path = tmp_path / "key.pem"
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    db = tmp_path / "resume.sqlite"
    auth = {"Authorization": "Bearer operator"}
    body = {"image_base64": base64.b64encode(image(firmware_key, size=4097)).decode()}
    client = TestClient(create_app(db, path, "operator", public(firmware_key)))
    prepare = client.post("/api/updates/prepare", json=body, headers=auth).json()
    assert (
        client.post(
            "/api/updates/begin", json={"preparation_id": prepare["preparation_id"]}, headers=auth
        ).status_code
        == 200
    )
    for _ in range(2):
        assert client.post("/api/updates/step", headers=auth).status_code == 200
    assert client.get("/api/updates").json()["written"] == 2048
    restarted = TestClient(create_app(db, path, "operator", public(firmware_key)))
    assert restarted.post("/api/simulation/advance", json={"seconds": 1}).status_code == 200
    prepare = restarted.post("/api/updates/prepare", json=body, headers=auth).json()
    assert (
        restarted.post(
            "/api/updates/begin",
            json={"preparation_id": prepare["preparation_id"], "resume": True},
            headers=auth,
        ).status_code
        == 200
    )
    for _ in range(10):
        status = restarted.get("/api/updates").json()
        if status["complete"]:
            break
        assert restarted.post("/api/updates/step", headers=auth).status_code == 200
    assert restarted.get("/api/updates").json()["complete"]


def test_retirement_cancels_active_firmware_transfer(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    assert core.receive(command(key, 1, "UPDATE_BEGIN", b"\x01" + image(key)[:112])) == 0
    assert updater.status()["active"]
    assert core.receive(command(key, 2, "END_MISSION")) == 0
    updater.status()
    before = flash.mutations
    assert core.receive(command(key, 3, "UPDATE_BEGIN", b"\x01" + image(key, version=3)[:112])) == 7
    assert flash.mutations == before and not updater.status()["active"]


@pytest.mark.parametrize("key", [b"\0" * 32, b"x" * 31, b"x" * 33])
def test_service_rejects_invalid_firmware_verification_keys(tmp_path, key):
    with pytest.raises(ValueError, match="verification key"):
        create_app(tmp_path / "invalid-key.sqlite", update_key=key)


def test_explicit_payload_disable_invalidates_description_immediately():
    key = Ed25519PrivateKey.generate()
    core = MissionCore(public(key), lambda data: True)
    core.tick(0, 761)
    assert core.receive(command(key, 1, "SET_MODE", b"\x01")) == 0
    assert core.receive(command(key, 2, "PAYLOAD_ENABLE")) == 0
    core.tick(0, 761)
    obc = ObcPayload(core)
    obc.poll()
    core.tick(30, 761)
    request = obc.poll()
    assert obc.receive(PayloadBridge().respond(request)) == 0
    assert obc.status()["accepted"]
    assert core.receive(command(key, 3, "PAYLOAD_DISABLE")) == 0
    # Do not poll first: the explicit configuration change itself invalidates prose.
    assert not obc.status()["accepted"]


def test_maximum_slot_body_and_final_checkpoint_publish(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    signed = image(key, size=SLOT_BYTES - 2048)
    assert set(transfer(key, core, signed)) == {0}
    assert updater.status()["complete"] and updater.status()["written"] == SLOT_BYTES - 2048
    assert flash.read(1, 0, len(signed)) == signed
    assert updater.boot_cycle(confirm=True)["confirmed_version"] == "2"


@pytest.mark.parametrize(
    "offset,value", [(24, 3), (32, 3), (40, 3), (48, 1), (5, 1), (12, 1), (52, 1)]
)
def test_crc_correct_but_inconsistent_boot_state_is_rejected(tmp_path, offset, value):
    import binascii

    key, core, flash, _, _ = rig(tmp_path)
    raw = bytearray((flash.directory / "boot.bin").read_bytes())
    raw[offset] = value
    struct.pack_into("<I", raw, 60, binascii.crc32(raw[:60]))
    (flash.directory / "boot.bin").write_bytes(raw)
    with pytest.raises(ValueError, match="boot state"):
        FirmwareUpdater(core, flash, public(key), 0, 0)


def test_authenticated_chunks_cannot_change_firmware_signer_content(tmp_path):
    key, core, flash, updater, _ = rig(tmp_path)
    signed = image(key)
    operations = transactions(signed, 1)
    for seq, (cid, params) in enumerate(operations[:-1], 1):
        if cid == COMMANDS["UPDATE_CHUNK"] and params[:4] == b"\0" * 4:
            changed = bytearray(params)
            changed[4] ^= 1
            params = bytes(changed)
        assert (
            core.receive(
                command(key, seq, next(n for n, v in COMMANDS.items() if v == cid), params)
            )
            == 0
        )
    assert core.receive(command(key, 100, "UPDATE_COMMIT")) == 2
    assert flash.read(1, 0, 4) != b"SQFW" and updater.status()["accepted_version"] == "1"


@pytest.mark.parametrize(
    "phase", ["resume_manifest", "resume_record", "resume_body", "publish_vectors", "abort_marker"]
)
def test_update_io_loss_at_recovery_publication_and_abort_stays_unpublished(tmp_path, phase):
    key, core, flash, updater, saved = rig(tmp_path)
    signed = image(key, size=4097)
    if phase == "abort_marker":
        assert core.receive(command(key, 1, "UPDATE_BEGIN", b"\x01" + signed[:112])) == 0
        flash.fail_after = flash.mutations
        assert core.receive(command(key, 2, "UPDATE_ABORT")) == 6
    else:
        for seq, (cid, params) in enumerate(transactions(signed, 1)[:-1], 1):
            assert (
                core.receive(
                    command(key, seq, next(n for n, v in COMMANDS.items() if v == cid), params)
                )
                == 0
            )
        if phase.startswith("resume"):
            core = MissionCore(public(key), lambda data: True, saved[-1])
            core.tick(0)
            updater = FirmwareUpdater(core, flash, public(key), 0, 0)
            if phase == "resume_manifest":
                (flash.directory / "slot-1.bin").write_bytes(b"")
                assert core.receive(command(key, 100, "UPDATE_RESUME", b"\x01" + signed[:112])) == 6
            else:
                assert core.receive(command(key, 100, "UPDATE_RESUME", b"\x01" + signed[:112])) == 0
                with (flash.directory / "slot-1.bin").open("r+b") as file:
                    file.truncate(256 if phase == "resume_record" else 2048)
                updater.status()
        else:
            with (flash.directory / "slot-1.bin").open("r+b") as file:
                file.truncate(2048)
            assert core.receive(command(key, 100, "UPDATE_COMMIT")) == 6
    assert updater.status()["faulted"] and not updater.status()["complete"]
    assert flash.read(0, 0, 4) == b"SQFW"


def test_resume_after_final_partial_checkpoint_reconstructs_complete_hash(tmp_path):
    key, core, flash, _, saved = rig(tmp_path)
    signed = image(key, size=4097)
    for seq, (cid, params) in enumerate(transactions(signed, 1)[:-1], 1):
        assert (
            core.receive(
                command(key, seq, next(n for n, v in COMMANDS.items() if v == cid), params)
            )
            == 0
        )
    restarted = MissionCore(public(key), lambda data: True, saved[-1])
    restarted.tick(0)
    resumed = FirmwareUpdater(restarted, flash, public(key), 0, 0)
    assert restarted.receive(command(key, 100, "UPDATE_RESUME", b"\x01" + signed[:112])) == 0
    for _ in range(5):
        status = resumed.status()
    assert status["written"] == 4097 and not status["recovering"]
    assert restarted.receive(command(key, 101, "UPDATE_COMMIT")) == 0
    assert flash.read(1, 0, len(signed)) == signed


def test_short_custom_backend_read_never_reaches_memmove(tmp_path, monkeypatch):
    key, core, flash, updater, _ = rig(tmp_path)
    signed = image(key)
    assert core.receive(command(key, 1, "UPDATE_BEGIN", b"\x01" + signed[:112])) == 0
    core.tick(121)
    assert not updater.status()["active"]
    monkeypatch.setattr(flash, "read", lambda slot, offset, length: b"\xff" * (length - 1))
    assert core.receive(command(key, 2, "UPDATE_RESUME", b"\x01" + signed[:112])) == 6
    assert updater.status()["faulted"]
