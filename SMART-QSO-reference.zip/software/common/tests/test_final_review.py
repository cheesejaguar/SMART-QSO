"""Final-review regressions for exact counters, migration and fail-closed API behavior."""

import json
import sqlite3

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat
from fastapi.testclient import TestClient

from software.common.core import MissionCore
from software.common.protocol import unpack
from software.ground.service.app import create_app
from software.ground.service.store import Store


def test_legacy_sequence_migration_and_unsigned_range(tmp_path):
    path = tmp_path / "old.sqlite"
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE sequences(id INTEGER PRIMARY KEY, value INTEGER NOT NULL)")
        db.execute("INSERT INTO sequences VALUES(1,?)", (2**63 - 1,))
    store = Store(path)
    assert store.sequence(0) == 2**63
    restarted = Store(path)
    assert restarted.sequence(0) == 2**63 + 1
    assert restarted.db.execute("SELECT typeof(value) FROM sequences").fetchone()[0] == "text"


def test_terminal_nonce_reserved_without_consuming_shutdown(tmp_path):
    store = Store(tmp_path / "nonce.sqlite")
    assert store.sequence(2**64 - 3) == 2**64 - 2
    with pytest.raises(RuntimeError, match="exhausted"):
        store.sequence(0)
    assert store.sequence(0, terminal=True) == 2**64 - 1
    with pytest.raises(RuntimeError, match="exhausted"):
        store.sequence(0, terminal=True)


@pytest.mark.parametrize("floor", [-1, 2**64, 1.5, True])
def test_bad_sequence_floor_cannot_touch_archive(tmp_path, floor):
    store = Store(tmp_path / "nonce.sqlite")
    with pytest.raises(ValueError):
        store.sequence(floor)
    assert store.sequence(0) == 1


def test_corrupt_counter_fails_closed(tmp_path):
    store = Store(tmp_path / "nonce.sqlite")
    with store.db:
        store.db.execute("INSERT INTO sequences VALUES(1,'1.5')")
    with pytest.raises(RuntimeError, match="Corrupt"):
        store.sequence(0)


def test_http_counter_exactness_exhaustion_and_retirement(tmp_path):
    path = tmp_path / "key.pem"
    key = Ed25519PrivateKey.generate()
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    app = create_app(tmp_path / "mission.sqlite", path, "test-only")
    app.state.store.sequence(2**64 - 4)
    auth = {"Authorization": "Bearer test-only"}
    with TestClient(app) as client:
        receipt = client.post("/api/commands/execute", json={"name": "NOP"}, headers=auth)
        assert receipt.status_code == 200 and receipt.json()["sequence"] == str(2**64 - 2)
        assert client.get("/api/status").json()["sequence"] == str(2**64 - 2)
        denied = client.post("/api/commands/execute", json={"name": "NOP"}, headers=auth)
        assert denied.status_code == 503
        shutdown = client.post("/api/commands/execute", json={"name": "END_MISSION"}, headers=auth)
        assert shutdown.status_code == 200 and shutdown.json()["sequence"] == str(2**64 - 1)
        assert client.get("/api/status").json()["retired"]
    restarted = create_app(tmp_path / "mission.sqlite", path, "test-only")
    assert restarted.state.core.status()["retired"]


def test_simulation_clock_boundary_rejected_before_state_mutation(tmp_path):
    store = Store(tmp_path / "mission.sqlite")
    core = MissionCore(bytes(32), store.save)
    core.tick(2**63 - 1)
    store.save(core.snapshot())
    app = create_app(store.path)
    before = app.state.core.snapshot()
    with TestClient(app) as client:
        response = client.post("/api/simulation/advance", json={"seconds": 1, "separation": True})
        assert response.status_code == 409
    assert app.state.core.snapshot() == before


def test_command_archive_contains_exact_verifiable_frame_and_parameters(tmp_path):
    path = tmp_path / "key.pem"
    key = Ed25519PrivateKey.generate()
    path.write_bytes(key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    path.chmod(0o600)
    app = create_app(tmp_path / "mission.sqlite", path, "test-only")
    with TestClient(app) as client:
        response = client.post("/api/commands/execute", json={"name": "SET_MODE", "mode": 1},
                               headers={"Authorization": "Bearer test-only"})
        assert response.status_code == 200
        events = client.get("/api/events").json()["events"]
    record = json.loads(next(row["detail"] for row in events if row["kind"] == "command-request"))
    packet = bytes.fromhex(record["frame_hex"])
    _, sequence, payload, signature = unpack(packet)
    key.public_key().verify(signature, packet[:-64])
    assert payload[-1:] == b"\x01" and record["params_hex"] == "01"
    assert record["sequence"] == str(sequence) and not record["rf_transmitted"]
    assert "test-only" not in record.values()
