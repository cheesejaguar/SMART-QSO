"""Static publication must fail on broken assets, base paths, anchors or console leaks."""

import pytest

from tools.check_public_site import check


def test_project_site_links_and_downloads(tmp_path):
    (tmp_path / "index.html").write_text('<a href="/SMART-QSO/engineering/#evidence">Audit</a>')
    (tmp_path / "engineering").mkdir()
    (tmp_path / "engineering/index.html").write_text(
        '<h1 id="evidence">Evidence</h1><a href="/SMART-QSO/results.json">Results</a>'
    )
    (tmp_path / "results.json").write_text('{}')
    assert check(tmp_path, "/SMART-QSO", True)["checked_links"] == 2


@pytest.mark.parametrize("link", ["/proposal.pdf", "/SMART-QSO/missing/",
                                  "/SMART-QSO/#absent", "../outside"])
def test_invalid_public_links_fail(tmp_path, link):
    (tmp_path / "index.html").write_text(f'<a href="{link}">Broken</a>')
    with pytest.raises(ValueError):
        check(tmp_path, "/SMART-QSO", True)


def test_public_site_cannot_ship_local_console(tmp_path):
    (tmp_path / "index.html").write_text('<h1>Mission</h1>')
    (tmp_path / "console").mkdir()
    with pytest.raises(ValueError, match="console"):
        check(tmp_path, public_only=True)
