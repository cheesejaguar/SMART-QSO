"""Assurance tooling must not hide actionable or non-MISRA checker failures."""

import subprocess
from pathlib import Path

import pytest

from tools.check_misra import disposition, external_references, scan


def source(tmp_path, content):
    path = Path("software/flight/core/sample.c")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return str(path)


def test_missing_external_consumer_stays_actionable(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    external_references.cache_clear()
    path = source(tmp_path, "bool sq_sample(void) { return true; }\n")
    assert disposition("8.7", path, 1)["actionable"]
    consumer = Path("software/ground/client/demo.py")
    consumer.parent.mkdir(parents=True)
    consumer.write_text("# sq_sample is only prose\nmessage='sq_sample'\n")
    external_references.cache_clear()
    assert disposition("8.7", path, 1)["actionable"]
    consumer.write_text("result = library.sq_sample()\n")
    external_references.cache_clear()
    record = disposition("8.7", path, 1)
    assert not record["actionable"] and record["external_references"][0]["path"] == str(consumer)
    assert disposition("15.5", path, 1)["actionable"]


def test_c_comments_and_quoted_names_do_not_create_call_evidence(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    external_references.cache_clear()
    definition = source(tmp_path, "bool sq_sample(void) { return true; }\n")
    consumer = Path("software/flight/tests/test_sample.c")
    consumer.parent.mkdir(parents=True)
    consumer.write_text('/* sq_sample(); */\nconst char *prose="sq_sample";\n')
    assert disposition("8.7", definition, 1)["actionable"]
    consumer.write_text("int main(void) { return sq_sample(); }\n")
    external_references.cache_clear()
    assert not disposition("8.7", definition, 1)["actionable"]


@pytest.mark.parametrize(
    "diagnostic,code",
    [
        ('<error id="syntaxError" severity="error"/>', 2),
        ('<error id="variableScope" severity="style"/>', 2),
        ("", 9),
    ],
)
def test_checker_errors_cannot_be_relabelled_as_context(tmp_path, monkeypatch, diagnostic, code):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        subprocess,
        "run",
        lambda *a, **kw: subprocess.CompletedProcess(
            [], code, "", f"<results><errors>{diagnostic}</errors></results>"
        ),
    )
    with pytest.raises(RuntimeError, match="Checker errors"):
        scan(Path("/controlled/checker"), Path("/controlled/addon"))


def test_unknown_vendor_constant_is_not_automatically_waived(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    path = Path("software/flight/vendor/monocypher.h")
    path.parent.mkdir(parents=True)
    path.write_text("#define UNREVIEWED_NEW_CONSTANT 0\n")
    assert disposition("2.5", str(path), 1)["actionable"]
