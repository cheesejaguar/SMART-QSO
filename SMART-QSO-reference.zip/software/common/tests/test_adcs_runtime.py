"""Independent reference arithmetic and safety properties for production C ADCS/formatting."""

import ctypes
import random

import pytest

from software.common.adcs import Bdot, vector
from software.common.core import MissionCore


def trunc(value, divisor):
    return (-1 if value < 0 else 1) * (abs(value) // divisor)


def test_bdot_matches_independent_integer_reference_over_1000_samples():
    core = MissionCore(bytes(32), lambda data: True)
    controller = Bdot(core, 1000, 200000)
    rng = random.Random(71)
    previous = [30000, 0, 10000]
    flags = dict(reviewed=True, sensor_valid=True, permitted=True)
    assert not controller.step(previous, 0, **flags)["active"]
    for index in range(1, 1001):
        field = [rng.randint(-100000, 100000) for _ in range(3)]
        result = controller.step(field, index * 1000, **flags)
        moments = [-1000 * (field[i] - previous[i]) for i in range(3)]
        total = sum(abs(m) for m in moments)
        expected = [trunc(m * 200000, total) for m in moments] if total > 200000 else moments
        assert result["active"] and result["moment_uam2"] == expected
        assert sum(abs(m) for m in result["moment_uam2"]) <= 200000
        previous = field


@pytest.mark.parametrize(
    "fault",
    [
        "invalid_sensor",
        "inhibited",
        "unreviewed",
        "stale",
        "clock_loss",
        "out_of_range",
        "bad_scale",
    ],
)
def test_adcs_faults_zero_output_and_require_new_history(fault):
    controller = Bdot(MissionCore(bytes(32), lambda data: True), 50, 200000)
    flags = dict(reviewed=True, sensor_valid=True, permitted=True)
    field = [30000, 0, 10000]
    controller.step(field, 1000, **flags)
    now = 2000
    if fault == "invalid_sensor":
        flags["sensor_valid"] = False
    if fault == "inhibited":
        flags["permitted"] = False
    if fault == "unreviewed":
        flags["reviewed"] = False
    if fault == "stale":
        now = 11001
    if fault == "clock_loss":
        now = 999
    if fault == "out_of_range":
        field[0] = -(2**31)
    extra = {"scale": [1000000, 0, 1000000]} if fault == "bad_scale" else {}
    result = controller.step(field, now, **flags, **extra)
    assert not result["active"] and not result["history"] and result["moment_uam2"] == [0, 0, 0]
    assert not controller.step(
        [30000, 0, 10000], 12000, reviewed=True, sensor_valid=True, permitted=True
    )["active"]


@pytest.mark.parametrize("values", [[1, 2], [1, 2, 2**31], [True, 1, 2], [1.5, 2, 3]])
def test_adcs_adapter_rejects_unrepresentable_vectors(values):
    with pytest.raises(ValueError):
        vector(values)


def test_host_json_full_width_signed_values_and_all_capacity_boundaries():
    core = MissionCore(bytes(32), lambda data: True)
    core.tick(2**64 - 1, 1000, -5000)
    expected = core.status()
    assert expected["uptime_s"] == 2**64 - 1 and expected["temperature_centi_c"] == -5000
    output = ctypes.create_string_buffer(1024)
    length = core.lib.sq_status_json(core.pointer, output, len(output))
    for capacity in range(length + 1):
        target = ctypes.create_string_buffer(b"X" * 1024)
        returned = core.lib.sq_status_json(core.pointer, target, capacity)
        assert not returned
        if capacity:
            assert target[0] == b"\0"
        assert target.raw[capacity:1024] == b"X" * (1024 - capacity)
    assert core.lib.sq_status_json(core.pointer, output, length + 1) == length


@pytest.mark.parametrize("flag", ["false", 1, None])
def test_adcs_adapter_rejects_ambiguous_permission_flags(flag):
    controller = Bdot(MissionCore(bytes(32), lambda data: True), 50, 200000)
    with pytest.raises(ValueError, match="booleans"):
        controller.step([30000, 0, 10000], 0, permitted=flag)
