"""Readable amateur payloads; authentication is separate from confidentiality."""

from __future__ import annotations

import binascii
import re
import struct
from dataclasses import dataclass

from .protocol_generated import KINDS, SPEC

HEADER = struct.Struct(SPEC["header"])
MESSAGE = struct.Struct(SPEC["message"]["prefix"])
CALL = re.compile(r"^[A-Z0-9]{3,6}(?:-[0-9]{1,2})?$")


def callsign(value: str) -> str:
    value = value.upper()
    if not CALL.fullmatch(value) or not any(c.isdigit() for c in value) or not 3 <= len(value) <= 9:
        raise ValueError("Use a valid amateur callsign with optional SSID (0..15)")
    if "-" in value and int(value.rsplit("-", 1)[1]) > 15:
        raise ValueError("SSID exceeds 15")
    return value


def frame(kind: int, sequence: int, payload: bytes) -> bytes:
    if kind not in KINDS.values() or not 0 <= sequence < 2**64:
        raise ValueError("Invalid kind/sequence")
    size = HEADER.size + len(payload) + 4 + (64 if kind == KINDS["COMMAND"] else 0)
    if size > SPEC["max_frame_bytes"]:
        raise ValueError("Frame too large")
    raw = HEADER.pack(b"SQ", SPEC["version"], kind, sequence, len(payload)) + payload
    return raw + struct.pack("<I", binascii.crc32(raw))


def unpack(data: bytes) -> tuple[int, int, bytes, bytes]:
    if len(data) < HEADER.size or len(data) > SPEC["max_frame_bytes"]:
        raise ValueError("Invalid frame size")
    magic, version, kind, sequence, size = HEADER.unpack_from(data)
    extra = 4 + (64 if kind == KINDS["COMMAND"] else 0)
    if (
        magic != b"SQ"
        or version != SPEC["version"]
        or kind not in KINDS.values()
        or len(data) != HEADER.size + size + extra
    ):
        raise ValueError("Invalid frame")
    signed = kind == KINDS["COMMAND"]
    end = HEADER.size + size
    if struct.unpack_from("<I", data, end)[0] != binascii.crc32(data[:end]):
        raise ValueError("Frame CRC failed")
    return kind, sequence, data[HEADER.size : end], data[-64:] if signed else b""


@dataclass(frozen=True)
class RelayMessage:
    id: int
    sender: str
    destination: str
    text: str
    ttl_s: int = 3600

    def encode(self) -> bytes:
        sender, destination = callsign(self.sender), callsign(self.destination)
        text = self.text.encode("ascii")
        if not 1 <= len(text) <= 128 or any(c < 32 or c > 126 for c in text):
            raise ValueError("Message must be 1..128 printable ASCII bytes")
        if not 1 <= self.ttl_s <= 86400 or not 0 <= self.id < 2**64:
            raise ValueError("Invalid ID or TTL")
        return frame(
            KINDS["MESSAGE"],
            self.id,
            MESSAGE.pack(self.id, sender.encode(), destination.encode(), self.ttl_s, len(text))
            + text,
        )

    @classmethod
    def decode(cls, data: bytes) -> RelayMessage:
        kind, _, payload, _ = unpack(data)
        if kind != KINDS["MESSAGE"] or len(payload) < MESSAGE.size:
            raise ValueError("Not a relay message")
        mid, source, dest, ttl, n = MESSAGE.unpack_from(payload)
        if len(payload) != MESSAGE.size + n:
            raise ValueError("Message length mismatch")
        result = cls(
            mid,
            source.rstrip(b"\0").decode("ascii"),
            dest.rstrip(b"\0").decode("ascii"),
            payload[MESSAGE.size :].decode("ascii"),
            ttl,
        )
        for encoded, station in ((source, result.sender), (dest, result.destination)):
            if encoded != callsign(station).encode("ascii").ljust(10, b"\0"):
                raise ValueError("Noncanonical uppercase/padded station field")
        result.encode()  # Apply identical range/text checks on receive.
        return result


def acknowledgment(message_id: int, recipient: str) -> bytes:
    if not 0 <= message_id < 2**64:
        raise ValueError("Invalid acknowledgment ID")
    return frame(
        KINDS["ACK"], message_id, struct.pack("<Q10s", message_id, callsign(recipient).encode())
    )


def ax25_address(call: str, final: bool) -> bytes:
    parts = callsign(call).split("-")
    name, ssid = parts[0], int(parts[1]) if len(parts) == 2 else 0
    return bytes(ord(c) << 1 for c in name.ljust(6)) + bytes([0x60 | ssid << 1 | int(final)])


def ax25_ui(info: bytes, source: str, destination: str) -> bytes:
    return ax25_address(destination, False) + ax25_address(source, True) + b"\x03\xf0" + info


def ax25_info(data: bytes) -> bytes:
    if len(data) < 16:
        raise ValueError("Short AX.25 frame")
    offset = 0
    for _ in range(10):
        if offset + 7 > len(data):
            raise ValueError("Truncated AX.25 address")
        end = data[offset + 6] & 1
        offset += 7
        if end:
            break
    else:
        raise ValueError("Too many digipeaters")
    if offset < 14 or data[offset : offset + 2] != b"\x03\xf0":
        raise ValueError("Expected AX.25 UI PID F0")
    return data[offset + 2 :]


def kiss_encode(packet: bytes, port: int = 0) -> bytes:
    if not 0 <= port <= 15:
        raise ValueError("Invalid KISS port")
    raw = bytes([port << 4]) + packet
    return b"\xc0" + raw.replace(b"\xdb", b"\xdb\xdd").replace(b"\xc0", b"\xdb\xdc") + b"\xc0"


class KissDecoder:
    """Bounded streaming decoder; resynchronizes after bad escapes/oversized frames."""

    def __init__(self):
        self.buffer = bytearray()
        self.active = False
        self.escape = False

    def feed(self, data: bytes) -> list[bytes]:
        frames = []
        for value in data:
            if value == 0xC0:
                if self.active and self.buffer and not self.escape and self.buffer[0] == 0:
                    frames.append(bytes(self.buffer[1:]))
                self.buffer.clear()
                self.active, self.escape = True, False
            elif self.active:
                if self.escape:
                    if value not in (0xDC, 0xDD):
                        self.active = False
                        self.buffer.clear()
                    else:
                        self.buffer.append(0xC0 if value == 0xDC else 0xDB)
                    self.escape = False
                elif value == 0xDB:
                    self.escape = True
                else:
                    self.buffer.append(value)
                if len(self.buffer) > 512:
                    self.active = False
                    self.buffer.clear()
        return frames


HEALTH = struct.Struct(SPEC["health"]["prefix"])


def health_frame(
    sequence: int,
    uptime_s: int,
    soc_permille: int,
    temperature_centi_c: int,
    mode: int,
    flags: int,
    queue_count: int,
) -> bytes:
    if not (
        0 <= uptime_s < 2**64
        and 0 <= soc_permille <= 1000
        and -5000 <= temperature_centi_c <= 10000
        and 0 <= mode <= 2
        and 0 <= flags <= 63
        and 0 <= queue_count <= 32
    ):
        raise ValueError("Health values outside controlled units/limits")
    return frame(
        KINDS["HEALTH"],
        sequence,
        HEALTH.pack(uptime_s, soc_permille, temperature_centi_c, mode, flags, queue_count),
    )


def decode_health(data: bytes) -> dict:
    kind, sequence, payload, _ = unpack(data)
    if kind != KINDS["HEALTH"] or len(payload) != HEALTH.size:
        raise ValueError("Invalid health transaction")
    values = HEALTH.unpack(payload)
    health_frame(sequence, *values)
    return dict(zip(SPEC["health"]["fields"], values, strict=True), sequence=sequence)


def relay_request(recipient: str, sequence: int = 0) -> bytes:
    return frame(
        KINDS["RELAY_REQUEST"], sequence, struct.pack("<10s", callsign(recipient).encode())
    )


def decode_description(data: bytes) -> dict:
    kind, sequence, payload, _ = unpack(data)
    if kind != KINDS["DESCRIPTION"] or len(payload) < 10:
        raise ValueError("Invalid description frame")
    observed, source, length = struct.unpack_from("<QBB", payload)
    text = payload[10:]
    if (
        source > 1
        or not 1 <= length <= 120
        or len(text) != length
        or any(c < 32 or c > 126 for c in text)
    ):
        raise ValueError("Invalid bounded advisory text")
    return {
        "sequence": sequence,
        "uptime_s": observed,
        "source": "MCU-accepted payload" if source else "deterministic template",
        "text": text.decode("ascii"),
        "authoritative_telemetry": False,
    }
