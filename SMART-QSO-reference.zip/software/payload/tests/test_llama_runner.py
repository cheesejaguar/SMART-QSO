"""
Unit tests for LLaMA Runner Module

Tests model loading, text generation, and fallback behavior
for SMART-QSO Jetson payload.

Author: SMART-QSO Team
Date: 2026-01-02
Version: 1.0
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from llama_runner import LlamaConfig, LlamaRunner


class TestLlamaConfig(unittest.TestCase):
    """Test LlamaConfig dataclass."""

    def test_required_model_path(self):
        """Test model_path is required."""
        config = LlamaConfig(model_path="/models/test.gguf")
        self.assertEqual(config.model_path, "/models/test.gguf")

    def test_default_context_size(self):
        """Test default context size."""
        config = LlamaConfig(model_path="/test.gguf")
        self.assertEqual(config.n_ctx, 1024)

    def test_default_gpu_layers(self):
        """Test default GPU layers."""
        config = LlamaConfig(model_path="/test.gguf")
        self.assertEqual(config.n_gpu_layers, 0)

    def test_default_cache_types(self):
        """Test default cache types are None."""
        config = LlamaConfig(model_path="/test.gguf")
        self.assertIsNone(config.cache_type_k)
        self.assertIsNone(config.cache_type_v)

    def test_default_draft_model(self):
        """Test default draft model is None."""
        config = LlamaConfig(model_path="/test.gguf")
        self.assertIsNone(config.draft_model_path)

    def test_custom_values(self):
        """Test custom configuration values."""
        config = LlamaConfig(
            model_path="/models/custom.gguf",
            n_ctx=2048,
            n_gpu_layers=32,
            cache_type_k="q4_0",
            cache_type_v="q4_0",
            draft_model_path="/models/draft.gguf",
        )
        self.assertEqual(config.model_path, "/models/custom.gguf")
        self.assertEqual(config.n_ctx, 2048)
        self.assertEqual(config.n_gpu_layers, 32)
        self.assertEqual(config.cache_type_k, "q4_0")
        self.assertEqual(config.cache_type_v, "q4_0")
        self.assertEqual(config.draft_model_path, "/models/draft.gguf")


class TestLlamaRunnerFallback(unittest.TestCase):
    def test_missing_model_cannot_claim_nominal_spacecraft(self):
        runner = LlamaRunner(LlamaConfig(model_path="/nonexistent/model.gguf"))
        with self.assertRaisesRegex(RuntimeError, "unavailable"):
            runner.generate_one_line("sys", "usr")

    def test_initialized_backend_generates_requested_text(self):
        from unittest.mock import MagicMock

        runner = LlamaRunner(LlamaConfig(model_path="/nonexistent/model.gguf"))
        backend = MagicMock()
        backend.create_completion.return_value = {"choices": [{"text": "Safe mode."}]}
        runner._ll = backend
        self.assertEqual(runner.generate_one_line("system", "health", max_tokens=12), "Safe mode.")
        self.assertEqual(backend.create_completion.call_args.kwargs["max_tokens"], 12)

    def test_backend_failure_propagates_for_caller_fallback(self):
        from unittest.mock import MagicMock

        runner = LlamaRunner(LlamaConfig(model_path="/nonexistent/model.gguf"))
        runner._ll = MagicMock()
        runner._ll.create_completion.side_effect = RuntimeError("model failed")
        with self.assertRaisesRegex(RuntimeError, "model failed"):
            runner.generate_one_line("system", "health")


if __name__ == "__main__":
    unittest.main()
