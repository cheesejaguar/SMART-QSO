"""Process-isolated language experiment with a wall-clock deadline and factual acceptance."""

from __future__ import annotations

import multiprocessing as mp
import time
from dataclasses import asdict
from queue import Empty

from .policy import HealthSnapshot, accept_generated, approved_phrases, template


def _generate(output, model: str, health: dict, gpu_layers: int):
    try:
        from llama_cpp import Llama

        snapshot = HealthSnapshot(**health)
        allowed = sorted(approved_phrases(snapshot))
        generator = Llama(model_path=model, n_ctx=512, n_gpu_layers=gpu_layers, verbose=False)
        answer = generator.create_completion(
            prompt="Choose a concise status description using only these exact factual phrases, separated by a period and space: "
            + repr(allowed)
            + "\nStatus: ",
            max_tokens=40,
            temperature=0,
            stop=["\n"],
        )
        output.put({"text": answer["choices"][0]["text"].strip(), "error": None})
    except (ImportError, ValueError, OSError, RuntimeError, KeyError, IndexError) as exc:
        output.put({"text": None, "error": type(exc).__name__})


def generate(
    model: str, health: HealthSnapshot, now_s: int, deadline_s: float = 20, gpu_layers: int = 0
) -> dict:
    if not 0 < deadline_s <= 120:
        raise ValueError("Deadline must be within 0..120 seconds")
    start = time.monotonic()
    context = mp.get_context("spawn")
    output = context.Queue(maxsize=1)
    process = context.Process(
        target=_generate, args=(output, model, asdict(health), gpu_layers), daemon=True
    )
    process.start()
    process.join(deadline_s)
    result = {"text": None, "error": "deadline"}
    if process.is_alive():
        process.terminate()
        process.join(2)
        if process.is_alive():
            process.kill()
            process.join()
    else:
        try:
            result = output.get(timeout=0.25)
        except Empty:
            result = {"text": None, "error": "worker exited without result"}
    output.close()
    elapsed = time.monotonic() - start
    accepted = isinstance(result["text"], str) and accept_generated(
        result["text"], health, now_s + int(elapsed), health.sequence
    )
    return {
        "text": result["text"] if accepted else template(health),
        "source": "language-model" if accepted else "deterministic-template",
        "elapsed_s": elapsed,
        "energy_j": None,
        "error": result["error"]
        if result["error"]
        else None
        if accepted
        else "factuality/format/freshness rejected",
        "telemetry_sequence": health.sequence,
    }
