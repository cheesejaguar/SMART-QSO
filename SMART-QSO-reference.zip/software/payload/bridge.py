"""Point-to-point payload serial service; generates descriptions, never spacecraft commands."""

from __future__ import annotations

import argparse
import logging
import time
from pathlib import Path

import serial

from software.common.payload_link import payload_result
from software.common.protocol import KissDecoder, decode_health, kiss_encode
from software.payload.bounded_worker import generate
from software.payload.policy import HealthSnapshot, template

LOG = logging.getLogger(__name__)


class PayloadBridge:
    def __init__(self, model: str | None = None, deadline_s: float = 15):
        if not 0 < deadline_s <= 18:
            raise ValueError("Deadline must leave transport margin within the MCU 20-second limit")
        self.model, self.deadline = model, deadline_s
        self.last_sequence = -1

    def respond(self, request: bytes) -> bytes:
        h = decode_health(request)
        if h["sequence"] <= self.last_sequence:
            raise ValueError("Duplicate/out-of-order payload request")
        self.last_sequence = h["sequence"]
        if not h["flags"] & 4 or not h["flags"] & 8 or not h["flags"] & 16 or h["mode"] == 0:
            raise ValueError("OBC has not permitted healthy payload operation")
        snapshot = HealthSnapshot(
            h["sequence"],
            h["uptime_s"],
            h["soc_permille"],
            ["SAFE", "IDLE", "RELAY"][h["mode"]],
            None,
            bool(h["flags"] & 2),
        )
        text = template(snapshot)
        if self.model:
            result = generate(self.model, snapshot, snapshot.observed_s, self.deadline)
            text = result["text"]
            LOG.info("description source=%s error=%s", result["source"], result["error"])
        return payload_result(snapshot.sequence, snapshot.observed_s, text)


def serve(port, bridge: PayloadBridge, stop=lambda: False):
    decoder = KissDecoder()
    while not stop():
        data = port.read(256)
        for request in decoder.feed(data):
            try:
                response = kiss_encode(bridge.respond(request))
                if port.write(response) != len(response):
                    raise OSError("Partial payload serial write")
                port.flush()
            except (ValueError, UnicodeError) as exc:
                LOG.warning("Rejected payload request: %s", exc)
        if not data:
            time.sleep(0.005)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True)
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--model", type=Path)
    parser.add_argument("--deadline", type=float, default=15)
    args = parser.parse_args()
    if not args.port.startswith("/dev/") or not 1200 <= args.baud <= 921600:
        parser.error("Use an explicit /dev/ serial device and supported baud rate")
    logging.basicConfig(level=logging.INFO)
    bridge = PayloadBridge(str(args.model) if args.model else None, args.deadline)
    with serial.Serial(args.port, args.baud, timeout=0.1, write_timeout=1) as port:
        serve(port, bridge)


if __name__ == "__main__":
    main()
