# Payload transaction and language experiment

The current production interface is protocol v2 HEALTH in, bounded PAYLOAD_RESULT out, over raw KISS on the point-to-point UART. The OBC owns power, transactions, factual acceptance, deadlines and fallback. Run the serial endpoint explicitly:

```sh
uv run python -m software.payload.bridge --port /dev/ttyUSB0
```

Without `--model` the bridge uses deterministic templates. The selected flight model, inference runtime, artifact hashes/license, carrier/harness and full-cycle energy/thermal measurements remain open. A local optional `llama_cpp` installation is an experiment dependency, not a selected or locked flight runtime.

See [current integration and verification](../../docs/resurrection/PAYLOAD_INTEGRATION.md) and [software closure](../../docs/resurrection/SOFTWARE_CLOSURE.md). The legacy JSON agent, formatter, model runner, supervisor and health interface remain compatibility/prototype modules; their passing tests do not establish protocol-v2 integration or flight qualification. The [historical README](../../docs/history/PAYLOAD_README.md) preserves the earlier design and tuning claims as unverified records.
