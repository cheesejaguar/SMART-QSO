"""Bounded factual language acceptance. Generated prose cannot control the spacecraft."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HealthSnapshot:
    sequence: int
    observed_s: int
    soc_permille: int
    mode: str
    sunlit: bool | None
    tx_allowed: bool


def approved_phrases(health: HealthSnapshot) -> set[str]:
    if not 0 <= health.soc_permille <= 1000 or health.mode not in ("SAFE", "IDLE", "RELAY"):
        raise ValueError("Invalid health snapshot")
    phrases = {
        f"Battery at {health.soc_permille / 10:g}%",
        f"{health.mode.capitalize()} mode",
        "Radio enabled" if health.tx_allowed else "Radio inhibited",
        "73!",
    }
    if health.sunlit is not None:
        phrases.add("Sunlit" if health.sunlit else "In eclipse")
    return phrases


def accept_generated(text: str, health: HealthSnapshot, now_s: int, sequence: int) -> bool:
    if sequence != health.sequence or not 0 <= now_s - health.observed_s <= 30:
        return False
    if not 1 <= len(text.encode("utf-8")) <= 120 or not text.isascii():
        return False
    parts = text.rstrip(".").split(". ")
    return (
        bool(parts)
        and all(part in approved_phrases(health) for part in parts)
        and len(set(parts)) == len(parts)
    )


def template(health: HealthSnapshot) -> str:
    return f"{health.mode.capitalize()} mode. Battery at {health.soc_permille / 10:g}%. " + (
        "Radio enabled." if health.tx_allowed else "Radio inhibited."
    )


def status_template(status: dict) -> str:
    return template(
        HealthSnapshot(
            status["sequence"],
            status["uptime_s"],
            status["soc_permille"],
            ["SAFE", "IDLE", "RELAY"][status["mode"]],
            False,
            status["tx_allowed"],
        )
    )
