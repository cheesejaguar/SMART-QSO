# Product
<!-- impeccable:product-schema 1 -->
## Platform
web
## Stack
Delegated by the user: Astro public site; React/TypeScript/Vite mission console; local Python/FastAPI/SQLite service.
## Users
Licensed amateur packet operators and educational clubs use the relay. Operators diagnose spacecraft state and command safely. Research and institutional funders assess evidence, risk, and milestones.
## Product Purpose
A 3U digital store-and-forward CubeSat with bounded autonomy and an isolated onboard language-generation experiment. Core relay and factual telemetry remain deterministic.
## Operating Context
Repository-only starting point. No secured funding, partner institution, hardware, license, or launch. Public status must expose this. All simulated and replayed data carry provenance and freshness.
## Capabilities
AX.25/1200 baud AFSK with KISS TNC interoperability; bounded message queues; authenticated telecommand; MCU-controlled optional language payload; mission assurance and funding evidence.
## Constraints
3U reference, 12-month nominal life, $500k-$1.5m funding target (not a quotation), open unencrypted amateur service. Qualification and approvals require external evidence.
## Voice
Precise, approachable engineering. No invented partners, users, awards, flight heritage, NASA affiliation, compliance, or live spacecraft data.
